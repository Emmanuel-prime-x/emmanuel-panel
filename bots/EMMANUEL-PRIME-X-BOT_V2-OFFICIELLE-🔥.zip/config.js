const path = require('path')

// Lit une variable d'environnement (utile sur Pterodactyl > Startup > Variables)
let keysFile = {}
try { keysFile = require('./api-keys') } catch {}
// variable du panel d'abord, puis le fichier api-keys.js
const env = (k, d) => (process.env[k] !== undefined && process.env[k] !== '' ? process.env[k] : keysFile[k] || d)

module.exports = {
  botName: '𝐄𝐌𝐌𝐀𝐍𝐔𝐄𝐋 𝐏𝐑𝐈𝐌𝐄 𝐗 𝐁𝐎𝐓',
  version: '2.0.0',
  ownerName: '𝐏𝐑𝐎𝐅𝐄𝐒𝐒𝐎𝐑 𝐄𝐌𝐌𝐀𝐍𝐔𝐄𝐋 𝐗',
  ownerNumber: env('OWNER_NUMBER', '242056749511'),
  ownerTelegram: 'emmanuelprimex',
  // ---- Telegram : ton ID numérique (écris /id à @userinfobot) -> réserve les commandes owner à toi seul.
  // Plusieurs IDs possibles, séparés par des virgules (variable OWNER_TG_IDS ou ici).
  ownerTelegramIds: String(env('OWNER_TG_IDS', '8850465900')).split(',').map((x) => x.trim()).filter(Boolean),
  // ---- Telegram : groupes / chaînes à rejoindre OBLIGATOIREMENT avant d'utiliser le bot ----
  // chat : @nom_public (ou l'ID -100... pour un groupe privé) ; url : lien d'invitation affiché au bouton.
  // IMPORTANT : le bot Telegram doit être ADMIN de chaque groupe / chaîne pour pouvoir vérifier les membres.
  // Remplace les exemples ci-dessous (les lignes contenant VOTRE_ sont ignorées).
  requiredChats: [
    { name: '📢 Ma chaîne Telegram', chat: '@emmanuelprimexbot', url: 'https://t.me/emmanuelprimexbot' },
    { name: '👥 Mon groupe Telegram', chat: '@emmanuelprimexbotchat', url: 'https://t.me/emmanuelprimexbotchat' }
  ].filter((x) => !/VOTRE_/.test(x.chat)).concat(
    // ou via la variable REQUIRED_CHATS : "@ma_chaine,@mon_groupe" (le lien est déduit du @nom)
    String(env('REQUIRED_CHATS', '')).split(',').map((x) => x.trim()).filter((x) => /^@\w+$/.test(x)).map((x) => ({ name: '📢 ' + x, chat: x, url: 'https://t.me/' + x.slice(1) }))
  ),
  channel: 'https://whatsapp.com/channel/0029Vb9GRQFIHphNfTWq1r0U',
  youtube: 'https://www.youtube.com/@Emmanuel_ytb-d5i',

  // WhatsApp : les commandes fonctionnent dans les groupes (RESPOND_IN_GROUPS=false pour les désactiver)
  respondInGroups: !/^(0|false|no|non|off)$/i.test(env('RESPOND_IN_GROUPS', 'true')),

  prefix: env('PREFIX', '.'),
  timezone: env('TZ_BOT', 'Africa/Brazzaville'),

  // ---- Telegram (parrainage / appairage) ----
  telegramToken: env('TELEGRAM_TOKEN', '8641481327:AAHv6t3MBLJyBc6OWi4Yfjm1fUhvqc5yh9o'),
  maxSessionsPerUser: Number(env('MAX_SESSIONS_PER_USER', 2)),
  maxSessions: Number(env('MAX_SESSIONS', 150)),

  // ---- IA (optionnel : sans clé, le bot utilise Pollinations, gratuit) ----
  // (V2) corrigé : avant, la clé OpenRouter était collée à la place du NOM de la variable, donc jamais lue.
  // Mets ta clé dans la variable OPENROUTER_API_KEY (ne la colle plus dans le code).
  grokKey: env('GROK_API_KEY', ''),
  grokModel: env('GROK_MODEL', 'grok-3-mini'),
  geminiKey: env('GEMINI_API_KEY', ''),
  openrouterKey: env('OPENROUTER_API_KEY', ''),
  openrouterModel: env('OPENROUTER_MODEL', 'google/gemini-2.0-flash-exp:free'),
  // IA gratuites sans clé (secours quand Pollinations répond 402). {q} = question, {sys} = consigne.
  aiFreeApis: [
    'https://api.siputzx.my.id/api/ai/gpt3?prompt={sys}&content={q}',
    'https://api.siputzx.my.id/api/ai/metaai?query={q}',
    'https://api.giftedtech.co.ke/api/ai/gpt4o?apikey=gifted&q={q}',
    'https://api.giftedtech.co.ke/api/ai/geminiaipro?apikey=gifted&q={q}',
    'https://api.vreden.my.id/api/gpt4?query={q}'
  ],
  geminiModel: env('GEMINI_MODEL', 'gemini-2.5-flash'),
  openaiKey: env('OPENAI_API_KEY', ''),
  openaiBase: env('OPENAI_BASE_URL', 'https://api.openai.com/v1'),
  openaiModel: env('OPENAI_MODEL', 'gpt-4o-mini'),

  // ---- Secours quand yt-dlp est bloqué (YouTube, TikTok, Facebook, Instagram, X...) ----
  // {url} est remplacé par le lien. Elles sont essayées dans l'ordre, tu peux en ajouter / retirer.
  ytAudioApis: [
    'https://api.ryzumi.vip/api/downloader/ytmp3?url={url}',
    'https://api.nekolabs.web.id/downloader/youtube/v1?url={url}&format=mp3',
    'https://api.siputzx.my.id/api/d/ytmp3?url={url}',
    'https://api.vreden.my.id/api/v1/download/youtube/audio?url={url}&quality=128',
    'https://api.giftedtech.co.ke/api/download/ytmp3?apikey=gifted&url={url}',
    'https://api.vreden.my.id/api/ytmp3?url={url}',
    'https://api.giftedtech.co.ke/api/download/dlmp3?apikey=gifted&url={url}'
  ],
  ytVideoApis: [
    'https://api.ryzumi.vip/api/downloader/ytmp4?url={url}',
    'https://api.nekolabs.web.id/downloader/youtube/v1?url={url}&format=360',
    'https://api.siputzx.my.id/api/d/ytmp4?url={url}',
    'https://api.vreden.my.id/api/v1/download/youtube/video?url={url}&quality=360',
    'https://api.giftedtech.co.ke/api/download/ytmp4?apikey=gifted&url={url}',
    'https://api.vreden.my.id/api/ytmp4?url={url}',
    'https://api.giftedtech.co.ke/api/download/dlmp4?apikey=gifted&url={url}'
  ],
  socialApis: {
    tiktok: [
      'https://www.tikwm.com/api/?url={url}&hd=1',
      'https://api.siputzx.my.id/api/tiktok/v2?url={url}',
      'https://api.vreden.my.id/api/tiktok?url={url}',
      'https://api.giftedtech.co.ke/api/download/tiktok?apikey=gifted&url={url}'
    ],
    facebook: [
      'https://api.siputzx.my.id/api/d/facebook?url={url}',
      'https://api.vreden.my.id/api/fbdl?url={url}',
      'https://api.giftedtech.co.ke/api/download/facebook?apikey=gifted&url={url}'
    ],
    instagram: [
      'https://api.siputzx.my.id/api/d/igdl?url={url}',
      'https://api.vreden.my.id/api/igdl?url={url}',
      'https://api.giftedtech.co.ke/api/download/instadl?apikey=gifted&url={url}'
    ],
    twitter: [
      'https://api.vxtwitter.com/{path}',
      'https://api.siputzx.my.id/api/d/twitter?url={url}',
      'https://api.vreden.my.id/api/twitter?url={url}'
    ],
    any: [
      'https://api.siputzx.my.id/api/d/savefrom?url={url}'
    ]
  },
  // Cookies YouTube (format Netscape) : colle tout le contenu dans la variable YT_COOKIES, ou mets le fichier data/cookies.txt
  ytCookies: env('YT_COOKIES', ''),

  // ---- Images du bot ----
  profileImage: path.join(__dirname, 'assets', 'profile.jpg'),
  menuImage: path.join(__dirname, 'assets', 'bot.jpg'),
  menuThumb: path.join(__dirname, 'assets', 'menu-thumb.jpg'),
  // Instances Piped / Invidious (secours YouTube sans yt-dlp), essayées dans l'ordre
  pipedInstances: ['https://pipedapi.kavin.rocks', 'https://pipedapi.adminforge.de', 'https://api.piped.private.coffee', 'https://pipedapi.leptons.xyz'],
  invidiousInstances: ['https://inv.nadeko.net', 'https://yewtu.be', 'https://invidious.nerdvpn.de'],

  // ---- Dossiers ----
  dataDir: path.join(__dirname, 'data'),
  sessionsDir: path.join(__dirname, 'sessions'),
  settingsDir: path.join(__dirname, 'data', 'settings'),
  memoryDir: path.join(__dirname, 'data', 'memory'),
  tmpDir: path.join(__dirname, 'tmp'),
  binDir: path.join(__dirname, 'bin')
}

// @pseudo Telegram nettoyé (accepte « @nom », « t.me/nom » ou « https://t.me/nom »)
module.exports.ownerTelegramUser = String(module.exports.ownerTelegram).replace(/^(https?:\/\/)?(t\.me\/|telegram\.me\/)?@?/i, '').replace(/\/.*$/, '')
