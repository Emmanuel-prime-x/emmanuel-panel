import { BOT_NAME, VIDEOS_DIR } from '../config.js';
import { listFiles, sendLocal, VIDEO_EXT } from '../media.js';
import { getJson } from '../http.js';
import * as C from '../content.js';
import { esc, pick, randInt, normalize, mentionHtml, userName, bar } from '../util.js';
import * as store from '../store.js';

const riddles = new Map(); // chatId -> {a, until}
const simpleHash = (s) => { let h = 0; for (const c of s) h = (h * 31 + c.charCodeAt(0)) % 1000003; return h; };
const who = (ctx) => (ctx.target ? mentionHtml(ctx.target) : esc(ctx.args || userName(ctx.from)));
const simple = (name, desc, fn, extra = {}) => ({ name, desc, cat: '🎉 Fun', run: (ctx) => ctx.reply(fn(ctx)), ...extra });

async function apiPic(ctx, url, pickUrl, caption) {
  let data;
  try { data = await getJson(url, { timeout: 8000 }); } catch { return ctx.reply('Le service d’images ne répond pas, réessaie dans un instant 🙏'); }
  const u = pickUrl(data);
  if (!u) return ctx.reply('Je n’ai rien trouvé cette fois 😅');
  try { await ctx.media('photo', u, { caption }); } catch { await ctx.say(esc(u)); }
}

export const defs = [
  simple('blague', 'une blague', () => pick(C.JOKES), { aliases: ['joke'] }),
  simple('citation', 'une citation inspirante', () => pick(C.QUOTES), { aliases: ['quote'] }),
  simple('fait', 'un fait étonnant', () => `💡 ${pick(C.FACTS)}`, { aliases: ['fact', 'saviez'] }),
  simple('verite', 'une question « vérité »', () => `🔍 <b>Vérité</b>\n${pick(C.TRUTHS)}`, { aliases: ['truth'] }),
  simple('action', 'un défi « action »', () => `🎯 <b>Action</b>\n${pick(C.DARES)}`, { aliases: ['dare', 'defi'] }),
  simple('motivation', 'un petit boost', () => `💪 ${pick(C.MOTIVATION)}`, { aliases: ['boost'] }),
  simple('activite', 'une idée quand on s’ennuie', () => `🎲 ${pick(C.ACTIVITIES)}`, { aliases: ['ennuie'] }),
  simple('drague', 'une phrase de drague (gentille)', () => `😏 ${pick(C.PICKUP)}`, { aliases: ['flirt'] }),
  simple('compliment', 'un compliment (réponds à quelqu’un)', (ctx) => `💖 ${who(ctx)}, ${pick(C.COMPLIMENTS)}`),
  simple('roast', 'une petite vanne (pour rire)', (ctx) => `🔥 ${who(ctx)} : ${pick(C.ROASTS)}`, { aliases: ['vanne'] }),
  simple('boule', 'boule magique : pose une question', (ctx) => ctx.args ? `🔮 <i>${esc(ctx.args.slice(0, 200))}</i>\n${pick(C.EIGHTBALL)}` : 'Pose-moi une question : /boule Est-ce que je vais réussir ?', { aliases: ['8ball', 'magic'] }),
  simple('pf', 'pile ou face', () => (randInt(0, 1) ? '🪙 Pile !' : '🪙 Face !'), { aliases: ['pileouface', 'coin', 'flip'] }),
  simple('de', 'lancer un dé (/de 20)', (ctx) => { const n = Math.min(Math.max(parseInt(ctx.args, 10) || 6, 2), 1000000); return `🎲 Dé à ${n} faces : <b>${randInt(1, n)}</b>`; }, { aliases: ['dice', 'roll'] }),
  simple('nombre', 'nombre aléatoire (/nombre 1 100)', (ctx) => {
    const m = ctx.args.match(/^(-?\d+)\s+(-?\d+)$/);
    if (!m) return 'Usage : /nombre 1 100';
    const a = parseInt(m[1], 10); const b = parseInt(m[2], 10);
    return `🎲 <b>${randInt(Math.min(a, b), Math.max(a, b))}</b>`;
  }, { aliases: ['random', 'rand'] }),
  simple('choisir', 'choisit pour toi (/choisir pizza ou sushi)', (ctx) => {
    const opts = ctx.args.split(/\s*(?:,|;|\||\bou\b)\s*/i).map((s) => s.trim()).filter(Boolean);
    return opts.length < 2 ? 'Donne-moi au moins 2 choix : /choisir pizza ou sushi' : `🤔 Je choisis : <b>${esc(pick(opts))}</b>`;
  }, { aliases: ['choix', 'pick'] }),
  simple('note', 'note ton idée sur 10 (/note ma tenue)', (ctx) => {
    const t = ctx.args || 'toi'; const n = simpleHash(normalize(t)) % 11;
    return `⭐ « ${esc(t.slice(0, 60))} » : <b>${n}/10</b>`;
  }, { aliases: ['rate', 'rating'] }),
  simple('qi', 'ton QI (très sérieux)', (ctx) => `🧠 Le QI de ${who(ctx)} est de <b>${60 + (simpleHash(`iq${ctx.target?.id || ctx.from.id}`) % 100)}</b> (scientifiquement douteux 😄)`, { aliases: ['iq'] }),
  simple('beaute', 'ton taux de charme', (ctx) => { const p = 50 + (simpleHash(`b${ctx.target?.id || ctx.from.id}${new Date().toDateString()}`) % 51); return `✨ Charme du jour de ${who(ctx)} : <b>${p}%</b>\n${bar(p)}`; }, { aliases: ['charme'] }),
  simple('gay', 'détecteur de rien du tout (blague)', (ctx) => `🌈 ${who(ctx)} : <b>${simpleHash(`g${ctx.target?.id || ctx.from.id}`) % 101}%</b> de fabuleux(se) 😎`),
  simple('chance', 'ta chance du jour', (ctx) => { const p = simpleHash(`c${ctx.from.id}${new Date().toDateString()}`) % 101; return `🍀 Chance du jour : <b>${p}%</b>\n${bar(p)}`; }),
  {
    name: 'ship', aliases: ['love', 'amour', 'compat'], cat: '🎉 Fun', desc: 'compatibilité (/ship Alice ; Bob)',
    run(ctx) {
      let a; let b;
      if (ctx.args.includes(';')) [a, b] = ctx.args.split(';').map((s) => s.trim());
      else if (ctx.target) { a = userName(ctx.from); b = userName(ctx.target); }
      else { const p = ctx.args.split(/\s+/); if (p.length >= 2) [a, b] = [p[0], p[1]]; }
      if (!a || !b) return ctx.reply('Usage : /ship Alice ; Bob (ou réponds à quelqu’un)');
      const p = simpleHash([normalize(a), normalize(b)].sort().join('+')) % 101;
      const flavor = p < 21 ? 'Aucune alchimie 😅' : p < 41 ? 'Bof, à voir' : p < 61 ? 'Il y a du potentiel' : p < 81 ? 'Belle complicité 💞' : 'Match parfait 💘';
      return ctx.reply(`💫 ${esc(a)} + ${esc(b)}\n${bar(p)} <b>${p}%</b>\n${flavor}\n<i>(pour le fun 😉)</i>`);
    },
  },
  {
    name: 'horoscope', aliases: ['signe'], cat: '🎉 Fun', desc: 'horoscope du jour (/horoscope lion)',
    run(ctx) {
      const key = normalize(ctx.args || '');
      const sign = Object.keys(C.SIGNS).find((s) => s === key || (key && s.startsWith(key)));
      if (!sign) return ctx.reply(`Donne ton signe : /horoscope lion\n${Object.values(C.SIGNS).join(' · ')}`);
      const h = simpleHash(`${sign}${new Date().toDateString()}`);
      const pk = (arr, k) => arr[(h >> k) % arr.length];
      const love = 1 + (h % 5); const work = 1 + ((h >> 3) % 5);
      return ctx.reply(`${C.SIGNS[sign]}\n${pk(C.HORO_PARTS.a, 1)} ${pk(C.HORO_PARTS.b, 2)}. ${pk(C.HORO_PARTS.c, 4)}\n\n❤️ Amour : ${'★'.repeat(love)}${'☆'.repeat(5 - love)}\n💼 Travail : ${'★'.repeat(work)}${'☆'.repeat(5 - work)}`);
    },
  },
  {
    name: 'devinette', aliases: ['riddle'], cat: '🎉 Fun', desc: 'une devinette (puis /reponse)',
    run(ctx) {
      const r = pick(C.RIDDLES);
      riddles.set(ctx.chat.id, { a: r.a, until: Date.now() + 10 * 60000 });
      return ctx.reply(`🧩 <b>Devinette</b>\n${esc(r.q)}\n\nTape /reponse pour la solution.`);
    },
  },
  {
    name: 'reponse', cat: '🎉 Fun', desc: 'solution de la devinette', hidden: true,
    run(ctx) {
      const r = riddles.get(ctx.chat.id);
      if (!r || r.until < Date.now()) return ctx.reply('Pas de devinette en cours : tape /devinette');
      riddles.delete(ctx.chat.id);
      return ctx.reply(`💡 Réponse : <b>${esc(r.a)}</b>`);
    },
  },
  {
    name: 'bonjour', aliases: ['bonsoir', 'bonnenuit', 'gm', 'gn'], cat: '🎉 Fun', desc: 'salut personnalisé', hidden: true,
    run(ctx) {
      const h = new Date().getHours();
      const m = ctx.command === 'bonnenuit' || ctx.command === 'gn' ? '🌙 Bonne nuit' : h < 5 || h >= 18 ? '🌆 Bonsoir' : '☀️ Bonjour';
      return ctx.reply(`${m} ${esc(ctx.name)} ! Je suis ravie de te lire 💫`);
    },
  },
  {
    name: 'chat', aliases: ['cat', 'minou'], cat: '🐾 Animaux', desc: 'photo de chat', cooldown: 3000,
    run: (ctx) => apiPic(ctx, 'https://api.thecatapi.com/v1/images/search', (d) => d?.[0]?.url, '🐱 Miaou !'),
  },
  {
    name: 'chien', aliases: ['dog', 'toutou'], cat: '🐾 Animaux', desc: 'photo de chien', cooldown: 3000,
    run: (ctx) => apiPic(ctx, 'https://dog.ceo/api/breeds/image/random', (d) => d?.message, '🐶 Ouaf !'),
  },
  {
    name: 'renard', aliases: ['fox'], cat: '🐾 Animaux', desc: 'photo de renard', cooldown: 3000,
    run: (ctx) => apiPic(ctx, 'https://randomfox.ca/floof/', (d) => d?.image, '🦊 Le renard du jour'),
  },
  {
    name: 'canard', aliases: ['duck'], cat: '🐾 Animaux', desc: 'photo de canard', cooldown: 3000,
    run: (ctx) => apiPic(ctx, 'https://random-d.uk/api/v2/random', (d) => d?.url, '🦆 Coin coin !'),
  },
  {
    name: 'video', aliases: ['vid'], cat: '📸 Médias', desc: 'une vidéo de moi', cooldown: 5000,
    async run(ctx) {
      const files = listFiles(VIDEOS_DIR, VIDEO_EXT);
      if (!files.length) return ctx.reply('Je n’ai pas encore de vidéo à te montrer 🙈');
      await ctx.tg.typing(ctx.chat.id, 'upload_video', ctx.thread);
      await sendLocal(ctx, 'video', pick(files), { caption: `🎬 ${esc(BOT_NAME)} ✨` });
    },
  },
  {
    name: 'humeur', cat: '🏠 Général', desc: 'dis-moi ton humeur (/humeur joyeux)',
    run(ctx) {
      if (!ctx.args) return ctx.reply('Dis-moi comment tu te sens : /humeur joyeux');
      const u = store.touchUser(ctx.from); if (u) u.mood = ctx.args.slice(0, 40); store.save();
      return ctx.reply(`Merci de me le dire 💫 Je retiens que tu te sens « ${esc(ctx.args.slice(0, 40))} ».`);
    },
  },
];
export default defs;
