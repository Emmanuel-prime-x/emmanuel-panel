const AI = require('../lib/ai')
const U = require('../lib/utils')
const cfg = require('../config')

const key = (c) => `${c.number}_${c.senderNum}`
const use = (c, s) => c.reply(`ℹ️ Usage : ${c.prefix}${s}`)

module.exports = [
  {
    name: 'bot', aliases: ['chat', 'emmanuel'], cat: 'ai', desc: 'Discute avec le bot (il se souvient de tout)', usage: 'bot salut, ça va ?',
    run: async (c) => {
      if (!c.text) return c.reply(`Hey 👋 dis-moi tout !\nEx : ${c.prefix}bot salut, ça va ?\n\n_Je me souviens de nos discussions._`)
      await c.aiReply(c.text)
    }
  },
  {
    name: 'botreset', aliases: ['forget', 'oublie'], cat: 'ai', desc: 'Efface ce que le bot sait sur toi',
    run: async (c) => { AI.reset(key(c)); await c.reply("🧹 C'est fait, j'ai tout oublié de nos discussions. On repart de zéro !") }
  },
  {
    name: 'botmemory', aliases: ['memoire', 'memory'], cat: 'ai', desc: 'Voir ce que le bot retient de toi',
    run: async (c) => {
      const m = AI.info(key(c))
      if (!m.total) return c.reply("🧠 Je ne sais encore rien de toi. Commence par *" + c.prefix + "bot salut* !")
      await c.reply(`🧠 *Ma mémoire de toi*\n👤 Nom : ${m.name || '?'}\n💬 Messages échangés : ${m.total}\n📅 Depuis : ${new Date(m.since).toLocaleDateString('fr-FR')}\n\n${m.summary ? `📝 Résumé :\n${m.summary}` : '_(le résumé se construit au fil du temps)_'}`)
    }
  },
  {
    name: 'autochat', cat: 'ai', owner: true, desc: 'Réponses automatiques (DM + mentions en groupe)', usage: 'autochat on',
    run: async (c) => {
      const v = U.onoff(c.args[0])
      if (v === null) return c.reply(`Auto-chat : *${c.settings.autochat ? 'ON' : 'OFF'}*\nUtilise ${c.prefix}autochat on/off`)
      c.settings.autochat = v; c.saveSettings()
      await c.reply(`🤖 Auto-chat ${v ? 'activé : je réponds à tous les messages privés et quand on me mentionne' : 'désactivé'}.`)
    }
  },
  {
    name: 'ai', aliases: ['ask', 'gpt', 'gemini'], cat: 'ai', desc: 'Pose une question (sans mémoire)', usage: 'ai explique la gravité',
    run: async (c) => { if (!c.input) return use(c, 'ai <question>'); c.typing(); await c.reply(await AI.ask(c.input)) }
  },
  {
    name: 'imagine', aliases: ['img', 'image'], cat: 'ai', desc: "Génère une image à partir d'un texte", usage: 'imagine un lion astronaute',
    run: async (c) => {
      if (!c.text) return use(c, 'imagine <description>')
      await c.react('🎨')
      const url = `https://image.pollinations.ai/prompt/${encodeURIComponent(c.text)}?width=1024&height=1024&nologo=true&seed=${U.rand(1, 999999)}`
      await c.image(url, `🎨 ${c.text}`)
    }
  },
  {
    name: 'translate', aliases: ['tr', 'trad'], cat: 'ai', desc: 'Traduit un texte (réponds à un message ou écris-le)', usage: 'translate en Bonjour tout le monde',
    run: async (c) => {
      let lang = 'fr', text = c.text
      if (/^[a-z]{2}(-[A-Za-z]{2,4})?$/.test(c.args[0] || '') && (c.args.length > 1 || c.quoted?.text)) { lang = c.args[0]; text = c.args.slice(1).join(' ') || c.quoted?.text }
      else if (!text) text = c.quoted?.text || ''
      if (!text) return use(c, 'translate <langue> <texte>  (ex: translate en Salut)')
      const r = await U.translate(text, lang)
      await c.reply(`🌍 *${r.from} → ${lang}*\n\n${r.text}`)
    }
  },
  {
    name: 'summarize', aliases: ['resume', 'tldr'], cat: 'ai', desc: 'Résume un texte (réponds à un message)',
    run: async (c) => { if (!c.input) return use(c, 'summarize <texte> (ou réponds à un message)'); c.typing(); await c.reply(await AI.ask(`Résume ce texte en quelques phrases claires, dans sa langue :\n\n${c.input}`)) }
  },
  {
    name: 'fix', aliases: ['corrige'], cat: 'ai', desc: "Corrige l'orthographe et la grammaire",
    run: async (c) => { if (!c.input) return use(c, 'fix <texte>'); c.typing(); await c.reply(await AI.ask(`Corrige l'orthographe et la grammaire de ce texte sans changer le sens. Renvoie uniquement le texte corrigé :\n\n${c.input}`, undefined, { temperature: 0.2 })) }
  },
  {
    name: 'tts', aliases: ['voice', 'say'], cat: 'ai', desc: 'Transforme un texte en message vocal', usage: 'tts fr Bonjour !',
    run: async (c) => {
      let lang = 'fr', text = c.text || c.quoted?.text || ''
      if (/^[a-z]{2}(-[A-Za-z]{2})?$/.test(c.args[0] || '') && (c.args.length > 1)) { lang = c.args[0]; text = c.args.slice(1).join(' ') }
      if (!text) return use(c, 'tts [langue] <texte>')
      const parts = text.slice(0, 900).match(/[\s\S]{1,180}(?:\s|$)/g) || [text]
      const bufs = []
      for (const p of parts.slice(0, 5)) bufs.push(await U.getBuffer(`https://translate.google.com/translate_tts?ie=UTF-8&client=tw-ob&tl=${lang}&q=${encodeURIComponent(p.trim())}`, { maxBytes: 5e6 }))
      await c.audio(Buffer.concat(bufs), 'audio/mpeg', 'tts')
    }
  },
  {
    name: 'code', aliases: ['dev-ai'], cat: 'ai', desc: 'Génère du code', usage: 'code python un jeu du pendu',
    run: async (c) => { if (!c.text) return use(c, 'code <langage> <ce que tu veux>'); c.typing(); await c.reply(await AI.ask(`Écris le code demandé, complet et fonctionnel, dans un bloc de code, avec 2 lignes d'explication maximum : ${c.text}`, undefined, { max: 900, temperature: 0.3 })) }
  },
  {
    name: 'explain', aliases: ['explique'], cat: 'ai', desc: "Explique simplement n'importe quoi", usage: 'explain la blockchain',
    run: async (c) => { if (!c.input) return use(c, 'explain <sujet>'); c.typing(); await c.reply(await AI.ask(`Explique simplement, comme à un ami, avec un exemple concret : ${c.input}`)) }
  }
]
