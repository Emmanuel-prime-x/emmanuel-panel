const path = require('path')

// Lit une variable d'environnement (utile sur Pterodactyl > Startup > Variables)
const env = (k, d) => (process.env[k] !== undefined && process.env[k] !== '' ? process.env[k] : d)

module.exports = {
  botName: '𝐄𝐌𝐌𝐀𝐍𝐔𝐄𝐋 𝐏𝐑𝐈𝐌𝐄 𝐗 𝐁𝐎𝐓',
  version: '1.0.0',
  ownerName: '𝐏𝐑𝐎𝐅𝐄𝐒𝐒𝐎𝐑 𝐄𝐌𝐌𝐀𝐍𝐔𝐄𝐋 𝐗',
  ownerNumber: '242061468986',
  ownerTelegram: 't.me/emmanuelprimex',
  channel: 'https://whatsapp.com/channel/0029VbDMsSMGzzKaCwobcR1x',
  youtube: 'https://www.youtube.com/@Emmanuel_ytb-d5i',

  prefix: env('PREFIX', '.'),
  timezone: env('TZ_BOT', 'Africa/Brazzaville'),

  // ---- Telegram (parrainage / appairage) ----
  telegramToken: env('TELEGRAM_TOKEN', '8641481327:AAHrDs2ErwTj056UQQiiz1EORFn0OyKBz6U'),
  maxSessionsPerUser: Number(env('MAX_SESSIONS_PER_USER', 2)),
  maxSessions: Number(env('MAX_SESSIONS', 20)),

  // ---- IA (optionnel : sans clé, le bot utilise Pollinations, gratuit) ----
  openrouterKey: env('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', ''),
  geminiModel: env('GEMINI_MODEL', 'gemini-2.5-flash'),
  openaiKey: env('OPENAI_API_KEY', ''),
  openaiBase: env('OPENAI_BASE_URL', 'https://api.openai.com/v1'),
  openaiModel: env('OPENAI_MODEL', 'gpt-4o-mini'),

  // ---- Secours pour .song / .video quand yt-dlp est bloqué par YouTube ----
  // {url} est remplacé par le lien YouTube. Tu peux en ajouter / retirer.
  ytAudioApis: [
    'https://api.siputzx.my.id/api/d/ytmp3?url={url}',
    'https://api.giftedtech.co.ke/api/download/ytmp3?apikey=gifted&url={url}',
    'https://api.vreden.my.id/api/ytmp3?url={url}'
  ],
  ytVideoApis: [
    'https://api.siputzx.my.id/api/d/ytmp4?url={url}',
    'https://api.giftedtech.co.ke/api/download/ytmp4?apikey=gifted&url={url}',
    'https://api.vreden.my.id/api/ytmp4?url={url}'
  ],

  // ---- Dossiers ----
  dataDir: path.join(__dirname, 'data'),
  sessionsDir: path.join(__dirname, 'sessions'),
  settingsDir: path.join(__dirname, 'data', 'settings'),
  memoryDir: path.join(__dirname, 'data', 'memory'),
  tmpDir: path.join(__dirname, 'tmp'),
  binDir: path.join(__dirname, 'bin')
}
