import path from "path";
import { InputFile } from "grammy";
import fs from "fs";
import {
  OWNER_USERNAME,
  OWNER_ID,
  MENU_PHOTO_URL,
  MENU_VIDEO_URL,
  MENU_MEDIA_URL,
  MENU_MEDIA_TYPE,
  MAX_PAIR_PER_USER,
  FORCE_JOIN_CHANNELS,
  BRANDING,
} from "../../config/config.js";
import travas, { resolveGroupInviteTarget } from "../travas.js";
import { log } from "../logger.js";
import {
  isOwner,
  isAdmin,
  canUseBot,
  addAdmin,
  removeAdmin,
  getAdmins,
  addPremium,
  removePremium,
  getPremiums,
  addVVIP,
  removeVVIP,
  getVVIPs,
  getVVIPEntry,
  isVVIP,
  getMode,
  parseDuration,
  formatDuration,
  setMode,
  getPairsForUser,
  addPairNumber,
  getAllPairs,
  removePairNumber,
  clearAllPairs,
  getUsers,
  removeUser,
  addUser,
  getBotsForUser,
  addBotEntry,
  removeBotEntry,
} from "../../data/database.js";
import {
  initWhatsappForNumber,
  endWhatsappForNumber,
  clearAllSessions,
  getClient,
  waClients,
  clientKey,
  waitForPairSuccess as waitUntilOpen,
  sharedSessionKeyFromToken,
  describeWhatsappError,
} from "../whatsapp.js";
import {
  getVVIPUseState,
  consumeVVIPSenderUse,
  resetVVIPSenderUse,
  formatCooldownText,
} from "../vvipCooldown.js";

export function createHandlerRuntime(bot, menu, opts = {}) {
  const pendingAction = new Map();
  const pendingTravasTarget = new Map();
  const pairingLocks = new Set();
  const ownerActingAs = new Map();

  const isSubBot = !!opts.isSubBot;
  const subBotOwnerId = opts.subBotOwnerId ? String(opts.subBotOwnerId) : null;
  const subBotToken = opts.subBotToken || null;

  const checkOwner = (uid) =>
    isSubBot ? String(uid) === subBotOwnerId : isOwner(uid);

  const sharedKey =
    isSubBot && subBotToken ? sharedSessionKeyFromToken(subBotToken) : null;

  const getSessionKey = (uid) => (isSubBot && sharedKey ? sharedKey : uid);

  const normalizeActingEntry = (value) => {
    if (!value) return { targetKey: null, targetNumber: null };
    if (typeof value === "string") return { targetKey: value, targetNumber: null };
    return {
      targetKey: value.targetKey || null,
      targetNumber: value.targetNumber || null,
    };
  };

  const getActingTarget = (uid) => {
    const acting = normalizeActingEntry(ownerActingAs.get(String(uid)));
    return acting.targetKey || String(uid);
  };

  const getActingSenderNumber = (uid) => {
    const acting = normalizeActingEntry(ownerActingAs.get(String(uid)));
    return acting.targetNumber || null;
  };

  const isUsingExternalSender = (uid) => {
    const acting = normalizeActingEntry(ownerActingAs.get(String(uid)));
    return Boolean(acting.targetKey && acting.targetKey !== String(uid));
  };

  const resolveSessionKey = (uid) => {
    if (!isSubBot) {
      const acting = normalizeActingEntry(ownerActingAs.get(String(uid)));
      if (acting.targetKey) return acting.targetKey;
    }
    return getSessionKey(uid);
  };

  const describeAssenderTarget = (targetKey) => {
    if (String(targetKey).startsWith("sub_")) {
      return `émetteur(s) du sous-bot \`${targetKey}\``;
    }

    return `émetteur(s) de l'utilisateur \`${targetKey}\``;
  };

  const normalizeAssenderTarget = (arg) => {
    const trimmed = String(arg || "").trim();

    if (!trimmed) return { action: "invalid" };
    if (trimmed.toLowerCase() === "off") return { action: "off" };

    if (trimmed.startsWith("sub_")) {
      return { action: "target", targetKey: trimmed };
    }

    if (trimmed.includes(":")) {
      return {
        action: "target",
        targetKey: sharedSessionKeyFromToken(trimmed),
      };
    }

    const numericOnly = trimmed.replace(/[^0-9]/g, "");
    if (numericOnly && trimmed === numericOnly) {
      return { action: "target", targetKey: trimmed };
    }

    return { action: "invalid" };
  };

  const dbScope = isSubBot ? sharedKey : undefined;
  const checkAdmin = (id) => checkOwner(id) || isAdmin(id, dbScope);
  const checkAccess = (id) => checkOwner(id) || canUseBot(id, dbScope);

  const sanitizePhoneDigits = (input) => {
    const raw = Array.isArray(input) ? input.join(" ") : String(input ?? "");
    return raw.replace(/\D/g, "");
  };

  const registerUserIfNeeded = async (uid) => {
    const normalized = String(uid || "").trim();
    if (!normalized) return false;

    const added = addUser(normalized);
    if (added && !isSubBot && OWNER_ID) {
      await backupUsersJsonToOwner(normalized);
    }

    return added;
  };

  const backupUsersJsonToOwner = async (newUserId) => {
    if (isSubBot || !OWNER_ID) return false;

    const backupDir = path.resolve(process.cwd(), "database", "backups");
    const sourceFile = path.resolve(process.cwd(), "database", "users.json");
    const stamp = new Date()
      .toISOString()
      .slice(0, 19)
      .replace(/[:T]/g, "-");
    const backupFileName = `backup-${stamp}-${String(newUserId)}.json`;
    const backupFile = path.join(backupDir, backupFileName);

    try {
      fs.mkdirSync(backupDir, { recursive: true });

      let usersList = [];
      if (fs.existsSync(sourceFile)) {
        const raw = JSON.parse(fs.readFileSync(sourceFile, "utf-8"));
        usersList = Array.isArray(raw.users) ? raw.users : [];
      }

      const payload = {
        backupType: "users.json",
        generatedAt: new Date().toISOString(),
        reason: "sauvegarde nouvel utilisateur",
        newUserId: String(newUserId),
        totalUsers: usersList.length,
        users: usersList,
      };

      fs.writeFileSync(backupFile, JSON.stringify(payload, null, 2));

      await bot.api.sendDocument(
        OWNER_ID,
        new InputFile(backupFile, backupFileName),
        {
          caption:
            `📦 Nouvel utilisateur détecté\n` +
            `Sauvegardé dans les backups\n` +
            `ID utilisateur : ${String(newUserId)}\n` +
            `Total utilisateurs : ${usersList.length}\n` +
            `Fichier : ${backupFileName}`,
        },
      );

      return true;
    } catch (error) {
      log(`Échec de la sauvegarde users.json vers le propriétaire : ${String(error)}`);
      return false;
    }
  };

  const travasRun = async (ctx, uid, args, command, type, func) => {
    let target;

    if (type === "user") {
      const number = sanitizePhoneDigits(args);
      if (!number)
        return menu.botError(
          ctx,
          `Utilisation : /${command} <numéro>`,
          "⚠️ FORMAT INVALIDE",
        );
      target = `${number}@s.whatsapp.net`;
    } else if (type === "group") {
      const link = args[0];
      if (!link)
        return menu.botError(
          ctx,
          `Utilisation : /${command} <lien du groupe>`,
          "⚠️ FORMAT INVALIDE",
        );

      const sessionKey = resolveSessionKey(uid);
      const sessions = getPairsForUser(sessionKey);
      const active = sessions.find(
        (num) => getClient(sessionKey, num)?.status === "open",
      );

      if (!active)
        return menu.botError(ctx, "Aucun émetteur actif n'est disponible.", "⚠️ HORS LIGNE");

      const sock = getClient(sessionKey, active).sock;

      try {
        target = await resolveGroupInviteTarget(sock, link);
        if (!target) {
          return menu.botError(
            ctx,
            "Cible de groupe invalide. Envoie un lien d'invitation WhatsApp ou un JID de groupe valide terminant par @g.us.",
            "⚠️ CIBLE DE GROUPE INVALIDE",
          );
        }
      } catch (err) {
        log.error(`[GROUP_INVITE] ${err.message}`);
        return menu.botError(ctx, err.message, "❌ ÉCHEC");
      }
    } else if (type === "channel") {
      const channelId = sanitizePhoneDigits(args);
      if (!channelId)
        return menu.botError(
          ctx,
          `Utilisation : /${command} <channel_id>`,
          "⚠️ FORMAT INVALIDE",
        );
      target = `${channelId}@newsletter`;
    }

    await actionSession(ctx, uid, resolveSessionKey(uid), target, func, command);
  };

  const sendDoneCard = async (
    ctx,
    { command, target, type = "single", results = [] },
  ) => {
    const cells = [
      [
        { text: "Champ", is_header: true, align: "center", valign: "middle" },
        { text: "Valeur", is_header: true, align: "center", valign: "middle" },
      ],
      [
        { text: "Commande", align: "left", valign: "middle" },
        { text: `/${command}`, align: "left", valign: "middle" },
      ],
      [
        { text: "Cible", align: "left", valign: "middle" },
        { text: target, align: "left", valign: "middle" },
      ],
      [
        { text: "Statut", align: "left", valign: "middle" },
        { text: "✅ Expédié", align: "left", valign: "middle" },
      ],
    ];

    if (type === "all" && results.length) {
      results.forEach((num) => {
        cells.push([
          { text: "Émetteur", align: "left", valign: "middle" },
          { text: num, align: "left", valign: "middle" },
        ]);
      });
    }

    const blocks = [
      { type: "heading", text: "🟢 EXÉCUTION RÉUSSIE", size: 1 },
      {
        type: "table",
        cells: [
          [
            { text: "Ceci est une carte de réponse instantanée. L'exécution réelle se déroule en arrière-plan.", is_header: false, align: "center", valign: "middle" },
          ],
        ],
        is_bordered: true,
        is_striped: true,
      },
      { type: "divider" },
      { type: "table", cells, is_bordered: true, is_striped: true },
      {
        type: "buttons",
        buttons: [
          { text: "𝐛𝐚𝐜𝐤 - 𝐦𝐞𝐧𝐮", callback_data: "back_menu" },
        ],
      },
    ];

    return menu.streamBlocks(ctx, blocks, {
      totalDurationMs: 600,
      maxSteps: 2,
    });
  };

  const actionSession = async (ctx, realUid, storageKey, target, func, command) => {
    const selectedNumber = getActingSenderNumber(realUid);
    const sessions = selectedNumber
      ? getPairsForUser(storageKey).filter((n) => n === selectedNumber)
      : getPairsForUser(storageKey);

    if (!sessions.length) {
      return menu.botError(ctx, "Aucun émetteur n'est encore configuré.", "⚠️ AUCUNE SESSION");
    }

    const number = sessions[0];
    const client = getClient(storageKey, number);

    if (!client?.sock || client.status !== "open") {
      return menu.botError(
        ctx,
        `La session ${number} est hors ligne.`,
        "⚠️ SESSION HORS LIGNE",
      );
    }

    try {
      await sendDoneCard(ctx, { command, target, type: "single" });
      await func(client.sock, target);
    } catch (err) {
      log.error(
        `Exécution WhatsApp échouée | ${command} | ${describeWhatsappError(err)}`,
      );
      return menu.botError(ctx, describeWhatsappError(err), "❌ ÉCHEC");
    }

    return;
  };

  const sendVVIPSelectorMenu = async (ctx, runtime = {}) => {
    const uid = String(ctx.from.id);
    const {
      checkOwner = () => false,
      checkAdmin = () => false,
      dbScope,
      botError = () => Promise.resolve(),
    } = runtime;

    const isPrivilegedVVIPUser =
      checkOwner(uid) || checkAdmin(uid) || isVVIP(uid, dbScope);

    if (getMode(dbScope) === "public" && !isPrivilegedVVIPUser) {
      return botError(
        ctx,
        "Cette fonctionnalité d'émetteur VVIP est désactivée en mode public/gratuit pour les utilisateurs gratuits.",
        "⚠️ NON DISPONIBLE",
      );
    }

    if (!isPrivilegedVVIPUser) {
      return botError(ctx, "Un accès VVIP est requis pour cette fonctionnalité.");
    }

    const active = [];
    for (const [userId, numbers] of Object.entries(getAllPairs())) {
      for (const number of numbers) {
        const client = getClient(userId, number);
        if (client?.status === "open") {
          active.push({ userId, number });
        }
      }
    }

    if (!active.length) {
      return botError(
        ctx,
        "Aucun émetteur actif n'est disponible pour le moment.",
        "⚠️ VIDE",
      );
    }

    const usageState = getVVIPUseState(uid);
    const blocks = [
      {
        type: "heading",
        text: `👑 Émetteur VVIP — ${ctx.from.first_name}`,
        size: 1,
      },
      {
        type: "table",
        cells: [
          [
            {
              text: `Limite : ${usageState.limit}/15 min • Restant : ${usageState.remaining} • ${formatCooldownText(uid)}`,
              is_header: true,
              align: "center",
              valign: "middle",
            },
          ],
        ],
        is_bordered: true,
        is_striped: true,
      },
      {
        type: "buttons",
        buttons: active.map(({ userId, number }) => ({
          text: `📱 ${number} • ${userId}`,
          style: "success",
          callback_data: `vvip_select_${userId}__${number}`,
        })),
      },
      {
        type: "buttons",
        buttons: [
          { text: "Retour au menu", style: "danger", callback_data: "back_menu" },
        ],
      },
    ];

    return menu.streamBlocks(ctx, blocks);
  };

  return {
    isSubBot,
    subBotOwnerId,
    subBotToken,
    checkOwner,
    checkAdmin,
    checkAccess,
    dbScope,
    getSessionKey,
    resolveSessionKey,
    describeAssenderTarget,
    normalizeAssenderTarget,
    sanitizePhoneDigits,
    registerUserIfNeeded,
    backupUsersJsonToOwner,
    travasRun,
    actionSession,
    sendDoneCard,
    sendVVIPSelectorMenu,
    pendingAction,
    pendingTravasTarget,
    pairingLocks,
    ownerActingAs,
    getActingTarget,
    isUsingExternalSender,
  };
}
