import { TIMEZONE } from '../config.js';
import { getJson } from '../http.js';
import { esc, calc, fmtNum, normalize, truncate, clamp } from '../util.js';

const U = (name, desc, run, extra = {}) => ({ name, desc, cat: '🧰 Outils', run, ...extra });
const down = (ctx) => ctx.reply('Ce service externe ne répond pas pour le moment, réessaie dans un instant 🙏');
const enc = encodeURIComponent;

// ---- conversions ----
const UNITS = {
  length: { m: 1, km: 1000, cm: 0.01, mm: 0.001, mi: 1609.344, ft: 0.3048, in: 0.0254, yd: 0.9144 },
  mass: { kg: 1, g: 0.001, mg: 1e-6, t: 1000, lb: 0.45359237, oz: 0.028349523 },
  volume: { l: 1, ml: 0.001, cl: 0.01, gal: 3.785411784 },
  speed: { ms: 1, kmh: 1 / 3.6, mph: 0.44704, kt: 0.514444 },
  data: { b: 1, kb: 1024, mb: 1024 ** 2, gb: 1024 ** 3, tb: 1024 ** 4 },
};
const ALIAS = { km_h: 'kmh', 'km/h': 'kmh', 'm/s': 'ms', mile: 'mi', miles: 'mi', pied: 'ft', pieds: 'ft', pouce: 'in', pouces: 'in', livre: 'lb', livres: 'lb', litre: 'l', litres: 'l', celsius: 'c', fahrenheit: 'f', kelvin: 'k', '°c': 'c', '°f': 'f', go: 'gb', mo: 'mb', ko: 'kb', to: 'tb', o: 'b' };
const canon = (u) => { const x = u.toLowerCase(); return ALIAS[x] || x; };
function convert(v, from, to) {
  const f = canon(from); const t = canon(to);
  const temps = ['c', 'f', 'k'];
  if (temps.includes(f) && temps.includes(t)) {
    const c = f === 'c' ? v : f === 'f' ? (v - 32) * 5 / 9 : v - 273.15;
    return t === 'c' ? c : t === 'f' ? c * 9 / 5 + 32 : c + 273.15;
  }
  for (const table of Object.values(UNITS)) if (f in table && t in table) return (v * table[f]) / table[t];
  return null;
}

// ---- heure ----
const CITIES = { paris: 'Europe/Paris', londres: 'Europe/London', london: 'Europe/London', berlin: 'Europe/Berlin', madrid: 'Europe/Madrid', rome: 'Europe/Rome', moscou: 'Europe/Moscow', istanbul: 'Europe/Istanbul', newyork: 'America/New_York', montreal: 'America/Toronto', chicago: 'America/Chicago', losangeles: 'America/Los_Angeles', saopaulo: 'America/Sao_Paulo', brazzaville: 'Africa/Brazzaville', kinshasa: 'Africa/Kinshasa', libreville: 'Africa/Libreville', douala: 'Africa/Douala', lagos: 'Africa/Lagos', abidjan: 'Africa/Abidjan', dakar: 'Africa/Dakar', casablanca: 'Africa/Casablanca', alger: 'Africa/Algiers', tunis: 'Africa/Tunis', lecaire: 'Africa/Cairo', nairobi: 'Africa/Nairobi', johannesburg: 'Africa/Johannesburg', dubai: 'Asia/Dubai', mumbai: 'Asia/Kolkata', delhi: 'Asia/Kolkata', pekin: 'Asia/Shanghai', shanghai: 'Asia/Shanghai', tokyo: 'Asia/Tokyo', seoul: 'Asia/Seoul', sydney: 'Australia/Sydney' };
const fmtTime = (tz) => new Intl.DateTimeFormat('fr-FR', { timeZone: tz, dateStyle: 'full', timeStyle: 'medium' }).format(new Date());

const WMO = { 0: '☀️ Ciel dégagé', 1: '🌤️ Plutôt dégagé', 2: '⛅ Partiellement nuageux', 3: '☁️ Couvert', 45: '🌫️ Brouillard', 48: '🌫️ Brouillard givrant', 51: '🌦️ Bruine légère', 53: '🌦️ Bruine', 55: '🌧️ Bruine forte', 61: '🌧️ Pluie légère', 63: '🌧️ Pluie', 65: '🌧️ Forte pluie', 71: '🌨️ Neige légère', 73: '🌨️ Neige', 75: '❄️ Forte neige', 80: '🌦️ Averses', 81: '🌧️ Averses fortes', 82: '⛈️ Averses violentes', 95: '⛈️ Orage', 96: '⛈️ Orage et grêle', 99: '⛈️ Orage violent' };
const COINS = { btc: 'bitcoin', bitcoin: 'bitcoin', eth: 'ethereum', ethereum: 'ethereum', sol: 'solana', bnb: 'binancecoin', xrp: 'ripple', doge: 'dogecoin', ada: 'cardano', ton: 'the-open-network', usdt: 'tether', ltc: 'litecoin' };

export const defs = [
  U('calc', 'calculatrice (/calc 2*(3+4))', (ctx) => {
    if (!ctx.args) return ctx.reply('Usage : /calc 2*(3+4)^2 — fonctions : sqrt, sin, cos, tan, log, ln, abs, round, pi, e');
    try { return ctx.reply(`🧮 ${esc(truncate(ctx.args, 100))} = <b>${fmtNum(calc(ctx.args))}</b>`); } catch (e) { return ctx.reply(`Je n’ai pas compris ce calcul (${esc(e.message)}) 🤔`); }
  }, { aliases: ['calcul2', 'calculer'] }),
  U('convertir', 'convertir (/convertir 10 km mi)', (ctx) => {
    const m = ctx.args.match(/^(-?[\d.,]+)\s*([^\s\d]+)\s+(?:en|to|vers|->)?\s*([^\s\d]+)$/i);
    if (!m) return ctx.reply('Usage : /convertir 10 km mi\nUnités : km m cm mm mi ft in · kg g lb oz · l ml gal · c f k · kmh mph ms · kb mb gb tb');
    const v = parseFloat(m[1].replace(',', '.'));
    const r = convert(v, m[2], m[3]);
    return ctx.reply(r === null ? 'Je ne connais pas ces unités 🤔' : `📏 ${fmtNum(v)} ${esc(m[2])} = <b>${fmtNum(r)} ${esc(m[3])}</b>`);
  }, { aliases: ['convert', 'conv'] }),
  U('heure', 'heure dans une ville (/heure tokyo)', (ctx) => {
    const q = normalize(ctx.args);
    const tz = !q ? TIMEZONE : CITIES[q] || (ctx.args.includes('/') ? ctx.args.trim() : null);
    if (!tz) return ctx.reply(`Ville inconnue. Essaie : ${Object.keys(CITIES).slice(0, 14).join(', ')}… ou un fuseau comme Europe/Paris`);
    try { return ctx.reply(`🕐 <b>${esc(ctx.args || tz)}</b>\n${esc(fmtTime(tz))}`); } catch { return ctx.reply('Fuseau horaire invalide.'); }
  }, { aliases: ['time', 'date', 'jour'] }),
  U('age', 'ton âge (/age 14/05/2000)', (ctx) => {
    const m = ctx.args.match(/^(\d{1,2})[/.-](\d{1,2})[/.-](\d{4})$/) || ctx.args.match(/^(\d{4})-(\d{1,2})-(\d{1,2})$/);
    if (!m) return ctx.reply('Usage : /age 14/05/2000');
    const [d, mo, y] = m[1].length === 4 ? [m[3], m[2], m[1]] : [m[1], m[2], m[3]];
    const b = new Date(Date.UTC(+y, +mo - 1, +d)); const now = new Date();
    if (Number.isNaN(b.getTime()) || b > now) return ctx.reply('Date invalide 🤔');
    let years = now.getUTCFullYear() - b.getUTCFullYear();
    if (now.getUTCMonth() < b.getUTCMonth() || (now.getUTCMonth() === b.getUTCMonth() && now.getUTCDate() < b.getUTCDate())) years -= 1;
    return ctx.reply(`🎂 Tu as <b>${years} ans</b> (${fmtNum(Math.floor((now - b) / 86400000))} jours de vie)`);
  }),
  U('jours', 'jours avant une date (/jours 25/12)', (ctx) => {
    const m = ctx.args.match(/^(\d{1,2})[/.-](\d{1,2})(?:[/.-](\d{4}))?$/);
    if (!m) return ctx.reply('Usage : /jours 25/12 ou /jours 01/01/2027');
    const now = new Date(); const today = Date.UTC(now.getUTCFullYear(), now.getUTCMonth(), now.getUTCDate());
    let target = Date.UTC(m[3] ? +m[3] : now.getUTCFullYear(), +m[2] - 1, +m[1]);
    if (!m[3] && target < today) target = Date.UTC(now.getUTCFullYear() + 1, +m[2] - 1, +m[1]);
    const days = Math.round((target - today) / 86400000);
    return ctx.reply(days === 0 ? '🎉 C’est aujourd’hui !' : days < 0 ? `📅 C’était il y a ${-days} jour(s).` : `📅 Plus que <b>${days}</b> jour(s) !`);
  }, { aliases: ['countdown'] }),
  U('imc', 'indice de masse corporelle (/imc 70 175)', (ctx) => {
    const [kg, cm] = ctx.argv.map((x) => parseFloat(x.replace(',', '.')));
    if (!(kg > 0) || !(cm > 0)) return ctx.reply('Usage : /imc poids(kg) taille(cm) — ex : /imc 70 175');
    const v = kg / ((cm / 100) ** 2);
    const c = v < 18.5 ? 'insuffisance pondérale' : v < 25 ? 'corpulence normale' : v < 30 ? 'surpoids' : 'obésité';
    return ctx.reply(`⚖️ IMC : <b>${v.toFixed(1)}</b> (${c})\n<i>Indicateur général, pas un avis médical.</i>`);
  }, { aliases: ['bmi'] }),
  U('pourcent', 'calcul de pourcentage (/pourcent 20 de 150)', (ctx) => {
    const m = ctx.args.match(/^([\d.,]+)\s*%?\s*(?:de|of)\s*([\d.,]+)$/i);
    if (!m) return ctx.reply('Usage : /pourcent 20 de 150');
    const a = parseFloat(m[1].replace(',', '.')); const b = parseFloat(m[2].replace(',', '.'));
    return ctx.reply(`📊 ${fmtNum(a)} % de ${fmtNum(b)} = <b>${fmtNum((a * b) / 100)}</b>`);
  }, { aliases: ['percent'] }),
  U('couleur', 'infos sur une couleur (/couleur #ff8800)', (ctx) => {
    const m = ctx.args.replace('#', '').match(/^([0-9a-f]{6})$/i);
    if (!m) return ctx.reply('Usage : /couleur #ff8800');
    const [r, g, b] = [0, 2, 4].map((i) => parseInt(m[1].slice(i, i + 2), 16));
    const mx = Math.max(r, g, b) / 255; const mn = Math.min(r, g, b) / 255; const l = (mx + mn) / 2;
    return ctx.reply(`🎨 <b>#${m[1].toUpperCase()}</b>\nRGB : ${r}, ${g}, ${b}\nLuminosité : ${Math.round(l * 100)} %`);
  }, { aliases: ['color'] }),
  U('qr', 'génère un QR code (/qr texte)', async (ctx) => {
    if (!ctx.args) return ctx.reply('Usage : /qr https://exemple.com');
    try { await ctx.media('photo', `https://api.qrserver.com/v1/create-qr-code/?size=500x500&margin=10&data=${enc(ctx.args.slice(0, 900))}`, { caption: '🔳 Ton QR code' }); } catch { await down(ctx); }
  }, { cooldown: 3000 }),
  U('meteo', 'météo d’une ville (/meteo Paris)', async (ctx) => {
    if (!ctx.args) return ctx.reply('Usage : /meteo Brazzaville');
    try {
      const g = await getJson(`https://geocoding-api.open-meteo.com/v1/search?name=${enc(ctx.args)}&count=1&language=fr`);
      const p = g?.results?.[0];
      if (!p) return ctx.reply('Je ne trouve pas cette ville 🤔');
      const w = await getJson(`https://api.open-meteo.com/v1/forecast?latitude=${p.latitude}&longitude=${p.longitude}&current=temperature_2m,apparent_temperature,relative_humidity_2m,wind_speed_10m,weather_code&timezone=auto`);
      const c = w.current;
      return ctx.reply(`🌍 <b>${esc(p.name)}${p.country ? `, ${esc(p.country)}` : ''}</b>\n${WMO[c.weather_code] || '🌡️ Météo'}\n🌡️ ${c.temperature_2m} °C (ressenti ${c.apparent_temperature} °C)\n💧 Humidité : ${c.relative_humidity_2m} %\n💨 Vent : ${c.wind_speed_10m} km/h`);
    } catch { return down(ctx); }
  }, { aliases: ['weather', 'meteo2'], cooldown: 3000 }),
  U('wiki', 'résumé Wikipédia (/wiki Napoléon)', async (ctx) => {
    if (!ctx.args) return ctx.reply('Usage : /wiki Napoléon');
    try {
      const s = await getJson(`https://fr.wikipedia.org/w/api.php?action=opensearch&search=${enc(ctx.args)}&limit=1&format=json`);
      const title = s?.[1]?.[0];
      if (!title) return ctx.reply('Aucun article trouvé 🤔');
      const d = await getJson(`https://fr.wikipedia.org/api/rest_v1/page/summary/${enc(title)}`);
      return ctx.reply(`📚 <b>${esc(d.title)}</b>\n${esc(truncate(d.extract || 'Pas de résumé.', 1200))}\n\n${esc(d.content_urls?.desktop?.page || '')}`);
    } catch { return down(ctx); }
  }, { aliases: ['wikipedia'], cooldown: 3000 }),
  U('traduire', 'traduction (/traduire en Bonjour tout le monde)', async (ctx) => {
    const m = ctx.args.match(/^([a-z]{2})(?:-[a-z]{2})?\s+([\s\S]+)$/i);
    const text = m ? m[2] : (ctx.msg.reply_to_message?.text || '');
    const lang = m ? m[1].toLowerCase() : (ctx.args.match(/^[a-z]{2}$/i)?.[0] || '').toLowerCase();
    if (!text || !lang) return ctx.reply('Usage : /traduire en Bonjour (code langue : en fr es de it pt ar ja zh ru…)\nOu réponds à un message avec /traduire en');
    try {
      const d = await getJson(`https://api.mymemory.translated.net/get?q=${enc(text.slice(0, 450))}&langpair=Autodetect|${lang}`);
      const t = d?.responseData?.translatedText;
      if (!t || d.responseStatus >= 400) return ctx.reply('Traduction impossible (langue non reconnue ?) 🤔');
      return ctx.reply(`🌐 ${esc(t)}`);
    } catch { return down(ctx); }
  }, { aliases: ['translate', 'tr'], cooldown: 3000 }),
  U('devise', 'conversion de devises (/devise 10 usd eur)', async (ctx) => {
    const m = ctx.args.match(/^([\d.,]+)\s*([a-z]{3})\s+(?:en|to|vers)?\s*([a-z]{3})$/i);
    if (!m) return ctx.reply('Usage : /devise 10 usd eur (ex : XAF, EUR, USD, GBP, NGN, MAD…)');
    const amount = parseFloat(m[1].replace(',', '.')); const from = m[2].toUpperCase(); const to = m[3].toUpperCase();
    try {
      const d = await getJson(`https://open.er-api.com/v6/latest/${from}`);
      const rate = d?.rates?.[to];
      if (!rate) return ctx.reply('Devise inconnue 🤔');
      return ctx.reply(`💱 ${fmtNum(amount)} ${from} = <b>${fmtNum(amount * rate)} ${to}</b>\n<i>1 ${from} = ${fmtNum(rate)} ${to}</i>`);
    } catch { return down(ctx); }
  }, { aliases: ['currency', 'change'], cooldown: 3000 }),
  U('crypto', 'prix d’une crypto (/crypto btc)', async (ctx) => {
    const id = COINS[normalize(ctx.args || 'btc')];
    if (!id) return ctx.reply(`Crypto non gérée. Essaie : ${Object.keys(COINS).join(', ')}`);
    try {
      const d = await getJson(`https://api.coingecko.com/api/v3/simple/price?ids=${id}&vs_currencies=eur,usd&include_24hr_change=true`);
      const r = d?.[id];
      if (!r) return down(ctx);
      return ctx.reply(`🪙 <b>${esc(id)}</b>\n${fmtNum(r.usd)} $ · ${fmtNum(r.eur)} €\n24 h : ${r.usd_24h_change >= 0 ? '📈 +' : '📉 '}${r.usd_24h_change?.toFixed(2)} %`);
    } catch { return down(ctx); }
  }, { aliases: ['bitcoin', 'btc'], cooldown: 4000 }),
  U('pokemon', 'fiche Pokémon (/pokemon pikachu)', async (ctx) => {
    if (!ctx.args) return ctx.reply('Usage : /pokemon pikachu');
    try {
      const d = await getJson(`https://pokeapi.co/api/v2/pokemon/${enc(ctx.args.toLowerCase().trim())}`);
      const caption = `⚡ <b>${esc(d.name)}</b> #${d.id}\nType : ${d.types.map((t) => t.type.name).join(', ')}\nTaille : ${d.height / 10} m · Poids : ${d.weight / 10} kg\n${d.stats.map((s) => `${s.stat.name}: ${s.base_stat}`).join(' · ')}`;
      const img = d.sprites?.other?.['official-artwork']?.front_default || d.sprites?.front_default;
      if (img) { try { await ctx.media('photo', img, { caption }); return null; } catch { /* texte */ } }
      return ctx.reply(caption);
    } catch (e) { return e.status === 404 ? ctx.reply('Pokémon introuvable 🤔') : down(ctx); }
  }, { cooldown: 3000 }),
  U('anime', 'infos sur un anime (/anime Naruto)', async (ctx) => {
    if (!ctx.args) return ctx.reply('Usage : /anime Naruto');
    try {
      const d = await getJson(`https://api.jikan.moe/v4/anime?q=${enc(ctx.args)}&limit=1&sfw=true`, { timeout: 12000 });
      const a = d?.data?.[0];
      if (!a) return ctx.reply('Aucun anime trouvé 🤔');
      const caption = `🎌 <b>${esc(a.title)}</b>\n⭐ ${a.score ?? '?'} · ${a.episodes ?? '?'} épisodes · ${esc(a.status || '')}\n${esc(truncate(a.synopsis || '', 600))}`;
      const img = a.images?.jpg?.large_image_url;
      if (img) { try { await ctx.media('photo', img, { caption: truncate(caption, 1000) }); return null; } catch { /* texte */ } }
      return ctx.reply(caption);
    } catch { return down(ctx); }
  }, { cooldown: 4000 }),
  U('sondage', 'crée un sondage (/sondage Question ; A ; B ; C)', async (ctx) => {
    const p = ctx.args.split(';').map((s) => s.trim()).filter(Boolean);
    if (p.length < 3) return ctx.reply('Usage : /sondage Quelle pizza ? ; Margherita ; Reine ; 4 fromages');
    await ctx.tg.call('sendPoll', { chat_id: ctx.chat.id, question: p[0].slice(0, 300), options: p.slice(1, 11).map((o) => o.slice(0, 100)), is_anonymous: false, ...(ctx.thread ? { message_thread_id: ctx.thread } : {}) });
  }, { aliases: ['poll'] }),
  U('password', 'mot de passe aléatoire (/password 16)', async (ctx) => {
    const { randInt } = await import('../util.js');
    const n = clamp(parseInt(ctx.args, 10) || 16, 6, 64);
    const cs = 'ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz23456789!@#$%&*-_';
    return ctx.reply(`🔐 <code>${esc(Array.from({ length: n }, () => cs[randInt(0, cs.length - 1)]).join(''))}</code>`);
  }, { aliases: ['mdp', 'pass'] }),
  U('uuid', 'génère un UUID', async (ctx) => { const { randomUUID } = await import('node:crypto'); return ctx.reply(`<code>${randomUUID()}</code>`); }),
];
export default defs;
