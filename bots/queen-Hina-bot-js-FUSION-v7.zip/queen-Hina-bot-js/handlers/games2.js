// Nouveaux jeux : blackjack (solo, boutons, mise), puissance 4 (à 2, boutons), roue de la fortune (mise).
// Les parties vivent en mémoire et expirent seules. Callbacks : "b:" = blackjack, "p:" = puissance 4.
import * as store from '../store.js';
import { esc, shuffle, randInt, clamp, fmtNum, userName } from '../util.js';
import { addXp } from '../perks.js';

const TTL = 15 * 60 * 1000;
const rid = () => Math.random().toString(36).slice(2, 8);
const answer = (tg, cq, text) => tg.call('answerCallbackQuery', { callback_query_id: cq.id, ...(text ? { text: String(text).slice(0, 190) } : {}) }, { retries: 1, timeout: 8000 }).catch(() => {});
const nm = (u) => esc(userName(u));
const brief = (u) => ({ id: u.id, first_name: u.first_name || u.name || 'Joueur', username: u.username });
const parseBet = (arg, dflt = 50) => {
  const n = arg === undefined ? dflt : parseInt(arg, 10);
  return Number.isFinite(n) ? clamp(n, 10, 5000) : null;
};

// ============================ BLACKJACK ============================
const BJ = new Map();
const SUITS = ['♠️', '♥️', '♦️', '♣️'];
const RANKS = ['A', '2', '3', '4', '5', '6', '7', '8', '9', '10', 'J', 'Q', 'K'];
const deck = () => shuffle(SUITS.flatMap((s) => RANKS.map((r) => ({ r, s }))));
const show = (hand) => hand.map((c) => `${c.r}${c.s}`).join(' ');
export function handValue(hand) {
  let t = 0; let aces = 0;
  for (const c of hand) {
    if (c.r === 'A') { aces += 1; t += 11; } else if ('JQK'.includes(c.r)) t += 10; else t += parseInt(c.r, 10);
  }
  while (t > 21 && aces > 0) { t -= 10; aces -= 1; }
  return t;
}
const isBj = (h) => h.length === 2 && handValue(h) === 21;
const bjKb = (g, canDouble) => ({ inline_keyboard: [[
  { text: '🃏 Tirer', callback_data: `b:${g.id}:h` },
  { text: '✋ Rester', callback_data: `b:${g.id}:s` },
  ...(canDouble ? [{ text: '✖️2 Doubler', callback_data: `b:${g.id}:d` }] : []),
]] });
function bjText(g, reveal, footer = '') {
  const dealer = reveal ? `${show(g.dealer)}  (<b>${handValue(g.dealer)}</b>)` : `${g.dealer[0].r}${g.dealer[0].s} 🂠`;
  return `🃏 <b>Blackjack</b> — mise : <b>${fmtNum(g.bet)}</b> 🪙\n\n🎩 Croupier : ${dealer}\n👤 ${nm(g.user)} : ${show(g.hand)}  (<b>${handValue(g.hand)}</b>)${footer ? `\n\n${footer}` : ''}`;
}
function bjFinish(g, tg) {
  clearTimeout(g.timer); BJ.delete(g.id);
  while (handValue(g.dealer) < 17) g.dealer.push(g.cards.pop());
  const p = handValue(g.hand); const d = handValue(g.dealer);
  let payout = 0; let verdict;
  if (p > 21) verdict = '💥 Tu dépasses 21… perdu !';
  else if (isBj(g.hand) && !isBj(g.dealer)) { payout = Math.floor(g.bet * 2.5); verdict = '🎉 <b>BLACKJACK !</b> (paie 3:2)'; }
  else if (d > 21) { payout = g.bet * 2; verdict = '🎉 Le croupier dépasse 21, tu gagnes !'; }
  else if (p > d) { payout = g.bet * 2; verdict = '🎉 Tu gagnes !'; }
  else if (p === d) { payout = g.bet; verdict = '🤝 Égalité : mise rendue.'; }
  else verdict = '😬 Le croupier gagne.';
  if (payout) store.earn(g.user.id, payout);
  if (payout > g.bet) addXp(g.user.id, 10);
  const net = payout - g.bet;
  const foot = `${verdict}\n${net > 0 ? `+${fmtNum(net)}` : net < 0 ? `−${fmtNum(-net)}` : '±0'} 🪙 — solde : ${store.coinsText(g.user.id)}`;
  return tg.editText(g.chatId, g.msgId, bjText(g, true, foot), { reply_markup: { inline_keyboard: [] } }).catch((e) => console.warn('[bj] edit:', e.message));
}
export async function handleBjCallback(tg, cq) {
  const [, id, act] = String(cq.data || '').split(':');
  const g = BJ.get(id);
  if (!g || !cq.message || cq.message.chat.id !== g.chatId) return answer(tg, cq, 'Cette partie est terminée.');
  if (cq.from.id !== g.user.id) return answer(tg, cq, 'Ce n’est pas ta partie 😉');
  g.until = Date.now() + TTL;
  if (act === 'h') {
    g.hand.push(g.cards.pop());
    if (handValue(g.hand) >= 21) await bjFinish(g, tg);
    else await tg.editText(g.chatId, g.msgId, bjText(g, false), { reply_markup: bjKb(g, false) }).catch(() => {});
  } else if (act === 's') {
    await bjFinish(g, tg);
  } else if (act === 'd') {
    if (g.hand.length !== 2) return answer(tg, cq, 'Doubler n’est possible qu’au premier tour.');
    if (!store.spend(g.user.id, g.bet)) return answer(tg, cq, 'Pas assez de pièces pour doubler 😅');
    g.bet *= 2; g.hand.push(g.cards.pop());
    await bjFinish(g, tg);
  }
  return answer(tg, cq);
}

// ============================ PUISSANCE 4 ============================
const P4 = new Map();
const ROWS = 6; const COLS = 7;
const P4_EMOJI = { R: '🔴', Y: '🟡', '': '⚪' };
const p4Board = (b) => b.map((row) => row.map((c) => P4_EMOJI[c]).join('')).join('\n') + '\n1️⃣2️⃣3️⃣4️⃣5️⃣6️⃣7️⃣';
export function p4Winner(b) {
  const dirs = [[0, 1], [1, 0], [1, 1], [1, -1]];
  for (let r = 0; r < ROWS; r += 1) for (let c = 0; c < COLS; c += 1) {
    const v = b[r][c]; if (!v) continue;
    for (const [dr, dc] of dirs) {
      let k = 1;
      while (k < 4) { const rr = r + dr * k; const cc = c + dc * k; if (rr < 0 || rr >= ROWS || cc < 0 || cc >= COLS || b[rr][cc] !== v) break; k += 1; }
      if (k === 4) return v;
    }
  }
  return null;
}
const p4Kb = (g) => ({ inline_keyboard: [Array.from({ length: COLS }, (_, i) => ({ text: String(i + 1), callback_data: `p:${g.id}:${i}` }))] });
function p4View(g, over) {
  const head = `🔴 ${nm(g.red)}  vs  🟡 ${g.yellow ? nm(g.yellow) : '<i>en attente…</i>'}`;
  const status = over || (g.yellow ? `Au tour de ${g.turn === 'R' ? '🔴' : '🟡'} <b>${nm(g.turn === 'R' ? g.red : g.yellow)}</b>` : 'Un adversaire ? Appuie sur une colonne pour rejoindre !');
  return { text: `🔴🟡 <b>Puissance 4</b>\n${head}\n\n${p4Board(g.board)}\n\n${status}`, markup: over ? { inline_keyboard: [] } : p4Kb(g) };
}
const p4Edit = (g, tg, v) => tg.editText(g.chatId, g.msgId, v.text, { reply_markup: v.markup }).catch((e) => console.warn('[p4] edit:', e.message));
export async function handleP4Callback(tg, cq) {
  const [, id, arg] = String(cq.data || '').split(':');
  const g = P4.get(id);
  if (!g || !cq.message || cq.message.chat.id !== g.chatId) return answer(tg, cq, 'Cette partie est terminée ou a expiré.');
  const u = cq.from; const col = parseInt(arg, 10);
  if (!g.yellow) {
    if (u.id === g.red.id) return answer(tg, cq, 'Attends qu’un adversaire appuie sur une colonne 😉');
    if (g.want && g.want !== u.id) return answer(tg, cq, 'Cette partie est réservée à quelqu’un d’autre.');
    g.yellow = brief(u); g.until = Date.now() + TTL;
    await p4Edit(g, tg, p4View(g));
    return answer(tg, cq, 'Tu joues les 🟡 ! 🔴 commence.');
  }
  if (u.id !== g.red.id && u.id !== g.yellow.id) return answer(tg, cq, 'Cette partie oppose deux autres joueurs 😉');
  const cur = g.turn === 'R' ? g.red : g.yellow;
  if (u.id !== cur.id) return answer(tg, cq, 'Ce n’est pas ton tour !');
  if (!(col >= 0 && col < COLS)) return answer(tg, cq);
  let row = -1;
  for (let r = ROWS - 1; r >= 0; r -= 1) if (!g.board[r][col]) { row = r; break; }
  if (row < 0) return answer(tg, cq, 'Cette colonne est pleine.');
  g.board[row][col] = g.turn; g.until = Date.now() + TTL;
  const w = p4Winner(g.board);
  if (w) {
    const win = w === 'R' ? g.red : g.yellow; store.earn(win.id, 50); addXp(win.id, 20); P4.delete(g.id);
    await p4Edit(g, tg, p4View(g, `🏆 <b>${nm(win)}</b> gagne ! +50 🪙`));
  } else if (g.board[0].every(Boolean)) {
    store.earn(g.red.id, 10); store.earn(g.yellow.id, 10); P4.delete(g.id);
    await p4Edit(g, tg, p4View(g, '🤝 Grille pleine, match nul ! +10 🪙 chacun'));
  } else {
    g.turn = g.turn === 'R' ? 'Y' : 'R';
    await p4Edit(g, tg, p4View(g));
  }
  return answer(tg, cq);
}

setInterval(() => {
  const now = Date.now();
  for (const [k, g] of BJ) if (g.until < now) { clearTimeout(g.timer); BJ.delete(k); }
  for (const [k, g] of P4) if (g.until < now) P4.delete(k);
}, 60000).unref();

// ============================ ROUE ============================
const WHEEL = [
  { x: 0, w: 30, t: '💀 Banqueroute' }, { x: 0.5, w: 20, t: '😬 Moitié perdue' }, { x: 1, w: 20, t: '😌 Remboursé' },
  { x: 1.5, w: 14, t: '😊 ×1,5' }, { x: 2, w: 9, t: '🎉 ×2' }, { x: 3, w: 5, t: '🤩 ×3' }, { x: 5, w: 2, t: '💎 JACKPOT ×5' },
];
function spin() {
  let r = randInt(1, 100);
  for (const s of WHEEL) { r -= s.w; if (r <= 0) return s; }
  return WHEEL[0];
}

export const defs = [
  {
    name: 'blackjack', aliases: ['bj', '21'], cat: '🎮 Jeux', desc: 'blackjack contre le croupier (/blackjack 50)', cooldown: 4000,
    async run(ctx) {
      const bet = parseBet(ctx.argv[0]);
      if (bet === null) return ctx.reply('Usage : /blackjack 50 (mise de 10 à 5 000 🪙)');
      if ([...BJ.values()].some((g) => g.user.id === ctx.from.id && g.chatId === ctx.chat.id)) return ctx.reply('Tu as déjà une partie en cours ici 😉');
      if (!store.spend(ctx.from.id, bet)) return ctx.reply('Tu n’as pas assez de pièces pour cette mise 😅');
      const cards = deck();
      const g = { id: rid(), chatId: ctx.chat.id, user: brief(ctx.from), bet, cards, hand: [cards.pop(), cards.pop()], dealer: [cards.pop(), cards.pop()], until: Date.now() + TTL, tg: ctx.tg };
      BJ.set(g.id, g);
      if (isBj(g.hand) || isBj(g.dealer)) {
        const m = await ctx.say(bjText(g, true, '…'));
        g.msgId = m?.message_id; await bjFinish(g, ctx.tg);
        return;
      }
      const m = await ctx.say(bjText(g, false), { reply_markup: bjKb(g, true) });
      g.msgId = m?.message_id;
      // sans action pendant 3 minutes : on reste automatiquement (jamais de mise perdue dans le vide)
      g.timer = setTimeout(() => { if (BJ.has(g.id)) bjFinish(g, ctx.tg).catch(() => {}); }, 3 * 60 * 1000);
      g.timer.unref?.();
    },
  },
  {
    name: 'puissance4', aliases: ['p4', 'connect4'], cat: '🎲 Multijoueur', group: true, desc: 'puissance 4 à deux (réponds à quelqu’un pour le défier)', cooldown: 4000,
    async run(ctx) {
      if ([...P4.values()].some((g) => g.chatId === ctx.chat.id)) return ctx.reply('Une partie de puissance 4 est déjà en cours ici !');
      const g = { id: rid(), chatId: ctx.chat.id, red: brief(ctx.from), yellow: null, want: ctx.target?.id || null, turn: 'R', board: Array.from({ length: ROWS }, () => Array(COLS).fill('')), until: Date.now() + TTL };
      P4.set(g.id, g);
      const v = p4View(g);
      const m = await ctx.say(v.text, { reply_markup: v.markup });
      g.msgId = m?.message_id;
    },
  },
  {
    name: 'roue', aliases: ['wheel', 'fortune'], cat: '🎮 Jeux', desc: 'roue de la fortune (/roue 50) : de ×0 à ×5', cooldown: 4000,
    async run(ctx) {
      const bet = parseBet(ctx.argv[0]);
      if (bet === null) return ctx.reply('Usage : /roue 50 (mise de 10 à 5 000 🪙)');
      if (!store.spend(ctx.from.id, bet)) return ctx.reply('Tu n’as pas assez de pièces pour cette mise 😅');
      const s = spin(); const back = Math.floor(bet * s.x);
      if (back) store.earn(ctx.from.id, back);
      const net = back - bet;
      return ctx.reply(`🎡 La roue tourne…\n\n<b>${s.t}</b>\n${net > 0 ? `+${fmtNum(net)}` : net < 0 ? `−${fmtNum(-net)}` : '±0'} 🪙 — solde : ${store.coinsText(ctx.from.id)}`);
    },
  },
];
export default defs;
