// Soutenir le créateur avec des étoiles Telegram (⭐ Stars, devise XTR). Aucun fournisseur de paiement à configurer.
import { OWNER_IDS, OWNER_NAME, BOT_NAME } from '../config.js';
import * as store from '../store.js';
import { esc, fmtNum, mentionHtml } from '../util.js';
import { grantAccess, revokeAccess } from './access.js';

const AMOUNTS = [10, 25, 50, 100, 250, 500];
const MAX = 10000;
const stars = () => (store.db.stars && typeof store.db.stars === 'object' ? store.db.stars : (store.db.stars = { total: 0, donors: {}, payments: [] }));

function keyboard() {
  const rows = [];
  for (let i = 0; i < AMOUNTS.length; i += 3) rows.push(AMOUNTS.slice(i, i + 3).map((n) => ({ text: `⭐ ${n}`, callback_data: `s:${n}` })));
  return { inline_keyboard: rows };
}

export async function sendStarsInvoice(tg, chatId, userId, amount, thread) {
  const n = Math.min(Math.max(Math.floor(amount), 1), MAX);
  return tg.call('sendInvoice', {
    chat_id: chatId,
    title: `Soutenir ${BOT_NAME} ⭐`,
    description: `Merci de soutenir ${OWNER_NAME} et le bot avec ${n} étoile${n > 1 ? 's' : ''} Telegram 💖`,
    payload: `support:${userId}:${n}`,
    currency: 'XTR',
    prices: [{ label: `Soutien (${n} ⭐)`, amount: n }],
    ...(thread ? { message_thread_id: thread } : {}),
  }, { retries: 2, timeout: 15000 });
}

export async function handleSupportCallback(tg, cq) {
  try { await tg.call('answerCallbackQuery', { callback_query_id: cq.id }, { retries: 1, timeout: 8000 }); } catch { /* ignore */ }
  const n = parseInt(String(cq.data || '').slice(2), 10);
  const msg = cq.message;
  if (!Number.isFinite(n) || n < 1 || n > MAX || !msg) return;
  try {
    await sendStarsInvoice(tg, msg.chat.id, cq.from.id, n, msg.is_topic_message ? msg.message_thread_id : undefined);
  } catch (e) {
    console.warn('[stars] invoice:', e.message);
    await tg.sendMessage(msg.chat.id, 'Je n’arrive pas à créer la facture pour le moment 🙏 Réessaie dans un instant.').catch(() => {});
  }
}

export async function onPreCheckout(tg, q) {
  const pl = String(q.invoice_payload || '');
  const ok = q.currency === 'XTR' && (pl.startsWith('support:') || pl.startsWith('access:'));
  try {
    await tg.call('answerPreCheckoutQuery', ok ? { pre_checkout_query_id: q.id, ok: true } : { pre_checkout_query_id: q.id, ok: false, error_message: 'Paiement non reconnu, réessaie depuis /soutenir.' }, { retries: 2, timeout: 8000 });
  } catch (e) { console.warn('[stars] pre_checkout:', e.message); }
}

export async function onPayment(tg, msg) {
  const p = msg.successful_payment;
  const s = stars();
  if (s.payments.some((x) => x.charge === p.telegram_payment_charge_id)) return; // déjà enregistré
  const amount = Number(p.total_amount) || 0;
  const u = msg.from || {};
  s.total += amount;
  const d = s.donors[u.id] || (s.donors[u.id] = { name: u.first_name || 'Anonyme', amount: 0 });
  d.name = u.first_name || d.name; d.amount += amount; d.last = Date.now();
  const isAccess = String(p.invoice_payload || '').startsWith('access:');
  const days = isAccess ? Math.min(365, Math.max(1, parseInt(String(p.invoice_payload).split(':')[3], 10) || 30)) : 0;
  s.payments.push({ uid: u.id, amount, charge: p.telegram_payment_charge_id, at: Date.now(), ...(isAccess ? { kind: 'access', days } : {}) });
  while (s.payments.length > 300) s.payments.shift();
  if (isAccess) {
    grantAccess(u.id, days);
    store.save();
    await tg.sendMessage(msg.chat.id, `✅ <b>Merci ${esc(u.first_name || '')} !</b> Ton accès au chat avec ${esc(BOT_NAME)} est activé pour <b>${days} jour${days > 1 ? 's' : ''}</b> 💬✨ Parle-moi, je t'écoute !`, { reply_to: msg.message_id });
    for (const id of OWNER_IDS) {
      tg.sendMessage(id, `⭐ <b>Accès au chat acheté !</b>\n${mentionHtml(u)} a payé <b>${amount} ⭐</b> (${days} j)\nTotal reçu : ${fmtNum(s.total)} ⭐\n<code>${esc(p.telegram_payment_charge_id)}</code>`).catch(() => {});
    }
    return;
  }
  store.econ(u.id).coins += amount * 10; // petit cadeau en pièces
  store.save();
  await tg.sendMessage(msg.chat.id, `💖 <b>Merci ${esc(u.first_name || '')} !</b>\nTon soutien de <b>${amount} ⭐</b> fait vraiment plaisir à ${esc(OWNER_NAME)} et me fait grandir ✨\nCadeau : +${amount * 10} 🪙`, { reply_to: msg.message_id });
  for (const id of OWNER_IDS) {
    tg.sendMessage(id, `⭐ <b>Nouveau soutien !</b>\n${mentionHtml(u)} t’a envoyé <b>${amount} ⭐</b>\nTotal reçu : ${fmtNum(s.total)} ⭐\n<code>${esc(p.telegram_payment_charge_id)}</code>`).catch(() => {});
  }
}

export const defs = [
  {
    name: 'soutenir', aliases: ['donate', 'stars', 'etoiles', 'soutien'], cat: '⭐ Soutien', cooldown: 3000,
    desc: 'soutenir mon créateur avec des étoiles Telegram',
    async run(ctx) {
      const n = parseInt(ctx.argv[0], 10);
      if (Number.isFinite(n)) {
        if (n < 1 || n > MAX) return ctx.reply(`Choisis un montant entre 1 et ${MAX} ⭐`);
        await sendStarsInvoice(ctx.tg, ctx.chat.id, ctx.from.id, n, ctx.thread);
        return null;
      }
      return ctx.reply(`⭐ <b>Soutenir ${esc(OWNER_NAME)}</b>\nSi ${esc(BOT_NAME)} te plaît, tu peux envoyer des étoiles Telegram pour encourager son créateur 💖\n\nChoisis un montant, ou tape <code>/soutenir 75</code> pour un montant libre :`, { reply_markup: keyboard() });
    },
  },
  {
    name: 'supporters', aliases: ['donateurs', 'topsoutien'], cat: '⭐ Soutien', desc: 'les plus généreux soutiens',
    run(ctx) {
      const s = stars();
      const rows = Object.values(s.donors).sort((a, b) => b.amount - a.amount).slice(0, 10);
      if (!rows.length) return ctx.reply('Personne n’a encore envoyé d’étoiles. Sois le premier avec /soutenir 💖');
      return ctx.reply(`💖 <b>Merci à mes soutiens</b>\n${rows.map((r, i) => `${['🥇', '🥈', '🥉'][i] || `${i + 1}.`} ${esc(r.name)} — ${fmtNum(r.amount)} ⭐`).join('\n')}${ctx.isOwner ? `\n\nTotal reçu : <b>${fmtNum(s.total)} ⭐</b>` : ''}`);
    },
  },
  {
    name: 'refundstar', cat: '⭐ Soutien', owner: true, desc: '(owner) rembourser un paiement (/refundstar ID_transaction)',
    async run(ctx) {
      const charge = ctx.argv[0];
      const pay = stars().payments.find((x) => x.charge === charge);
      if (!pay) return ctx.reply('Transaction introuvable. Usage : /refundstar <identifiant de transaction>');
      await ctx.tg.call('refundStarPayment', { user_id: pay.uid, telegram_payment_charge_id: charge });
      const s = stars(); s.total -= pay.amount; s.payments = s.payments.filter((x) => x.charge !== charge);
      if (s.donors[pay.uid]) s.donors[pay.uid].amount -= pay.amount;
      if (pay.kind === 'access') revokeAccess(pay.uid, pay.days || 0);
      store.save();
      return ctx.reply('✅ Paiement remboursé.');
    },
  },
];
export default defs;
