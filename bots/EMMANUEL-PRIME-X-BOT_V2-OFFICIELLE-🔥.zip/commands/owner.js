const U = require('../lib/utils')

const O = { owner: true, cat: 'owner' }
const use = (c, s) => c.reply(`ℹ️ Usage : ${c.prefix}${s}`)
const toggle = (name, key, label, desc) => ({
  name, ...O, desc, usage: `${name} on`,
  run: async (c) => {
    const v = U.onoff(c.args[0])
    if (v === null) return c.reply(`${label} : *${c.settings[key] ? 'ON' : 'OFF'}*\nUtilise ${c.prefix}${name} on/off`)
    c.settings[key] = v; c.saveSettings()
    await c.reply(`✅ ${label} : *${v ? 'activé' : 'désactivé'}*`)
  }
})

module.exports = [
  {
    name: 'mode', ...O, desc: 'public (tout le monde) ou self (toi seulement)', usage: 'mode self',
    run: async (c) => {
      const v = (c.args[0] || '').toLowerCase()
      if (!['public', 'self'].includes(v)) return c.reply(`⚙️ Mode actuel : *${c.settings.mode}*\nUtilise ${c.prefix}mode public ou ${c.prefix}mode self`)
      c.settings.mode = v; c.saveSettings()
      await c.reply(`✅ Mode *${v}* activé.`)
    }
  },
  {
    name: 'block', ...O, desc: 'Bloque un contact', usage: 'block @user',
    run: async (c) => {
      const t = await c.getTarget()
      if (!t) return use(c, 'block @user (ou réponds à un message)')
      await c.sock.updateBlockStatus(t, 'block')
      await c.reply(`🚫 @${U.num(t)} bloqué.`, { mentions: [t] })
    }
  },
  {
    name: 'unblock', ...O, desc: 'Débloque un contact', usage: 'unblock 242...',
    run: async (c) => {
      const t = await c.getTarget()
      if (!t) return use(c, 'unblock @user')
      await c.sock.updateBlockStatus(t, 'unblock')
      await c.reply(`✅ @${U.num(t)} débloqué.`, { mentions: [t] })
    }
  },
  {
    name: 'bc', aliases: ['broadcast'], ...O, desc: 'Message à tous les groupes du bot', usage: 'bc Annonce importante',
    run: async (c) => {
      if (!c.input) return use(c, 'bc <message>')
      const groups = Object.keys(await c.sock.groupFetchAllParticipating())
      await c.reply(`📣 Envoi à ${groups.length} groupe(s)...`)
      let ok = 0
      for (const g of groups) {
        try { await c.sock.sendMessage(g, { text: `📣 *ANNONCE*\n\n${c.input}\n\n${require('../config').botName}` }); ok++ } catch {}
        await U.sleep(2500)
      }
      await c.reply(`✅ Envoyé dans ${ok}/${groups.length} groupe(s).`)
    }
  },
  {
    name: 'join', ...O, desc: 'Fait rejoindre un groupe via lien', usage: 'join https://chat.whatsapp.com/...',
    run: async (c) => {
      const code = (c.input.match(/chat\.whatsapp\.com\/([A-Za-z0-9]{10,})/) || [])[1]
      if (!code) return use(c, 'join <lien d\'invitation>')
      await c.sock.groupAcceptInvite(code)
      await c.reply('✅ Groupe rejoint !')
    }
  },
  {
    name: 'leave', aliases: ['quit'], ...O, group: true, desc: 'Le bot quitte ce groupe',
    run: async (c) => { await c.reply('👋 Au revoir tout le monde !'); await U.sleep(1000); await c.sock.groupLeave(c.jid) }
  },
  {
    name: 'chreact', aliases: ['channelreact', 'reactch'], ...O, desc: 'Fait réagir tous les numéros connectés à un post de ta chaîne', usage: 'chreact <lien du post> [emojis]',
    run: async (c) => {
      if (!c.isMainOwner) return c.reply('⛔ Commande réservée au créateur du bot (numéro principal).')
      const S = require('../lib/session')
      const m = (c.args[0] || '').match(/whatsapp\.com\/channel\/([\w-]+)\/(\d+)/i)
      if (!m) return use(c, 'chreact https://whatsapp.com/channel/XXXX/123 [🔥❤️👍]\n(copie le lien du post : appui long sur le message de la chaîne › Copier le lien)')
      const given = [...c.args.slice(1).join(' ').matchAll(/\p{Extended_Pictographic}\uFE0F?/gu)].map((x) => x[0])
      const emojis = given.length ? given : ['❤️', '🔥', '👍', '😍', '🙏', '😂']
      const live = S.list().filter((x) => x.sock && x.status === 'open')
      if (!live.length) return c.reply('❌ Aucun numéro connecté.')
      let jid
      try { jid = (await live[0].sock.newsletterMetadata('invite', m[1])).id } catch (e) { return c.reply('❌ Chaîne introuvable : ' + e.message) }
      await c.reply(`⏳ ${live.length} numéro(s) vont réagir au post ${m[2]}... (réactions espacées pour rester naturelles)`)
      let ok = 0, ko = 0
      for (const x of live) {
        try { await x.sock.newsletterReactMessage(jid, m[2], U.pick(emojis)); ok++ } catch { ko++ }
        await U.sleep(U.rand(1500, 4000))
      }
      await c.reply(`✅ Réactions envoyées : ${ok}${ko ? `\n⚠️ Échecs : ${ko} (abonne d'abord ces numéros à la chaîne)` : ''}\n\nℹ️ Chaque numéro doit suivre ta chaîne pour que la réaction compte.`)
    }
  },
  {
    name: 'addsudo', ...O, desc: 'Donne les droits owner à un numéro', usage: 'addsudo @user',
    run: async (c) => {
      if (!c.isRealOwner) return c.reply('⛔ Seul le propriétaire peut ajouter un sudo.')
      const t = await c.getTarget()
      if (!t) return use(c, 'addsudo @user  (ou addsudo 242XXXXXXXXX)')
      const n = U.num(t)
      c.settings.sudo = c.settings.sudo || []
      if (c.settings.sudo.includes(n)) return c.reply(`ℹ️ @${n} est déjà sudo.`, { mentions: [t] })
      c.settings.sudo.push(n); c.saveSettings()
      await c.reply(`✅ @${n} est maintenant sudo (accès aux commandes owner).`, { mentions: [t] })
    }
  },
  {
    name: 'delsudo', ...O, desc: 'Retire les droits owner à un numéro', usage: 'delsudo @user',
    run: async (c) => {
      if (!c.isRealOwner) return c.reply('⛔ Seul le propriétaire peut retirer un sudo.')
      const t = await c.getTarget()
      if (!t) return use(c, 'delsudo @user  (ou delsudo 242XXXXXXXXX)')
      const n = U.num(t)
      const before = (c.settings.sudo || []).length
      c.settings.sudo = (c.settings.sudo || []).filter((x) => x !== n); c.saveSettings()
      await c.reply(before > c.settings.sudo.length ? `🗑️ @${n} n'est plus sudo.` : `ℹ️ @${n} n'était pas sudo.`, { mentions: [t] })
    }
  },
  {
    name: 'listsudo', aliases: ['sudolist'], ...O, desc: 'Liste des sudo',
    run: async (c) => {
      const l = c.settings.sudo || []
      await c.reply(l.length ? `👑 *Liste des sudo*\n\n${l.map((n, i) => `${i + 1}. @${n}`).join('\n')}` : '📭 Aucun sudo pour le moment.', { mentions: l.map(U.toJid) })
    }
  },
  toggle('autoread', 'autoread', '👀 Lecture automatique', 'Marque les messages comme lus automatiquement'),
  toggle('autoreact', 'autoreact', '🍫 Réaction automatique', 'Réagit automatiquement aux messages avec un emoji (🍫🍡🍥🍧🍿🍦🍨😁😋🌝💞🍂🍁🍩🌺♥️)'),
  toggle('anticall', 'anticall', '📵 Anti-appel', 'Rejette automatiquement les appels'),
  {
    name: 'ban', ...O, desc: "Interdit à quelqu'un d'utiliser le bot", usage: 'ban @user',
    run: async (c) => {
      const t = await c.getTarget()
      if (!t) return use(c, 'ban @user')
      const n = U.num(t)
      if (!c.settings.banned.includes(n)) c.settings.banned.push(n)
      c.saveSettings()
      await c.reply(`⛔ @${n} ne peut plus utiliser le bot.`, { mentions: [t] })
    }
  },
  {
    name: 'unban', ...O, desc: 'Autorise de nouveau un utilisateur', usage: 'unban @user',
    run: async (c) => {
      const t = await c.getTarget()
      if (!t) return use(c, 'unban @user')
      c.settings.banned = c.settings.banned.filter((x) => x !== U.num(t))
      c.saveSettings()
      await c.reply(`✅ @${U.num(t)} est de nouveau autorisé.`, { mentions: [t] })
    }
  },
  {
    name: 'restart', aliases: ['reboot'], ...O, desc: 'Redémarre la connexion WhatsApp du bot',
    run: async (c) => { await c.reply('🔄 Redémarrage de la connexion...'); require('../lib/session').restart(c.number).catch(() => {}) }
  },
  {
    name: 'setprefix', ...O, desc: 'Change le préfixe des commandes', usage: 'setprefix !',
    run: async (c) => {
      const p = c.args[0]
      if (!p || p.length > 2 || /[a-z0-9\s]/i.test(p)) return c.reply(`⚙️ Préfixe actuel : *${c.settings.prefix}*\nUtilise ${c.prefix}setprefix ! (1 ou 2 symboles)`)
      c.settings.prefix = p; c.saveSettings()
      await c.reply(`✅ Nouveau préfixe : *${p}*\nDésormais : ${p}menu`)
    }
  }
]
