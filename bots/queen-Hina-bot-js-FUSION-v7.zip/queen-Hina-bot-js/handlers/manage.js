// Gestion par le créateur : voir les profils de tous les utilisateurs et tous les groupes,
// bloquer / débloquer des utilisateurs, faire quitter un groupe au bot. Tout est réservé au propriétaire.
// Interface à boutons : callbacks "o:" (vérifiés : seul le propriétaire peut les utiliser).
import * as store from '../store.js';
import { isOwner, TIMEZONE } from '../config.js';
import { levelOf } from '../perks.js';
import { bondOf } from './persona.js';
import { accessUntil, cfg as premiumCfg } from './access.js';
import { esc, fmtNum, fmtDuration, truncate } from '../util.js';

const PAGE = 8;
const O = { cat: '👑 Propriétaire', owner: true };
const date = (ts) => (ts ? new Date(ts).toLocaleString('fr-FR', { timeZone: TIMEZONE, dateStyle: 'short', timeStyle: 'short' }) : '—');
const ago = (ts) => (ts ? `il y a ${fmtDuration(Math.max(1, (Date.now() - ts) / 1000))}` : '—');
const uname = (u) => esc(u?.name || 'Sans nom');
const blocked = (id) => store.isBlacklisted(id);

// ---------- utilisateurs ----------
const allUsers = () => Object.values(store.db.users).sort((a, b) => (b.last || 0) - (a.last || 0));
function findUser(q, ctx) {
  if (ctx?.target) return store.db.users[String(ctx.target.id)] || { id: ctx.target.id, name: ctx.target.first_name };
  const s = String(q || '').trim().replace(/^@/, '');
  if (!s) return null;
  if (/^-?\d+$/.test(s)) return store.db.users[s] || { id: Number(s), name: null };
  const low = s.toLowerCase();
  return allUsers().find((u) => (u.username || '').toLowerCase() === low) || allUsers().find((u) => (u.name || '').toLowerCase().includes(low)) || null;
}

function usersPage(page, filter = '') {
  let list = allUsers();
  if (filter) { const f = filter.toLowerCase(); list = list.filter((u) => `${u.name || ''} ${u.username || ''} ${u.id}`.toLowerCase().includes(f)); }
  const pages = Math.max(1, Math.ceil(list.length / PAGE));
  const p = Math.min(Math.max(0, page), pages - 1);
  const rows = list.slice(p * PAGE, p * PAGE + PAGE);
  const nBlocked = store.db.blacklist.length;
  const text = `👥 <b>Utilisateurs</b> (${list.length}${filter ? ` pour « ${esc(filter)} »` : ''}) · 🚫 ${nBlocked} bloqué(s)\nPage ${p + 1}/${pages} — appuie sur un nom pour voir son profil.`;
  const kb = rows.map((u) => [{ text: `${blocked(u.id) ? '🚫 ' : ''}${truncate(u.name || String(u.id), 22)}${u.username ? ` @${u.username}` : ''} · ${u.msgs || 0} msg`.slice(0, 60), callback_data: `o:u:${u.id}` }]);
  if (!filter && pages > 1) kb.push([{ text: '◀️', callback_data: `o:pu:${Math.max(0, p - 1)}` }, { text: `${p + 1}/${pages}`, callback_data: 'o:noop' }, { text: '▶️', callback_data: `o:pu:${Math.min(pages - 1, p + 1)}` }]);
  return { text: rows.length ? text : `${text}\n\n<i>Aucun résultat.</i>`, markup: { inline_keyboard: kb } };
}

function userCard(id) {
  const u = store.db.users[String(id)];
  const e = store.db.econ[String(id)] || {};
  const owner = isOwner(id);
  const groups = Object.values(store.db.chats).filter((c) => c.type !== 'private' && c.members?.[id]);
  const stars = store.db.stars?.donors?.[id];
  const access = accessUntil(id);
  const bond = bondOf(id);
  const lines = [
    `👤 <b>${esc(u?.name || 'Inconnu')}</b>${owner ? ' 👑' : ''}${blocked(id) ? ' 🚫 <b>BLOQUÉ</b>' : ''}`,
    `🆔 <code>${id}</code>${u?.username ? `  ·  @${esc(u.username)}` : ''}`,
    `📅 Première fois : ${date(u?.first)}`,
    `🕒 Dernière activité : ${date(u?.last)} (${ago(u?.last)})`,
    `💬 Messages : ${fmtNum(u?.msgs || 0)}`,
    `⭐ Niveau ${levelOf(e.xp || 0)} (${fmtNum(e.xp || 0)} XP) · ${bond.emoji} ${bond.name}`,
    `🪙 Pièces : ${owner ? '∞' : fmtNum(e.coins || 0)} · 🏦 Banque : ${owner ? '∞' : fmtNum(e.bank || 0)}`,
    `🧠 Souvenirs retenus : ${u?.memories?.length || 0}${u?.style ? ` · style ${esc(u.style)}` : ''}`,
  ];
  if (stars?.amount) lines.push(`💖 Étoiles données : ${fmtNum(stars.amount)} ⭐`);
  if (premiumCfg().enabled || access) lines.push(`🔒 Accès chat payant : ${access > Date.now() ? `actif encore ${fmtDuration((access - Date.now()) / 1000)}` : 'aucun'}`);
  lines.push(`🏘️ Groupes en commun : ${groups.length}${groups.length ? `\n${groups.slice(0, 5).map((c) => `   • ${esc(c.title || c.id)}`).join('\n')}${groups.length > 5 ? `\n   … +${groups.length - 5}` : ''}` : ''}`);
  const kb = [];
  if (!owner) kb.push([blocked(id) ? { text: '✅ Débloquer', callback_data: `o:ub:${id}` } : { text: '🚫 Bloquer', callback_data: `o:bl:${id}` }]);
  kb.push([{ text: '⬅️ Retour à la liste', callback_data: 'o:pu:0' }]);
  return { text: lines.join('\n'), markup: { inline_keyboard: kb } };
}

// ---------- groupes ----------
const allGroups = () => Object.values(store.db.chats).filter((c) => c.type !== 'private').sort((a, b) => lastActivity(b) - lastActivity(a));
const lastActivity = (c) => Math.max(0, ...Object.values(c.members || {}).map((m) => m.last || 0));
const totalMsgs = (c) => Object.values(c.members || {}).reduce((n, m) => n + (m.count || 0), 0);

function groupsPage(page) {
  const list = allGroups();
  const pages = Math.max(1, Math.ceil(list.length / PAGE));
  const p = Math.min(Math.max(0, page), pages - 1);
  const rows = list.slice(p * PAGE, p * PAGE + PAGE);
  const kb = rows.map((c) => [{ text: `🏘️ ${truncate(c.title || String(c.id), 30)} · ${Object.keys(c.members || {}).length} membres`.slice(0, 60), callback_data: `o:g:${c.id}` }]);
  if (pages > 1) kb.push([{ text: '◀️', callback_data: `o:pg:${Math.max(0, p - 1)}` }, { text: `${p + 1}/${pages}`, callback_data: 'o:noop' }, { text: '▶️', callback_data: `o:pg:${Math.min(pages - 1, p + 1)}` }]);
  const text = `🏘️ <b>Groupes</b> (${list.length})\nPage ${p + 1}/${pages} — appuie sur un groupe pour le voir.`;
  return { text: rows.length ? text : `${text}\n\n<i>Le bot n’est dans aucun groupe connu.</i>`, markup: { inline_keyboard: kb } };
}

async function groupCard(tg, id) {
  const c = store.db.chats[String(id)];
  if (!c) return { text: 'Groupe introuvable (déjà quitté ?).', markup: { inline_keyboard: [[{ text: '⬅️ Retour', callback_data: 'o:pg:0' }]] } };
  let count = null; let botAdmin = null;
  try { count = await tg.call('getChatMemberCount', { chat_id: c.id }, { retries: 0, timeout: 6000 }); } catch { /* le bot n'est peut-être plus dans le groupe */ }
  try { const m = await tg.call('getChatMember', { chat_id: c.id, user_id: tg.me.id }, { retries: 0, timeout: 6000 }); botAdmin = m.status === 'administrator'; } catch { /* ignore */ }
  const top = Object.entries(c.members || {}).sort((a, b) => (b[1].count || 0) - (a[1].count || 0)).slice(0, 3);
  const lines = [
    `🏘️ <b>${esc(c.title || 'Sans titre')}</b>`,
    `🆔 <code>${c.id}</code> · ${c.type === 'supergroup' ? 'supergroupe' : c.type === 'channel' ? 'canal' : 'groupe'}`,
    `👥 Membres : ${count ?? '?'} · connus du bot : ${Object.keys(c.members || {}).length}`,
    `💬 Messages vus : ${fmtNum(totalMsgs(c))}`,
    `🕒 Dernière activité : ${date(lastActivity(c))}`,
    `🛡️ Bot admin : ${botAdmin === null ? 'inconnu' : botAdmin ? 'oui' : 'non'}${c.settings?.muted ? ' · 🔇 muet' : ''}`,
  ];
  if (top.length) lines.push(`🏆 Plus actifs :\n${top.map(([, m], i) => `   ${['🥇', '🥈', '🥉'][i]} ${esc(m.name || '?')} (${m.count})`).join('\n')}`);
  return { text: lines.join('\n'), markup: { inline_keyboard: [[{ text: '🚪 Quitter ce groupe', callback_data: `o:lq:${c.id}` }], [{ text: '⬅️ Retour à la liste', callback_data: 'o:pg:0' }]] } };
}

async function leaveGroup(tg, id) {
  const c = store.db.chats[String(id)];
  try { await tg.call('leaveChat', { chat_id: c?.id ?? id }, { retries: 1, timeout: 10000 }); } catch (e) {
    if (!/not a member|kicked|not found|chat not found/i.test(e.description || e.message || '')) throw e;
  }
  delete store.db.chats[String(id)]; store.save();
  return c?.title || String(id);
}

function setBlocked(id, on) {
  const n = Number(id);
  if (isOwner(n)) return false;
  store.db.blacklist = store.db.blacklist.filter((x) => x !== n);
  if (on) store.db.blacklist.push(n);
  store.save();
  return true;
}

// ---------- callbacks ----------
export async function handleOwnerCallback(tg, cq) {
  const answer = (text) => tg.call('answerCallbackQuery', { callback_query_id: cq.id, ...(text ? { text: String(text).slice(0, 190), show_alert: false } : {}) }, { retries: 1, timeout: 8000 }).catch(() => {});
  if (!isOwner(cq.from.id)) return answer('Réservé à mon créateur 🔒');
  const msg = cq.message; if (!msg) return answer();
  const [, act, arg] = String(cq.data || '').split(':');
  const show = (v) => tg.editText(msg.chat.id, msg.message_id, v.text, { reply_markup: v.markup }).catch((e) => { if (!/not modified/i.test(e.message || '')) console.warn('[manage] edit:', e.message); });
  try {
    if (act === 'noop') return answer();
    if (act === 'pu') await show(usersPage(parseInt(arg, 10) || 0));
    else if (act === 'pg') await show(groupsPage(parseInt(arg, 10) || 0));
    else if (act === 'u') await show(userCard(arg));
    else if (act === 'bl') { if (!setBlocked(arg, true)) return answer('Impossible de bloquer un créateur.'); await show(userCard(arg)); return answer('🚫 Utilisateur bloqué'); }
    else if (act === 'ub') { setBlocked(arg, false); await show(userCard(arg)); return answer('✅ Utilisateur débloqué'); }
    else if (act === 'g') await show(await groupCard(tg, arg));
    else if (act === 'lq') {
      const c = store.db.chats[String(arg)];
      await show({ text: `🚪 Faire quitter <b>${esc(c?.title || arg)}</b> au bot ?\nTu pourras le réinviter plus tard.`, markup: { inline_keyboard: [[{ text: '✅ Oui, quitter', callback_data: `o:ly:${arg}` }, { text: '❌ Non', callback_data: `o:g:${arg}` }]] } });
    } else if (act === 'ly') {
      const title = await leaveGroup(tg, arg);
      await show({ text: `🚪 J’ai quitté <b>${esc(title)}</b>.`, markup: { inline_keyboard: [[{ text: '⬅️ Retour aux groupes', callback_data: 'o:pg:0' }]] } });
      return answer('Groupe quitté');
    }
  } catch (e) { console.warn('[manage]', e.message); return answer('Oups, une erreur est survenue.'); }
  return answer();
}

// ---------- commandes ----------
export const defs = [
  {
    ...O, name: 'utilisateurs', aliases: ['allusers', 'listeusers', 'membresbot'], desc: 'liste de tous les utilisateurs du bot (/utilisateurs [recherche])', cooldown: 2000,
    run(ctx) { const v = usersPage(0, ctx.args); return ctx.reply(v.text, { reply_markup: v.markup }); },
  },
  {
    ...O, name: 'voiruser', aliases: ['userinfo', 'uinfo', 'inspecter'], desc: 'profil complet d’un utilisateur (réponds, ID, @pseudo ou nom)', cooldown: 2000,
    run(ctx) {
      const u = findUser(ctx.args, ctx);
      if (!u) return ctx.reply('Usage : /voiruser 123456, /voiruser @pseudo, un nom, ou réponds à son message.');
      const v = userCard(u.id); return ctx.reply(v.text, { reply_markup: v.markup });
    },
  },
  {
    ...O, name: 'groupes', aliases: ['allgroups', 'mesgroupes', 'listegroupes'], desc: 'liste de tous les groupes où est le bot', cooldown: 2000,
    run(ctx) { const v = groupsPage(0); return ctx.reply(v.text, { reply_markup: v.markup }); },
  },
  {
    ...O, name: 'voirgroupe', aliases: ['gview', 'infogroupe'], desc: 'fiche d’un groupe (/voirgroupe ID ou nom)', cooldown: 2000,
    async run(ctx) {
      const q = ctx.args.trim().toLowerCase();
      const g = (ctx.isGroup && !q) ? store.db.chats[String(ctx.chat.id)] : (store.db.chats[q] || allGroups().find((c) => (c.title || '').toLowerCase().includes(q)));
      if (!g) return ctx.reply('Usage : /voirgroupe -100123456 ou une partie du nom (voir /groupes).');
      const v = await groupCard(ctx.tg, g.id); return ctx.reply(v.text, { reply_markup: v.markup });
    },
  },
  {
    ...O, name: 'bloquer', aliases: ['block', 'ban_bot'], desc: 'bloquer un utilisateur : le bot l’ignore (réponds, ID, @pseudo)', cooldown: 1500,
    run(ctx) {
      const u = findUser(ctx.args, ctx);
      if (!u) return ctx.reply('Usage : réponds à la personne, ou /bloquer 123456 ou /bloquer @pseudo');
      if (!setBlocked(u.id, true)) return ctx.reply('👑 Tu ne peux pas bloquer un créateur.');
      return ctx.reply(`🚫 <b>${uname(u)}</b> (<code>${u.id}</code>) est maintenant bloqué : je l’ignore complètement.`, { reply_markup: { inline_keyboard: [[{ text: '✅ Débloquer', callback_data: `o:ub:${u.id}` }]] } });
    },
  },
  {
    ...O, name: 'debloquer', aliases: ['unblock'], desc: 'débloquer un utilisateur (réponds, ID, @pseudo)', cooldown: 1500,
    run(ctx) {
      const u = findUser(ctx.args, ctx);
      if (!u) return ctx.reply('Usage : réponds à la personne, ou /debloquer 123456 ou /debloquer @pseudo (voir /bloques)');
      const was = blocked(u.id); setBlocked(u.id, false);
      return ctx.reply(was ? `✅ <b>${uname(u)}</b> (<code>${u.id}</code>) est débloqué.` : `ℹ️ <b>${uname(u)}</b> n’était pas bloqué.`);
    },
  },
  {
    ...O, name: 'bloques', aliases: ['blocked', 'listebloques'], desc: 'liste des utilisateurs bloqués',
    run(ctx) {
      if (!store.db.blacklist.length) return ctx.reply('✅ Aucun utilisateur bloqué.');
      const kb = store.db.blacklist.slice(0, 40).map((id) => [{ text: `✅ Débloquer ${truncate(store.db.users[String(id)]?.name || String(id), 24)}`, callback_data: `o:ub:${id}` }]);
      return ctx.reply(`🚫 <b>Utilisateurs bloqués</b> (${store.db.blacklist.length})\n${store.db.blacklist.slice(0, 40).map((id) => `• ${esc(store.db.users[String(id)]?.name || '?')} — <code>${id}</code>`).join('\n')}`, { reply_markup: { inline_keyboard: kb } });
    },
  },
  {
    ...O, name: 'quitter', aliases: ['leavegroup', 'sortir'], desc: 'faire quitter un groupe au bot (/quitter ID ou nom)', cooldown: 3000,
    async run(ctx) {
      const q = ctx.args.trim().toLowerCase();
      const g = !q ? null : (store.db.chats[q] || allGroups().find((c) => (c.title || '').toLowerCase().includes(q)));
      if (!g) return ctx.reply('Usage : /quitter -100123456 ou une partie du nom du groupe (voir /groupes).');
      return ctx.reply(`🚪 Faire quitter <b>${esc(g.title || g.id)}</b> au bot ?`, { reply_markup: { inline_keyboard: [[{ text: '✅ Oui, quitter', callback_data: `o:ly:${g.id}` }, { text: '❌ Non', callback_data: 'o:noop' }]] } });
    },
  },
];
export default defs;
