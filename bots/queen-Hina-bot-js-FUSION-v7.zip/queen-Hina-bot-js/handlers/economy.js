import * as store from '../store.js';
import { isOwner } from '../config.js';
import { eco, addXp } from '../perks.js';
import { esc, fmtDuration, mentionHtml, randInt, fmtNum, userName } from '../util.js';

const DAY = 86400000;

export const defs = [
  {
    name: 'daily', aliases: ['quotidien', 'bonus'], cat: '🪙 Économie', desc: 'récompense quotidienne',
    run(ctx) {
      if (ctx.isOwner) return ctx.reply('👑 Créateur : tes pièces sont illimitées ♾️');
      const e = store.econ(ctx.from.id); const now = Date.now();
      if (now - e.lastDaily < DAY) return ctx.reply(`⏳ Reviens dans <b>${fmtDuration((DAY - (now - e.lastDaily)) / 1000)}</b> !`);
      e.streak = now - e.lastDaily < 2 * DAY ? e.streak + 1 : 1;
      const gain = 100 + Math.min(e.streak, 10) * 10;
      e.coins += gain; e.lastDaily = now; store.save(); addXp(ctx.from.id, 25);
      return ctx.reply(`🎁 +<b>${gain}</b> 🪙 (série de ${e.streak} jour(s)) — solde : ${fmtNum(e.coins)}`);
    },
  },
  {
    name: 'work', aliases: ['travail', 'bosser'], cat: '🪙 Économie', desc: 'travaille pour gagner des pièces (toutes les heures)',
    run(ctx) {
      if (ctx.isOwner) return ctx.reply('👑 Créateur : tes pièces sont illimitées ♾️');
      const e = store.econ(ctx.from.id); const now = Date.now();
      if (now - e.lastWork < 3600000) return ctx.reply(`😮‍💨 Repose-toi encore <b>${fmtDuration((3600000 - (now - e.lastWork)) / 1000)}</b>.`);
      const jobs = ['livré des pizzas 🍕', 'codé un bot 💻', 'promené des chiens 🐕', 'vendu des gâteaux 🧁', 'réparé un vélo 🚲', 'donné un cours 📚'];
      eco(ctx.from.id);
      const boosted = e.buffs.pickaxe > 0;
      const gain = randInt(20, 80) * (boosted ? 2 : 1);
      if (boosted) { e.buffs.pickaxe -= 1; if (e.buffs.pickaxe <= 0) delete e.buffs.pickaxe; }
      e.coins += gain; e.lastWork = now; store.save(); addXp(ctx.from.id, 15);
      return ctx.reply(`💼 Tu as ${jobs[randInt(0, jobs.length - 1)]} et gagné <b>${gain}</b> 🪙${boosted ? ' (⛏️ ×2)' : ''} — solde : ${fmtNum(e.coins)}`);
    },
  },
  {
    name: 'solde', aliases: ['balance', 'bal', 'pieces'], cat: '🪙 Économie', desc: 'ton solde de pièces',
    run(ctx) { const u = ctx.target || ctx.from; return ctx.reply(`🪙 Solde de ${mentionHtml(u)} : <b>${store.coinsText(u.id)}</b>`); },
  },
  {
    name: 'don', aliases: ['give', 'pay'], cat: '🪙 Économie', desc: 'donner des pièces (réponds + /don 50)', needsTarget: true,
    run(ctx) {
      const n = parseInt(ctx.argv[0], 10);
      if (!Number.isFinite(n) || n <= 0) return ctx.reply('Usage : réponds à quelqu’un avec /don 50');
      if (ctx.target.id === ctx.from.id) return ctx.reply('Tu ne peux pas te donner à toi-même 😄');
      const a = store.econ(ctx.from.id);
      if (a.coins < n) return ctx.reply('Tu n’as pas assez de pièces 😅');
      a.coins -= n; store.econ(ctx.target.id).coins += n; store.save();
      return ctx.reply(`💸 ${mentionHtml(ctx.from)} donne <b>${n}</b> 🪙 à ${mentionHtml(ctx.target)}`);
    },
  },
  {
    name: 'pari', aliases: ['bet', 'gamble'], cat: '🪙 Économie', desc: 'parier (/pari 50) : 45 % de chance de doubler (65 % avec un trèfle)',
    run(ctx) {
      if (ctx.isOwner) return ctx.reply('👑 Créateur : tes pièces sont illimitées ♾️ (inutile de parier !)');
      const e = store.econ(ctx.from.id);
      const n = ctx.argv[0] === 'all' ? e.coins : parseInt(ctx.argv[0], 10);
      if (!Number.isFinite(n) || n <= 0) return ctx.reply('Usage : /pari 50 (ou /pari all)');
      if (n > e.coins) return ctx.reply('Tu n’as pas assez de pièces 😅');
      eco(ctx.from.id);
      const lucky = !!e.buffs.clover; delete e.buffs.clover;
      const win = Math.random() < (lucky ? 0.65 : 0.45);
      e.coins += win ? n : -n; store.save();
      return ctx.reply(win ? `🎉 Gagné ! +${n} 🪙 — solde : ${fmtNum(e.coins)}` : `😬 Perdu… −${n} 🪙 — solde : ${fmtNum(e.coins)}`);
    },
  },
  {
    name: 'richesse', aliases: ['topcoins', 'classement'], cat: '🪙 Économie', desc: 'les plus riches',
    run(ctx) {
      const owners = Object.entries(store.db.econ).filter(([id]) => isOwner(id));
      const rows = [...owners, ...Object.entries(store.db.econ).filter(([id]) => !isOwner(id)).sort((a, b) => (b[1].coins + (b[1].bank || 0)) - (a[1].coins + (a[1].bank || 0)))].slice(0, 10);
      if (!rows.length) return ctx.reply('Personne n’a encore de pièces.');
      const lines = rows.map(([id, e], i) => `${['🥇', '🥈', '🥉'][i] || `${i + 1}.`} ${esc(store.db.users[id]?.name || id)} — ${isOwner(id) ? '∞ 👑' : fmtNum(e.coins + (e.bank || 0))} 🪙`);
      return ctx.reply(`🏆 <b>Les plus riches</b>\n${lines.join('\n')}`);
    },
  },
];
export default defs;
