// ============================================================================
//  ICI : tes clés API (une par ligne, entre les guillemets).
//  Tu peux aussi les mettre dans les variables du panel (Startup > Variables) :
//  les variables du panel sont prioritaires sur ce fichier.
//  Ne partage JAMAIS ce fichier.
// ============================================================================
module.exports = {
  GROK_API_KEY: 'grok_88ac03b2b88e50ba030463c6c7bdd0f6_3e055ec8bf618a19cdb6c84bf00ca0f21baa649b18351687f3ee056e6ea94af7',        // xAI Grok  → https://console.x.ai
  OPENROUTER_API_KEY: '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',  // OpenRouter → https://openrouter.ai/keys
  GEMINI_API_KEY: '',      // Google Gemini (gratuit) → https://aistudio.google.com
  OPENAI_API_KEY: ''       // OpenAI (optionnel)
}
