import { InlineKeyboard, InputFile } from "grammy";
import {
  isAdmin,
  getPremiumEntry,
  getVVIPEntry,
  getMode,
  getPairsForUser,
  formatDuration,
} from "../data/database.js";
import { getTravasRegistry } from "./travas.js";
import { formatCooldownText } from "./vvipCooldown.js";
import { CUSTOM_EMOJI } from "../config/config.js";

// Rendu des menus et gestion des callbacks.
export function createMenuModule(bot, deps) {
  const {
    isSubBot,
    OWNER_USERNAME,
    MENU_VIDEO_URL,
    MENU_MEDIA_URL,
    MENU_MEDIA_TYPE,
    BRANDING,
    MENU_PHOTO_URL,
    FORCE_JOIN_CHANNELS,
    checkOwner,
    dbScope,
  } = deps;

  // Style visuel partagé par tous les menus.
  function footerBlock(extraNote) {
    const text = [
      { type: "bold", text: `\n` },
      ` \n- ${BRANDING.footer}`,
    ];
    if (extraNote) {
      text.push("\n", { type: "italic", text: extraNote });
    }
    return { type: "footer", text };
  }

  function sleep(ms) {
    return new Promise((resolve) => setTimeout(resolve, ms));
  }

  function buildCell(text, options = {}) {
    return {
      text: String(text),
      align: "left",
      valign: "middle",
      ...options,
    };
  }

  function customEmoji(name, text, group = "buttons") {
    const emoji = CUSTOM_EMOJI[group]?.[name];
    if (!emoji?.id) return `${emoji?.fallback || ""}${text}`;

    return [
      {
        type: "custom_emoji",
        custom_emoji_id: emoji.id,
        alternative_text: emoji.fallback || "",
      },
      text,
    ];
  }

  function buildTable(headers, rows, cellStyle = {}) {
    const headerCells = headers.map((text) =>
      buildCell(text, {
        is_header: true,
        align: "center",
        valign: "middle",
      }),
    );

    const rowCells = rows.map((row) =>
      row.map((value) =>
        buildCell(value, {
          align: cellStyle.align || "left",
          valign: cellStyle.valign || "middle",
        }),
      ),
    );

    return {
      cells: [headerCells, ...rowCells],
      type: "table",
      is_bordered: true,
      is_striped: true,
    };
  }

  function buildButtonBlock(buttons) {
    return {
      type: "buttons",
      buttons: buttons.map((button) => ({
        text: button.text,
        style: button.style || "danger",
        callback_data: button.callback_data,
      })),
    };
  }

  function getOwnerUrl() {
    const ownerUsername = String(OWNER_USERNAME || "telegram").replace(/^@/, "");
    return `https://t.me/${ownerUsername}`;
  }

  function buildMenuMediaBlock() {
    const mediaType = (MENU_MEDIA_TYPE || "video").toLowerCase();
    const mediaUrl = MENU_MEDIA_URL || (mediaType === "photo" ? MENU_PHOTO_URL : MENU_VIDEO_URL);

    if (!mediaUrl) return null;

    const mediaKey = mediaType === "photo" ? "photo" : "video";
    return {
      type: mediaKey,
      [mediaKey]: {
        type: mediaKey,
        media: mediaUrl,
      },
    };
  }

  async function streamBlocks(ctx, rawBlocks, options = {}) {
    const {
      reply_markup,
      totalDurationMs = 1000,
      maxSteps = 1,
      footerNote,
      footer = true,
    } = options;

    const blocks = footer ? [...rawBlocks, footerBlock(footerNote)] : rawBlocks;

    // Les brouillons ne fonctionnent que dans les chats privés (chat_id entier).
    const isPrivateChat = ctx.chat?.type === "private";

    if (isPrivateChat && blocks.length > 1) {
      const draftId = Date.now();

      // Étape 0 : petit placeholder pour donner un effet de chargement.
      await bot.api.raw
        .sendRichMessageDraft({
          chat_id: ctx.chat.id,
          draft_id: draftId,
          rich_message: {
            blocks: [{ type: "paragraph", text: "🕸 Préparation du menu..." }],
          },
        })
        .catch(() => { });
      await sleep(600);

      const steps = Math.min(maxSteps, blocks.length);
      const chunkSize = Math.max(1, Math.ceil(blocks.length / steps));
      const stepDelay = Math.floor(totalDurationMs / steps);

      for (let i = chunkSize; i < blocks.length; i += chunkSize) {
        await bot.api.raw
          .sendRichMessageDraft({
            chat_id: ctx.chat.id,
            draft_id: draftId,
            rich_message: { blocks: blocks.slice(0, i) },
          })
          .catch(() => { });
        await sleep(stepDelay);
      }
    }

    // Finalisation — le message reste affiché dans le chat.
    return bot.api.raw.sendRichMessage({
      chat_id: ctx.chat.id,
      rich_message: { blocks },
      ...(reply_markup ? { reply_markup } : {}),
    });
  }

  // Helper de tableau partagé par tous les messages de statut/résultat.
  function rowsToCells(rows) {
    return [
      [
        { text: "Statut", is_header: true, align: "center", valign: "middle" },
        { text: "Détail", is_header: true, align: "center", valign: "middle" },
      ],
      ...rows.map(([label, value]) => [
        { text: String(label), align: "left", valign: "middle" },
        { text: String(value), align: "left", valign: "middle" },
      ]),
    ];
  }

  async function sendTableMessage(ctx, title, cells, options = {}) {
    const blocks = [
      { type: "heading", text: title, size: 1 },
      { type: "table", cells, is_bordered: true, is_striped: true },
    ];

    if (options.stream) {
      return streamBlocks(ctx, blocks, {
        reply_markup: options.keyboard,
        totalDurationMs: options.totalDurationMs ?? 2000,
        maxSteps: options.maxSteps ?? 2,
        footerNote: options.footerNote,
        footer: options.footer,
      });
    }
    return bot.api.raw.sendRichMessage({
      chat_id: ctx.chat.id,
      rich_message: { blocks },
      ...(options.keyboard ? { reply_markup: options.keyboard } : {}),
    });
  }

  // Notification générique (erreur/succès/traitement dans tout le bot).
  function botReply(ctx, title, rows, keyboard = null) {
    return sendTableMessage(ctx, title, rowsToCells(rows), { keyboard });
  }

  function botError(ctx, reason, title = "⚠️ AVERTISSEMENT D'ACCÈS\n") {
    return botReply(ctx, title, [
      ["Accès", "❌ Refusé"],
      ["Raison", reason],
    ]);
  }

  function botSucces(ctx, detail, title = "🟢 STATUT : SUCCÈS\n") {
    return botReply(ctx, title, [
      ["Statut", "✅ Réussi"],
      ["Détail", detail],
    ]);
  }

  function botList(ctx, title, items, emptyText = "Vide") {
    if (!items.length) return botReply(ctx, title, [["Total", emptyText]]);
    return botReply(
      ctx,
      title,
      items.map((item, i) => [`#${i + 1}`, item]),
    );
  }

  async function sendTextResult(ctx, data) {
    if (data.type === "single") {
      return botReply(ctx, "🟢 Résultats\n", [
        ["Message", "✅ Envoyé avec succès"],
        ["Session", data.session],
        ["Cible", data.target],
      ]);
    }

    if (data.type === "all") {
      const rows = data.results.map((item) => {
        const split = item.split(" — ");
        return [split[0], split[1] || "-"];
      });
      return botReply(ctx, "🟢 Résultats", rows);
    }
  }

  // ----------------------------- ( VÉRIFICATION D'ADHÉSION AUX CANAUX ) ----------------------------- \\
  /* Supporte plusieurs canaux à la fois (FORCE_JOIN_CHANNEL=@a,@b,@c dans .env).
       L'utilisateur doit rejoindre TOUS les canaux enregistrés. */

  async function isUserJoinedChannel(uid) {
    if (!FORCE_JOIN_CHANNELS || !FORCE_JOIN_CHANNELS.length) return true;

    for (const channel of FORCE_JOIN_CHANNELS) {
      try {
        const member = await bot.api.getChatMember(channel, uid);
        if (!["member", "administrator", "creator"].includes(member.status)) {
          return false;
        }
      } catch {
        return false;
      }
    }
    return true;
  }

  function joinChannelKeyboard() {
    const kb = new InlineKeyboard();
    for (const channel of FORCE_JOIN_CHANNELS) {
      kb.url(
        `📢 Rejoindre ${channel}`,
        `https://t.me/${String(channel).replace("@", "")}`,
      ).row();
    }
    kb.text("✅ J'ai rejoint", "recheck_join");
    return kb;
  }

  async function sendJoinRequiredMenu(ctx, reason = "Vous devez d'abord rejoindre le canal requis.") {
    const channelButtons = FORCE_JOIN_CHANNELS.map((channel) => ({
      text: `📢 Rejoindre ${channel}`,
      style: "success",
      url: `https://t.me/${String(channel).replace("@", "")}`,
    }));

    const mediaBlock = buildMenuMediaBlock();
    const blocks = [
      {
        type: "heading",
        text: `${BRANDING.emoji} ${BRANDING.shortName}`,
        size: 1,
      },
      ...(mediaBlock ? [mediaBlock] : []),
      {
        type: "heading",
        text: `Accès requis ── ${ctx.from.first_name}`,
        size: 2,
      },
      {
        type: "table",
        cells: [
          [
            {
              text: "Vous devez rejoindre le canal requis avant d'utiliser ce bot.",
              is_header: true,
              align: "center",
              valign: "middle",
            },
          ],
        ],
        is_bordered: true,
        is_striped: true,
      },
      {
        type: "table",
        cells: [
          [
            { text: "Statut", is_header: true, align: "center", valign: "middle" },
            { text: "Détails", is_header: true, align: "center", valign: "middle" },
          ],
          [{ text: "Accès", align: "left", valign: "middle" }, { text: "❌ Verrouillé", align: "left", valign: "middle" }],
          [{ text: "Raison", align: "left", valign: "middle" }, { text: reason, align: "left", valign: "middle" }],
          [{ text: "Action", align: "left", valign: "middle" }, { text: "Rejoindre tous les canaux requis", align: "left", valign: "middle" }],
        ],
        is_bordered: true,
        is_striped: true,
      },
      {
        type: "buttons",
        buttons: channelButtons,
      },
      {
        type: "buttons",
        buttons: [
          {
            text: "✅ J'ai rejoint",
            style: "success",
            callback_data: "recheck_join",
          },
        ],
      },
    ];

    return streamBlocks(ctx, blocks);
  }

  // ----------------------------- ( HELPER : ENVOYER UN TABLEAU ) ----------------------------- \\
  /* Envoie un tableau générique (utilisé par listpair, listbot, etc.). */

  async function sendSXTable(ctx, title, cells) {
    return sendTableMessage(ctx, title, cells, {
      stream: true,
      totalDurationMs: 2000,
      maxSteps: 2,
    });
  }

  // ----------------------------- ( MENU : MENU DE DÉMARRAGE ) ----------------------------- \\
  /* Affiche le menu principal du bot. */

  async function sendStartMenu(ctx) {
    const ownerUsername = String(OWNER_USERNAME || "telegram").replace(
      /^@/,
      "",
    );
    const ownerUrl = `https://t.me/${ownerUsername}`;

    const mediaBlock = buildMenuMediaBlock();
    const blocks = [
      {
        type: "heading",
        text: `${BRANDING.emoji} ${BRANDING.shortName}`,
        size: 1,
      },
      ...(mediaBlock ? [mediaBlock] : []),
      {
        type: "heading",
        text: `Bonjour ── ${ctx.from.first_name} ⋆🩵`,
        size: 2,
      },
      {
        type: "table",
        cells: [
          [
            {
              text: [
                { type: "bold", text: "Ce bot est un bot WhatsApp multi-sessions qui vous permet de gérer plusieurs comptes WhatsApp depuis une seule interface." },
              ],
              is_header: true,
              align: "center",
              valign: "middle",
            }
          ]
        ],
        is_bordered: false,
        is_striped: false,
      },

      {
        type: "table",
        cells: [
          [
            {
              text: "𝕀ℕ𝔽𝕆ℝ𝕄𝔸𝕋𝕀𝕆ℕ",
              is_header: true,
              align: "center",
              valign: "middle",
            },
            {
              text: "𝔻É𝕋𝔸𝕀𝕃",
              is_header: true,
              align: "center",
              valign: "middle",
            },
          ],
          [{ text: "ℂℝÉ𝔸𝕋𝔼𝕌ℝ" }, { text: BRANDING.creator }],
          [{ text: "𝕍𝔼ℝ𝕊𝕀𝕆ℕ" }, { text: BRANDING.version }],
          [
            { text: "𝕋𝕐ℙ𝔼" },
            { text: isSubBot ? "Sous-bot (clone)" : "Bot principal" },
          ],
          [
            { text: "Mode du bot" },
            {
              text: !isSubBot
                ? getMode() === "public"
                  ? "Public"
                  : "Privé"
                : "—",
            },
          ],
          [{ text: "𝕊𝕋𝔸𝕋𝕌𝕋" }, { text: customEmoji("status", " En ligne", "startMenu") }],
        ],
        is_bordered: true,
        is_striped: true,
      },
      {
        type: "buttons",
        buttons: [
          {
            text: customEmoji("learn", " Découvrir les fonctionnalités"),
            style: "success",
            callback_data: "learn_features_menu",
          },
        ],
      },
      {
        type: "buttons",
        buttons: [
          {

            text: customEmoji("all", " 𝕋𝕆𝕌𝕊 - 𝕄𝔼ℕ𝕌"),
            style: "danger",
            callback_data: "all_menu",
          },
          {
            text: customEmoji("action", " 𝔸ℂ𝕋𝕀𝕆ℕ - 𝕄𝔼ℕ𝕌"),
            style: "danger",
            callback_data: "action_menu",
          },
        ],
      },
      {
        type: "buttons",
        buttons: [
          {
            text: customEmoji("info", " 𝕄𝔼𝕊 - 𝕀ℕ𝔽𝕆𝕊"),
            style: "success",
            callback_data: "my_info_menu",
          }
        ]
      },
      {
        type: "buttons",
        buttons: [
          {
            text: customEmoji("contact", " ℂ𝕆ℕ𝕋𝔸ℂ𝕋 - ℙℝ𝕆ℙℝ𝕀É𝕋𝔸𝕀ℝ𝔼"),
            style: "success",
            url: ownerUrl,
          }
        ]
      },
    ];
    await streamBlocks(ctx, blocks);
  }

  // ----------------------------- ( MENU : MENU D'ACTION ) ----------------------------- \\
  /* Affiche le menu dédié aux actions avec la liste des commandes, infos, risques. */

  async function sendActionMenu(ctx) {
    const ownerUrl = getOwnerUrl();
    const registry = getTravasRegistry();

    if (isSubBot) {
      const commandCategories = [
        { type: "number", key: "android", label: "Android", exclude: "ios" },
        { type: "number", key: "ios", label: "iPhone", only: "ios" },
        { type: "group", key: "group", label: "Groupe" },
        { type: "channel", key: "channel", label: "Canal" },
      ];

      const commandDetails = commandCategories.flatMap((category) => {
        const items = registry.filter((item) => {
          if (category.only) return item.key === category.only;
          if (category.exclude) return item.type === category.type && item.key !== category.exclude;
          return item.type === category.type;
        });
        const rows = items
          .map((item) => [
            `/${item.command || item.key} <${item.type === "number" ? "numéro" : item.type === "group" ? "groupe" : "id_canal"}>`,
            item.label,
          ]);

        if (!rows.length) return [];

        return [
          { type: "divider" },
          {
            type: "table",
            cells: [[{ text: [{ type: "bold", text: ` ${category.label}` }], is_header: true, align: "center", valign: "middle" }]],
            is_bordered: false,
            is_striped: false,
          },
          buildTable(["Commande", "Action"], rows),
        ];
      });

      const mediaBlock = buildMenuMediaBlock();

      const blocks = [
        {
          type: "heading",
          text: `${BRANDING.emoji} ${BRANDING.shortName}`,
          size: 1,
        },
        ...(mediaBlock ? [mediaBlock] : []),
        {
          type: "heading",
          text: customEmoji("title", " Centre d'action ── Menu", "actionMenu"),
          size: 2,
        },
        {
          type: "paragraph",
          text: "Utilisez la commande ci-dessous et remplacez la valeur cible par la destination souhaitée.",
        },
        {
          type: "details",
          summary: customEmoji("available", " Actions disponibles", "actionMenu"),
          blocks: commandDetails,
        },
        { type: "paragraph", text: "\n" },
        {
          type: "buttons",
          buttons: [
            {
              text: customEmoji("back", " retour au menu"),
              style: "danger",
              callback_data: "back_menu",
            },
          ],
        },
        {
          type: "buttons",
          buttons: [
            {
              text: customEmoji("contact", " ℂ𝕆ℕ𝕋𝔸ℂ𝕋 - ℙℝ𝕆ℙℝ𝕀É𝕋𝔸𝕀ℝ𝔼"),
              style: "success",
              url: ownerUrl,
            }
          ]
        },
      ];

      await streamBlocks(ctx, blocks);
      return;
    }

    const categoryMap = {
      android: registry.filter((item) => item.type === "number" && !["ios"].includes(item.key),
      ),
      ios: registry.filter((item) => item.key === "ios"),
      group: registry.filter((item) => item.type === "group"),
      channel: registry.filter((item) => item.type === "channel"),
    };

    const categoryOrder = [
      { key: "android", label: "Android", style: "danger" },
      { key: "ios", label: "iPhone", style: "success" },
      { key: "group", label: "Groupe", style: "danger" },
      { key: "channel", label: "Canal", style: "success" },
    ];

    const buildButtonRows = (items, perRow = 2) => {
      const rows = [];
      for (let i = 0; i < items.length; i += perRow) {
        rows.push(
          items.slice(i, i + perRow).map((item) => ({
            text: item.label,
            style: item.type === "group" ? "danger" : item.type === "channel" ? "success" : "danger",
            callback_data: `travas_pick_${item.key}`,
          })),
        );
      }
      return rows.map((row) => ({ type: "buttons", buttons: row }));
    };

    const groupedDetails = categoryOrder
      .filter(({ key }) => categoryMap[key]?.length)
      .flatMap(({ key, label }) => [
        { type: "divider" },
        {
          type: "table",
          cells: [[{ text: [{ type: "bold", text: ` ${label}` }], is_header: true, align: "center", valign: "middle" }]],
          is_bordered: false,
          is_striped: false,
        },
        ...buildButtonRows(categoryMap[key], 2),
      ]);

    const commandRows = registry.map((item) => [
      `/${item.command || item.key}`,
      item.label,
      item.type,
    ]);

    const mediaBlock = buildMenuMediaBlock();
    const blocks = [
      {
        type: "heading",
        text: `${BRANDING.emoji} ${BRANDING.shortName}`,
        size: 1,
      },
      ...(mediaBlock ? [mediaBlock] : []),
      {
        type: "heading",
        text: customEmoji("title", " Centre d'action ── Menu", "actionMenu"),
        size: 2,
      },
      {
        type: "paragraph",
        text: "Cliquez sur une action ci-dessous. Le bot vous demandera la cible puis l'enverra automatiquement.",
      },
      {
        type: "details",
        summary: customEmoji("buttons", " Boutons d'action", "actionMenu"),
        blocks: groupedDetails,
      },
      {
        type: "details",
        summary: customEmoji("listcommands", " Commandes d'action", "actionMenu"),
        blocks: [
          buildTable(["Commande", "Action", "Type"], commandRows),
        ],
      },
      { type: 'paragraph', text: '\n' },
      {
        type: "buttons",
        buttons: [
          {
            text: "‼️ retour au menu",
            style: "danger",
            callback_data: "back_menu",
          },
        ],
      },
      {
        type: "buttons",
        buttons: [
          {
            text: customEmoji("contact", " ℂ𝕆ℕ𝕋𝔸ℂ𝕋 - ℙℝ𝕆ℙℝ𝕀É𝕋𝔸𝕀ℝ𝔼"),
            style: "success",
            url: ownerUrl,
          }
        ]
      },
    ];

    await streamBlocks(ctx, blocks);
  }

  // ----------------------------- ( MENU : MENU COMPLET ) ----------------------------- \\
  /* Affiche toutes les commandes disponibles. */

  async function sendAllMenu(ctx) {
    const divider = { type: "divider" };
    const ownerUrl = getOwnerUrl();

    const systemCommands = [
      ["/start", "Menu principal", "Tous"],
      ["/menu", "Toutes les commandes", "Tous"],
      ["/action", "Centre d'action", "Tous"],
      ["/myinfo", "Vos informations de compte", "Tous"],
      ["/help", "Aide détaillée", "Tous"],
      ["/ping", "Latence du bot", "Tous"],
      ["/id", "Votre ID Telegram", "Tous"],
      ["/stats", "Statistiques globales", "Admin"],
      ["/health", "Santé des sessions WhatsApp", "Admin"],
      ["/sessions", "Liste de toutes les sessions", "Admin"],
    ];

    if (!isSubBot) {
      systemCommands.push(
        ["/maintenance", "Activer/désactiver la maintenance", "Propriétaire"],
        ["/restart", "Redémarrer le bot", "Propriétaire"],
        ["/backup", "Télécharger une sauvegarde complète", "Propriétaire"],
        ["/restore", "Restaurer la base depuis un JSON", "Propriétaire"],
      );
    }

    const menuGroup = [
      {
        title: "Système - Menu",
        data: systemCommands,
      },
      {
        title: "Pairing - Menu",
        data: [
          ["/pair", "Associer un WhatsApp", "Premium"],
          ["/delpair", "Supprimer une session", "Premium"],
          ["/listpair", "Lister les expéditeurs", "Utilisateur"],
          ["/clearpair", "Effacer toutes les sessions", "Propriétaire"],
        ],
      },
      {
        title: "Actions - Menu",
        data: [
          ["/xcombo", "Charge lourde Android", "Premium"],
          ["/vxdelay", "Flux de messages Delay-X2", "Premium"],
          ["/freeze", "Charge de gel / blocage", "Premium"],
          ["/ios", "Charge riche iOS", "Premium"],
          ["/crashgb", "Charge sur groupe", "Premium"],
          ["/freezgb", "Gel de groupe", "Premium"],
          ["/bangb", "Boucle de bannissement groupe", "Premium"],
          ["/channel", "Charge sur canal", "Premium"],
        ],
      },
      {
        title: "Premium - Menu",
        data: [
          ["/addprem", "Ajouter premium (ID[,durée])", "Admin"],
          ["/delprem", "Retirer premium", "Admin"],
          ["/listprem", "Lister les premium", "Admin"],
          ["/extendprem", "Prolonger un premium", "Admin"],
        ],
      },
      {
        title: "VVIP - Menu",
        data: [
          ["/addvvip", "Ajouter VVIP (ID[,durée])", "Admin"],
          ["/delvvip", "Retirer VVIP", "Admin"],
          ["/listvvip", "Lister les VVIP", "Admin"],
          ["/xvvip", "Utiliser un expéditeur VVIP actif", "VVIP"],
          ["/resetvvipcooldown", "Réinitialiser un refroidissement", "Propriétaire"],
        ],
      },
      {
        title: "Admin - Menu",
        data: [
          ["/addadmin", "Ajouter un admin", "Propriétaire"],
          ["/deladmin", "Retirer un admin", "Propriétaire"],
          ["/listadmin", "Lister les admins", "Propriétaire"],
          ["/listusers", "Lister tous les utilisateurs", "Admin"],
          ["/userinfo", "Informations sur un utilisateur", "Admin"],
          ["/deluser", "Supprimer un utilisateur", "Admin"],
          ["/exportusers", "Exporter les utilisateurs en JSON", "Admin"],
          ["/bc", "Diffusion", "Admin"],
        ],
      },
    ];

    if (!isSubBot) {
      menuGroup.splice(1, 0, {
        title: "Déploiement - Menu",
        data: [
          ["/addbot", "Déployer un nouveau bot", "Premium"],
          ["/delbot", "Supprimer un bot", "Premium"],
          ["/listbot", "Lister mes bots", "Premium"],
        ],
      });
    }

    const mediaBlock = buildMenuMediaBlock();
    const blocks = [
      {
        type: "heading",
        text: `${BRANDING.emoji} ${BRANDING.shortName}`,
        size: 1,
      },
      ...(mediaBlock ? [mediaBlock] : []),
      {
        type: "heading",
        text: customEmoji("title", " Bibliothèque de commandes ── Menu", "allMenu"),
        size: 2,
      },
      {
        type: "table",
        cells: [
          [
            { text: "Ceci est le menu de la bibliothèque de commandes. Cliquez ci-dessous pour voir la liste des commandes disponibles dans ce bot.", is_header: true, align: "center", valign: "middle" },
          ],
        ],
        is_bordered: true,
        is_striped: true,
      },
      {
        type: "table",
        cells: [
          [
            { text: "Catégorie", is_header: true, align: "center", valign: "middle" },
            { text: "Nombre", is_header: true, align: "center", valign: "middle" },
          ],
          [{ text: "Système", align: "left", valign: "middle" }, { text: isSubBot ? "10" : "14", align: "center", valign: "middle" }],
          [{ text: "Pairing", align: "left", valign: "middle" }, { text: "4", align: "center", valign: "middle" }],
          [{ text: "Actions", align: "left", valign: "middle" }, { text: "8", align: "center", valign: "middle" }],
          [{ text: "Premium", align: "left", valign: "middle" }, { text: "4", align: "center", valign: "middle" }],
          [{ text: "VVIP", align: "left", valign: "middle" }, { text: "5", align: "center", valign: "middle" }],
          [{ text: "Admin", align: "left", valign: "middle" }, { text: "8", align: "center", valign: "middle" }],
        ],
        is_bordered: true,
        is_striped: true,
      },
      {
        type: "details",
        summary: customEmoji("details", " ℂ𝕃𝕀ℚ𝕌𝔼ℤ 𝕀ℂ𝕀 ", "allMenu"),
        blocks: menuGroup.map((group) => ({
          type: "details",
          summary: [group.title],
          blocks: [
            buildTable(["Commande", "Info", "Accès"], group.data),
          ],
        })),
      },
      {
        type: "table",
        cells: [
          [{ text: "Cliquez sur le menu ci-dessus pour voir la liste des commandes", is_header: false, align: "center", valign: "middle" }],
        ],
      },
      {
        type: "buttons",
        buttons: [
          {
            text: customEmoji("back", " retour au menu"),
            style: "danger",
            callback_data: "back_menu",
          },
        ],
      },
      {
        type: "buttons",
        buttons: [
          {
            text: customEmoji("contact", " ℂ𝕆ℕ𝕋𝔸ℂ𝕋 - ℙℝ𝕆ℙℝ𝕀É𝕋𝔸𝕀ℝ𝔼"),
            style: "success",
            url: ownerUrl,
          }
        ]
      },];

    await streamBlocks(ctx, blocks);
  }

  function getLearnFeaturesContent(language = "fr") {
    const normalized = (language || "fr").toLowerCase();
    const map = {
      fr: {
        title: "Découvrir les fonctionnalités du bot",
        intro: "Ce bot vous aide à gérer des expéditeurs WhatsApp, les rôles des utilisateurs, les accès premium/VVIP, les menus et le contrôle du bot de manière rapide et structurée.",
        rows: [
          ["Bot principal", "Bot central qui gère tous les expéditeurs WhatsApp, les menus et les accès utilisateurs."],
          ["Mode du bot", "Public = tous les utilisateurs voient les fonctionnalités générales. Privé = accès réservé à certains rôles."],
          ["Pairing", "Utilisez /pair pour ajouter un expéditeur, /listpair pour voir les expéditeurs actifs, /delpair pour en supprimer un et /clearpair pour tout réinitialiser."],
          ["Premium", "Les utilisateurs premium bénéficient d'un accès élargi, notamment au pairing et aux actions avancées."],
          ["VVIP", "Les utilisateurs VVIP peuvent utiliser les expéditeurs actifs avec un refroidissement de 15 minutes et une limite de 5 utilisations."],
          ["Admin / Propriétaire", "Les admins et le propriétaire peuvent gérer les rôles, le mode du bot, les listes d'utilisateurs, les sauvegardes et les réglages principaux."],
          ["Mes infos", "Consultez votre rôle, votre statut premium/VVIP, la durée restante, le refroidissement et le nombre d'expéditeurs actifs."],
          ["Comment l'utiliser", "Commencez par /start, ouvrez /menu, vérifiez /myinfo, puis utilisez /pair ou /xvvip selon votre niveau d'accès."],
          ["Commandes puissantes", "/stats, /health, /sessions, /userinfo, /exportusers, /maintenance et /restart vous donnent un contrôle total sur le bot."],
        ],
      },
      en: {
        title: "Learn Bot Features",
        intro: "This bot manages WhatsApp senders, user roles, premium/VVIP access, command access, and bot controls in one central system.",
        rows: [
          ["Main Bot", "Main bot that manages all WhatsApp senders, menus, and user access."],
          ["Bot Mode", "Public = general features are visible to all users. Private = access is restricted to selected roles."],
          ["Pairing", "Use /pair to add a sender, /listpair to view active senders, /delpair to remove one, and /clearpair to reset all sessions."],
          ["Premium", "Premium users receive broader access to pairing and action features."],
          ["VVIP", "VVIP users can use active senders with a 15-minute cooldown and a limit of 5 uses within that window."],
          ["Admin / Owner", "Admins and owners can manage roles, bot mode, user lists, backups, and core bot settings."],
          ["My Info", "Check your role, premium/VVIP status, remaining time, cooldown, and active sender count."],
          ["How to Use", "Start with /start, open /menu, check /myinfo, then use /pair or /xvvip depending on your access level."],
          ["Powerful Commands", "/stats, /health, /sessions, /userinfo, /exportusers, /maintenance and /restart give you full control over the bot."],
        ],
      },
      ar: {
        title: "تعرّف على ميزات البوت",
        intro: "يدير هذا البوت مرسلي واتساب، وأدوار المستخدمين، وصلاحيات premium/VVIP، وقوائم الوصول، والتحكم في البوت من نقطة واحدة.",
        rows: [
          ["البوت الرئيسي", "البوت الأساسي الذي يدير جميع مرسلي واتساب والقوائم والوصول."],
          ["وضع البوت", "Public = الميزات العامة ظاهرة لكل المستخدمين. Private = الوصول مقيد للأدوار المحددة."],
          ["الإقران", "استخدم /pair لإضافة مرسل، /listpair لمراجعة المرسلين النشطين، /delpair لحذف واحد، و /clearpair لإعادة تعيين جميع الجلسات."],
          ["Premium", "يتمتع المستخدمون المميزون بوصول أوسع إلى ميزات الإقران والعمل."],
          ["VVIP", "يمكن لمستخدمي VVIP استخدام المرسلين النشطين مع فترة تبرّيد 15 دقيقة وحد أقصى 5 استخدامات خلال تلك الفترة."],
          ["المشرف / المالك", "يمكن للمشرفين والمالكين إدارة الأدوار، وضع البوت، قوائم المستخدمين، النسخ الاحتياطية، وإعدادات البوت الأساسية."],
          ["معلوماتي", "راجع دورك، حالة Premium/VVIP، الوقت المتبقي، فترة التبرّيد، وعدد المرسلين النشطين."],
          ["طريقة الاستخدام", "ابدأ بـ /start، افتح /menu، تحقق من /myinfo، ثم استخدم /pair أو /xvvip حسب مستوى الوصول الخاص بك."],
          ["أوامر قوية", "/stats, /health, /sessions, /userinfo, /exportusers, /maintenance و /restart تمنحك تحكمًا كاملًا في البوت."],
        ],
      },
      pt: {
        title: "Aprenda os Recursos do Bot",
        intro: "Este bot gerencia remetentes do WhatsApp, papéis de usuário, acesso premium/VVIP, menus e controle central do bot.",
        rows: [
          ["Bot Principal", "Bot principal que gerencia todos os remetentes do WhatsApp, menus e acesso de usuários."],
          ["Modo do Bot", "Public = recursos gerais ficam visíveis para todos. Private = acesso restrito a funções específicas."],
          ["Emparelhamento", "Use /pair para adicionar um remetente, /listpair para ver os ativos, /delpair para remover um, e /clearpair para resetar todas as sessões."],
          ["Premium", "Usuários premium recebem acesso mais amplo a recursos de pairing e ações."],
          ["VVIP", "Usuários VVIP podem usar remetentes ativos com cooldown de 15 minutos e limite de 5 usos no período."],
          ["Admin / Dono", "Admins e donos podem gerenciar papéis, modo do bot, lista de usuários, backups e configurações principais."],
          ["Minha Info", "Veja seu papel, status premium/VVIP, tempo restante, cooldown e quantidade de remetentes ativos."],
          ["Como Usar", "Comece com /start, abra /menu, veja /myinfo e depois use /pair ou /xvvip conforme seu nível de acesso."],
          ["Comandos Poderosos", "/stats, /health, /sessions, /userinfo, /exportusers, /maintenance e /restart dão controle total sobre o bot."],
        ],
      },
    };

    return map[normalized] || map.fr;
  }

  async function sendLearnFeaturesMenu(ctx, language = "fr") {
    const locale = getLearnFeaturesContent(language);
    const mediaBlock = buildMenuMediaBlock();

    const blocks = [
      {
        type: "heading",
        text: `${BRANDING.emoji} ${BRANDING.shortName}`,
        size: 1,
      },
      ...(mediaBlock ? [mediaBlock] : []),
      {
        type: "heading",
        text: customEmoji("title", ` ${locale.title}`, "learnMenu"),
        size: 2,
      },
      {
        type: "table",
        cells: [
          [
            {
              text: locale.intro,
              is_header: true,
              align: "center",
              valign: "middle",
            },
          ],
        ],
        is_bordered: true,
        is_striped: true,
      },
      {
        type: "buttons",
        buttons: [
          { text: "🇫🇷 Français", style: "success", callback_data: "learn_lang_fr" },
          { text: "🇬🇧 English", style: "success", callback_data: "learn_lang_en" },
          { text: "🇸🇦 العربية", style: "success", callback_data: "learn_lang_ar" },
          { text: "🇵🇹 Português", style: "success", callback_data: "learn_lang_pt" },
        ],
      },
      {
        type: "details",
        summary: customEmoji("details", " Fonctionnalités", "learnMenu"),
        blocks: [
          {
            type: "table",
            cells: [
              [
                { text: "Fonctionnalité", is_header: true, align: "center", valign: "middle" },
                { text: "Explication", is_header: true, align: "center", valign: "middle" },
              ],
              ...locale.rows.map(([title, desc]) => [
                { text: String(title), align: "left", valign: "middle" },
                { text: String(desc), align: "left", valign: "middle" },
              ]),
            ],
            is_bordered: true,
            is_striped: true,
          },
        ],
      },
      {
        type: "buttons",
        buttons: [
          {
            text: customEmoji("back", " retour au menu"),
            style: "danger",
            callback_data: "back_menu",
          },
        ],
      },
    ];

    await streamBlocks(ctx, blocks);
  }

  // ----------------------------- ( MENU : MES INFOS ) ----------------------------- \\

  async function sendMyInfoMenu(ctx) {
    const uid = String(ctx.from.id);
    const ownerUrl = getOwnerUrl();
    const owner = checkOwner(uid);
    const admin = !owner && isAdmin(uid, dbScope);
    const premiumEntry = getPremiumEntry(uid, dbScope);
    const vvipEntry = getVVIPEntry(uid, dbScope);

    let status = "Utilisateur gratuit";
    if (owner) status = "Propriétaire";
    else if (admin) status = "Admin";
    else if (vvipEntry) status = "VVIP";
    else if (premiumEntry) status = "Premium";

    let sisaDurasi = "-";
    if (vvipEntry) {
      sisaDurasi = vvipEntry.expiresAt
        ? formatDuration(vvipEntry.expiresAt - Date.now())
        : "Permanent";
    } else if (premiumEntry) {
      sisaDurasi = premiumEntry.expiresAt
        ? formatDuration(premiumEntry.expiresAt - Date.now())
        : "Permanent";
    }

    const sessionKey = uid;
    const totalPair = isSubBot ? "-" : getPairsForUser(sessionKey).length;
    const cooldownText = formatCooldownText(uid);
    const fullName =
      ctx.from.first_name +
      (ctx.from.last_name ? ` ${ctx.from.last_name}` : "");
    const username = ctx.from.username
      ? `@${ctx.from.username}`
      : "Aucun nom d'utilisateur";
    const languageCode = ctx.from.language_code
      ? ctx.from.language_code.toUpperCase()
      : "-";
    const isPremiumTelegram = ctx.from.is_premium ? "Oui" : "Non";

    const divider = { type: "divider" };

    const makeDetails = (emojiKey, title, headers, dataRows) => ({
      type: "details",
      summary: customEmoji(emojiKey, ` ${title}`, "myInfo"),
      blocks: [buildTable(headers, dataRows)],
    });

    const mediaBlock = buildMenuMediaBlock();
    const blocks = [
      {
        type: "heading",
        text: `${BRANDING.emoji} ${BRANDING.shortName}`,
        size: 1,
      },
      ...(mediaBlock ? [mediaBlock] : []),
      {
        type: "heading",
        text: customEmoji("account", " Infos du compte ── Menu", "myInfo"),
        size: 2,
      },
      {
        type: "table",
        cells: [
          [
            {
              text: [
                {
                  type: "bold",
                  text: "Voici le menu d'informations de votre compte. Cliquez sur les sections ci-dessous pour voir les détails de votre compte Telegram et le statut du bot.",
                },
              ],
              is_header: true,
              align: "center",
              valign: "middle",
            },
          ],
        ],
        is_bordered: false,
        is_striped: false,
      },
      divider,
      {
        type: "table",
        cells: [
          [
            { text: "Statut", is_header: true, align: "center", valign: "middle" },
            { text: "Valeur", is_header: true, align: "center", valign: "middle" },
          ],
          [{ text: "Rôle", align: "left", valign: "middle" }, { text: status, align: "left", valign: "middle" }],
          [{ text: "VVIP", align: "left", valign: "middle" }, { text: vvipEntry ? "Actif" : "Inactif", align: "left", valign: "middle" }],
          [{ text: "Premium", align: "left", valign: "middle" }, { text: premiumEntry ? "Actif" : "Inactif", align: "left", valign: "middle" }],
          [{ text: "Solde", align: "left", valign: "middle" }, { text: sisaDurasi, align: "left", valign: "middle" }],
          [{ text: "Refroidissement VVIP", align: "left", valign: "middle" }, { text: cooldownText, align: "left", valign: "middle" }],
        ],
        is_bordered: true,
        is_striped: true,
      },
      divider,
      makeDetails(
        "account",
        "Compte Telegram",
        ["Info", "Détail"],
        [
          ["Nom complet", fullName],
          ["Nom d'utilisateur", username],
          ["ID Telegram", uid],
          ["Langue", languageCode],
          ["Telegram Premium", isPremiumTelegram],
        ],
      ),
      divider,
      makeDetails(
        "botStatus",
        "Statut du bot",
        ["Info", "Détail"],
        [
          ["Statut", status],
          ["Bot VVIP", vvipEntry ? "Actif" : "Inactif"],
          ["Bot Premium", premiumEntry ? "Actif" : "Inactif"],
          ["Temps restant", sisaDurasi],
        ],
      ),
      ...(!isSubBot
        ? [
          divider,
          makeDetails(
            "statistics",
            "Statistiques du bot",
            ["Info", "Détail"],
            [
              ["Total des paires WhatsApp", String(totalPair)],
              [
                "Mode du bot",
                getMode() === "public" ? "Public" : "Privé",
              ],
            ],
          ),
        ]
        : []),
      divider,
      {
        type: "table",
        cells: [
          [{ text: `Note : les données ci-dessus ont été récupérées automatiquement depuis votre profil Telegram par ${BRANDING.name}.`, is_header: false, align: "center", valign: "middle" }],
        ],
      },
      {
        type: "table",
        cells: [
          [{ text: "Cliquez sur le menu ci-dessus pour voir la liste des commandes", is_header: false, align: "center", valign: "middle" }],
        ],
      },
      {
        type: "buttons",
        buttons: [
          {
            text: customEmoji("back", " retour au menu"),
            style: "danger",
            callback_data: "back_menu",
          },
        ],
      },
      {
        type: "buttons",
        buttons: [
          {
            text: customEmoji("contact", " ℂ𝕆ℕ𝕋𝔸ℂ𝕋 - ℙℝ𝕆ℙℝ𝕀É𝕋𝔸𝕀ℝ𝔼"),
            style: "success",
            url: ownerUrl,
          }
        ]
      },
    ];

    await streamBlocks(ctx, blocks);
  }

  // ----------------------------- ( CALLBACK : BOUTONS DES MENUS ) ----------------------------- \\
  /* Retourne true quand ce module a traité le callback. */

  async function handleMenuCallback(ctx, data) {
    if (data === "recheck_join") {
      const uidCheck = String(ctx.from.id);
      const joined = await isUserJoinedChannel(uidCheck);
      if (joined) {
        await ctx.editMessageText(
          "✅ Merci d'avoir rejoint ! Vous pouvez maintenant utiliser le bot.",
        );
      } else {
        await botError(ctx, "Vous n'avez pas encore rejoint tous les canaux requis.");
      }
      return true;
    }

    if (data === "all_menu") {
      await ctx.deleteMessage().catch(() => { });
      await sendAllMenu(ctx);
      return true;
    }

    if (data === "my_info_menu") {
      await ctx.deleteMessage().catch(() => { });
      await sendMyInfoMenu(ctx);
      return true;
    }

    if (data === "learn_features_menu") {
      await ctx.deleteMessage().catch(() => { });
      await sendLearnFeaturesMenu(ctx, "fr");
      return true;
    }

    if (data.startsWith("learn_lang_")) {
      const lang = data.replace("learn_lang_", "");
      await ctx.deleteMessage().catch(() => { });
      await sendLearnFeaturesMenu(ctx, lang);
      return true;
    }

    if (data === "action_menu") {
      await ctx.deleteMessage().catch(() => { });
      await sendActionMenu(ctx);
      return true;
    }

    if (data === "back_menu") {
      await ctx.deleteMessage().catch(() => { });
      await sendStartMenu(ctx);
      return true;
    }

    return false;
  }

  return {
    isUserJoinedChannel,
    joinChannelKeyboard,
    sendJoinRequiredMenu,
    sendSXTable,
    sendStartMenu,
    sendActionMenu,
    sendAllMenu,
    sendMyInfoMenu,
    handleMenuCallback,
    botReply,
    botError,
    botSucces,
    botList,
    sendTextResult,
    streamBlocks,
  };
}
