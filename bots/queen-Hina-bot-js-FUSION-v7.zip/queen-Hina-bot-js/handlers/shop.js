// Économie avancée : niveaux/XP, boutique, inventaire, banque, vol.
import * as store from '../store.js';
import { hooks } from '../router.js';
import { isOwner } from '../config.js';
import { ITEMS, itemKey, eco, xpFor, levelOf, addXp, badgeOf, bankCap, accrue } from '../perks.js';
import { esc, mentionHtml, randInt, fmtNum, fmtDuration, bar, clamp } from '../util.js';

const C = '🪙 Économie';
const money = (id, n) => (isOwner(id) ? '∞' : fmtNum(n));
const qtyArg = (argv, from = 1) => { const a = argv[from]; if (!a) return 1; const n = parseInt(a, 10); return Number.isFinite(n) ? clamp(n, 1, 99) : 1; };

// ---- XP automatique : 1 message = 5 à 10 XP (au plus une fois toutes les 30 s par personne) ----
const lastXp = new Map();
hooks.push(async (ctx) => {
  if (!ctx.from || ctx.from.is_bot) return false;
  const now = Date.now();
  if (now - (lastXp.get(ctx.from.id) || 0) < 30000) return false;
  lastXp.set(ctx.from.id, now);
  if (lastXp.size > 5000) lastXp.clear();
  const r = addXp(ctx.from.id, randInt(5, 10));
  if (r.up) {
    await ctx.reply(`🎉 <b>${esc(ctx.name)}</b> passe au <b>niveau ${r.level}</b> ! +${r.bonus} 🪙`).catch(() => {});
  }
  return false; // ne consomme jamais le message : la discussion continue normalement
});

export const defs = [
  {
    name: 'niveau', aliases: ['level', 'xp', 'rang'], cat: C, desc: 'ton niveau et ton XP',
    run(ctx) {
      const u = ctx.target || ctx.from; const e = eco(u.id);
      const lvl = levelOf(e.xp); const lo = xpFor(lvl); const hi = xpFor(lvl + 1);
      const pct = ((e.xp - lo) / (hi - lo)) * 100;
      const lines = [
        `🌸 <b>${mentionHtml(u)}</b> ${badgeOf(e)}${isOwner(u.id) ? ' 👑' : ''}`,
        `⭐ Niveau <b>${lvl}</b>`,
        `${bar(pct, 12)} ${e.xp - lo}/${hi - lo} XP`,
        `🪙 Porte-monnaie : ${store.coinsText(u.id)}   🏦 Banque : ${money(u.id, e.bank)}`,
      ];
      return ctx.reply(lines.join('\n'));
    },
  },
  {
    name: 'topxp', aliases: ['toplevel', 'niveaux'], cat: C, desc: 'classement des niveaux',
    run(ctx) {
      const rows = Object.entries(store.db.econ).filter(([, e]) => e.xp > 0).sort((a, b) => b[1].xp - a[1].xp).slice(0, 10);
      if (!rows.length) return ctx.reply('Personne n’a encore d’XP. Discute un peu ! 💬');
      const lines = rows.map(([id, e], i) => `${['🥇', '🥈', '🥉'][i] || `${i + 1}.`} ${esc(store.db.users[id]?.name || id)} ${badgeOf(e)} — niv. ${levelOf(e.xp)} (${fmtNum(e.xp)} XP)`);
      return ctx.reply(`🌟 <b>Classement des niveaux</b>\n${lines.join('\n')}`);
    },
  },
  {
    name: 'boutique', aliases: ['shop', 'magasin'], cat: C, desc: 'la boutique d’objets',
    run(ctx) {
      const lines = Object.entries(ITEMS).map(([k, it]) => `${it.emoji} <b>${it.name}</b> (<code>${k}</code>) — ${fmtNum(it.price)} 🪙\n   <i>${it.desc}</i>`);
      return ctx.reply(`🛍️ <b>Boutique de Queen Hina</b>\n\n${lines.join('\n')}\n\nAcheter : <code>/acheter bouclier 2</code>\nUtiliser : <code>/utiliser bouclier</code>`);
    },
  },
  {
    name: 'acheter', aliases: ['buy', 'achat'], cat: C, desc: 'acheter un objet (/acheter bouclier 2)',
    run(ctx) {
      const k = itemKey(ctx.argv[0]);
      if (!k) return ctx.reply('Quel objet ? Regarde /boutique 🛍️ puis /acheter bouclier');
      const n = qtyArg(ctx.argv); const it = ITEMS[k]; const cost = it.price * n;
      if (!it.use && eco(ctx.from.id).inv[k] > 0) return ctx.reply(`Tu as déjà ${it.emoji} ${it.name} 😉`);
      if (!it.use && n > 1) return ctx.reply(`${it.emoji} ${it.name} ne s’achète qu’en un seul exemplaire.`);
      if (!store.spend(ctx.from.id, cost)) return ctx.reply(`Il te manque des pièces 😅 (${fmtNum(cost)} 🪙 nécessaires)`);
      const e = eco(ctx.from.id); e.inv[k] = (e.inv[k] || 0) + n; store.save();
      return ctx.reply(`✅ Tu as acheté ${it.emoji} <b>${it.name}</b> ×${n} pour ${fmtNum(cost)} 🪙`);
    },
  },
  {
    name: 'inventaire', aliases: ['inv', 'sac'], cat: C, desc: 'ton inventaire',
    run(ctx) {
      const u = ctx.target || ctx.from; const e = eco(u.id); const now = Date.now();
      const items = Object.entries(e.inv).filter(([, n]) => n > 0).map(([k, n]) => `${ITEMS[k].emoji} ${ITEMS[k].name} ×${n}`);
      const buffs = [];
      if (e.buffs.shield > now) buffs.push(`🛡️ bouclier actif encore ${fmtDuration((e.buffs.shield - now) / 1000)}`);
      if (e.buffs.clover) buffs.push('🍀 trèfle prêt pour ton prochain pari');
      if (e.buffs.pickaxe > 0) buffs.push(`⛏️ pioche : ${e.buffs.pickaxe} /work boosté(s)`);
      if (e.buffs.lockpick) buffs.push('🗝️ crochet prêt pour ton prochain vol');
      return ctx.reply(`🎒 <b>Inventaire de ${mentionHtml(u)}</b>\n${items.length ? items.join('\n') : '<i>vide</i>'}${buffs.length ? `\n\n✨ <b>Effets actifs</b>\n${buffs.join('\n')}` : ''}`);
    },
  },
  {
    name: 'utiliser', aliases: ['use', 'activer'], cat: C, desc: 'utiliser un objet (/utiliser bouclier)',
    run(ctx) {
      const k = itemKey(ctx.argv[0]);
      if (!k) return ctx.reply('Quel objet ? Exemple : /utiliser bouclier (voir /inventaire)');
      const it = ITEMS[k]; const e = eco(ctx.from.id); const now = Date.now();
      if ((e.inv[k] || 0) < 1) return ctx.reply(`Tu n’as pas de ${it.emoji} ${it.name}. Va voir /boutique !`);
      if (!it.use) return ctx.reply(`${it.emoji} ${it.name} est un badge : il s’affiche déjà sur ton /niveau ✨`);
      if (k === 'bouclier' && e.buffs.shield > now) return ctx.reply('Ton bouclier est déjà actif 🛡️');
      if (k === 'trefle' && e.buffs.clover) return ctx.reply('Ton trèfle est déjà prêt 🍀');
      if (k === 'crochet' && e.buffs.lockpick) return ctx.reply('Ton crochet est déjà prêt 🗝️');
      e.inv[k] -= 1; if (e.inv[k] <= 0) delete e.inv[k];
      let msg = '';
      if (k === 'bouclier') { e.buffs.shield = now + 86400000; msg = '🛡️ Bouclier activé pour <b>24 h</b> : personne ne peut te voler !'; }
      else if (k === 'trefle') { e.buffs.clover = true; msg = '🍀 Trèfle prêt : ton prochain /pari a 65 % de chances !'; }
      else if (k === 'pioche') { e.buffs.pickaxe = (e.buffs.pickaxe || 0) + 5; msg = `⛏️ Pioche prête : tes ${e.buffs.pickaxe} prochains /work rapportent ×2 !`; }
      else if (k === 'crochet') { e.buffs.lockpick = true; msg = '🗝️ Crochet prêt : ton prochain /voler a 75 % de chances !'; }
      else if (k === 'potion') { const r = addXp(ctx.from.id, 100); msg = `🧪 +100 XP ! Tu es niveau <b>${r.level}</b>${r.up ? ` 🎉 (+${r.bonus} 🪙)` : ''}`; }
      else if (k === 'ticket') {
        const r = Math.random(); const gain = r < 0.03 ? 1000 : r < 0.15 ? 250 : r < 0.45 ? 100 : 0;
        if (gain) e.coins += gain;
        msg = gain >= 1000 ? '🎟️ 🎊 <b>JACKPOT !</b> +1 000 🪙' : gain ? `🎟️ Gagné ! +${gain} 🪙` : '🎟️ Perdu… retente ta chance !';
      }
      store.save();
      return ctx.reply(msg);
    },
  },
  {
    name: 'vendre', aliases: ['sell'], cat: C, desc: 'revendre un objet à 50 % (/vendre bouclier)',
    run(ctx) {
      const k = itemKey(ctx.argv[0]);
      if (!k) return ctx.reply('Quel objet ? Exemple : /vendre bouclier 2');
      const it = ITEMS[k]; const e = eco(ctx.from.id); const n = Math.min(qtyArg(ctx.argv), e.inv[k] || 0);
      if (n < 1) return ctx.reply(`Tu n’as pas de ${it.emoji} ${it.name}.`);
      const gain = Math.floor(it.price / 2) * n;
      e.inv[k] -= n; if (e.inv[k] <= 0) delete e.inv[k];
      store.earn(ctx.from.id, gain);
      return ctx.reply(`💰 Tu as vendu ${it.emoji} ${it.name} ×${n} pour ${fmtNum(gain)} 🪙`);
    },
  },
  {
    name: 'banque', aliases: ['bank', 'compte'], cat: C, desc: 'ton compte en banque (intérêts 2 %/jour)',
    run(ctx) {
      const e = eco(ctx.from.id); const gain = accrue(ctx.from.id);
      return ctx.reply(`🏦 <b>Banque de ${esc(ctx.name)}</b>\nSolde : <b>${money(ctx.from.id, e.bank)}</b> 🪙 / ${fmtNum(bankCap(e))} max\n${gain ? `📈 Intérêts reçus : +${fmtNum(gain)} 🪙\n` : ''}Les pièces en banque sont <b>à l’abri des vols</b> et rapportent 2 % par jour.\n/depot 100 · /retrait 100`);
    },
  },
  {
    name: 'depot', aliases: ['deposit', 'deposer'], cat: C, desc: 'mettre des pièces en banque (/depot 100 ou all)',
    run(ctx) {
      const e = eco(ctx.from.id); accrue(ctx.from.id);
      const room = bankCap(e) - e.bank;
      const n = ctx.argv[0] === 'all' ? Math.min(e.coins, room) : parseInt(ctx.argv[0], 10);
      if (!Number.isFinite(n) || n <= 0) return ctx.reply('Usage : /depot 100 (ou /depot all)');
      if (n > e.coins) return ctx.reply('Tu n’as pas assez de pièces 😅');
      if (n > room) return ctx.reply(`Ta banque est presque pleine (place pour ${fmtNum(room)} 🪙). Monte de niveau pour l’agrandir !`);
      if (isOwner(ctx.from.id)) return ctx.reply('👑 Créateur : inutile, tu as déjà tout ♾️');
      e.coins -= n; e.bank += n; store.save();
      return ctx.reply(`🏦 +${fmtNum(n)} 🪙 déposés. Banque : <b>${fmtNum(e.bank)}</b> · Poche : ${fmtNum(e.coins)}`);
    },
  },
  {
    name: 'retrait', aliases: ['withdraw', 'retirer'], cat: C, desc: 'retirer des pièces de la banque (/retrait 100 ou all)',
    run(ctx) {
      const e = eco(ctx.from.id); accrue(ctx.from.id);
      const n = ctx.argv[0] === 'all' ? e.bank : parseInt(ctx.argv[0], 10);
      if (!Number.isFinite(n) || n <= 0) return ctx.reply('Usage : /retrait 100 (ou /retrait all)');
      if (n > e.bank) return ctx.reply('Ta banque n’a pas autant 😅');
      e.bank -= n; e.coins += n; store.save();
      return ctx.reply(`🏦 −${fmtNum(n)} 🪙 retirés. Banque : <b>${fmtNum(e.bank)}</b> · Poche : ${store.coinsText(ctx.from.id)}`);
    },
  },
  {
    name: 'voler', aliases: ['steal', 'vol'], cat: C, desc: 'tenter de voler quelqu’un (réponds à son message)', needsTarget: true, group: true, cooldown: 3000,
    run(ctx) {
      if (ctx.isOwner) return ctx.reply('👑 Créateur : tu n’as pas besoin de voler 😏');
      const t = ctx.target;
      if (t.id === ctx.from.id) return ctx.reply('Tu ne peux pas te voler toi-même 😄');
      if (isOwner(t.id)) return ctx.reply('👑 Voler le créateur ? Même pas en rêve 😤');
      const me = eco(ctx.from.id); const he = eco(t.id); const now = Date.now();
      const wait = 1800000 - (now - me.lastSteal);
      if (wait > 0) return ctx.reply(`🕵️ Fais-toi oublier encore <b>${fmtDuration(wait / 1000)}</b>.`);
      if (he.buffs.shield > now) return ctx.reply(`🛡️ ${mentionHtml(t)} est protégé par un bouclier !`);
      if (he.coins < 100) return ctx.reply(`${mentionHtml(t)} est trop fauché pour que ça vaille le coup 😅`);
      if (me.coins < 100) return ctx.reply('Il te faut au moins 100 🪙 en poche pour tenter un vol (au cas où tu te fais attraper).');
      me.lastSteal = now;
      const chance = me.buffs.lockpick ? 0.75 : 0.5; delete me.buffs.lockpick;
      if (Math.random() < chance) {
        const gain = Math.min(2000, Math.max(10, Math.floor(he.coins * randInt(10, 25) / 100)));
        he.coins -= gain; me.coins += gain; store.save();
        return ctx.reply(`🦹 ${mentionHtml(ctx.from)} dérobe <b>${fmtNum(gain)}</b> 🪙 à ${mentionHtml(t)} !`);
      }
      const fine = Math.min(me.coins, randInt(50, 150));
      me.coins -= fine; he.coins += fine; store.save();
      return ctx.reply(`🚨 ${mentionHtml(ctx.from)} s’est fait attraper et paie <b>${fine}</b> 🪙 d’amende à ${mentionHtml(t)} !`);
    },
  },
];
export default defs;
