const cfg = require('../config')
const U = require('../lib/utils')

const CATS = [['general', 'GENERAL'], ['ai', 'IA & CHAT'], ['download', 'TELECHARGEMENT'], ['tools', 'OUTILS'], ['media', 'MEDIA'], ['fun', 'FUN & JEUX'], ['group', 'GROUPE'], ['owner', 'OWNER']]
const ZONES = {
  paris: 'Europe/Paris', brazzaville: 'Africa/Brazzaville', kinshasa: 'Africa/Kinshasa', abidjan: 'Africa/Abidjan', dakar: 'Africa/Dakar', douala: 'Africa/Douala',
  yaounde: 'Africa/Douala', lagos: 'Africa/Lagos', libreville: 'Africa/Libreville', cotonou: 'Africa/Porto-Novo', lome: 'Africa/Lome', bamako: 'Africa/Bamako',
  casablanca: 'Africa/Casablanca', alger: 'Africa/Algiers', tunis: 'Africa/Tunis', caire: 'Africa/Cairo', londres: 'Europe/London', london: 'Europe/London',
  bruxelles: 'Europe/Brussels', montreal: 'America/Toronto', 'new york': 'America/New_York', tokyo: 'Asia/Tokyo', dubai: 'Asia/Dubai', pekin: 'Asia/Shanghai', moscou: 'Europe/Moscow'
}

module.exports = [
  {
    name: 'menu', aliases: ['start', 'commands'], cat: 'general', desc: 'Affiche toutes les commandes',
    run: async (c) => {
      const { list } = require('../lib/registry')
      const p = c.prefix
      let out = U.infoBox([`${U.mono('prefix')} : ${p}`, `${U.mono('commandes')} : ${list.length}`, `${U.mono('mode')} : ${c.settings.mode}`])
      for (const [k, t] of CATS) {
        const cmds = list.filter((x) => x.cat === k).map((x) => p + x.name)
        if (cmds.length) out += '\n\n' + U.box(U.mono(t), cmds)
      }
      out += `\n\n💡 ${p}help <commande> pour le détail\n💬 ${p}bot <message> pour discuter avec moi`
      await c.reply(out)
    }
  },
  {
    name: 'help', aliases: ['aide', 'h'], cat: 'general', desc: "Aide sur une commande", usage: 'help song',
    run: async (c) => {
      const { map } = require('../lib/registry')
      const cmd = map.get((c.args[0] || '').replace(c.prefix, '').toLowerCase())
      if (!cmd) return map.get('menu').run(c)
      await c.reply(`📖 *${c.prefix}${cmd.name}*\n${cmd.desc}\n\n${cmd.usage ? `Exemple : ${c.prefix}${cmd.usage}\n` : ''}${cmd.aliases?.length ? `Alias : ${cmd.aliases.map((a) => c.prefix + a).join(', ')}\n` : ''}${cmd.owner ? '🔒 Owner uniquement\n' : ''}${cmd.admin ? '🛡️ Admins de groupe\n' : ''}`)
    }
  },
  {
    name: 'ping', aliases: ['p'], cat: 'general', desc: 'Vitesse de réponse du bot',
    run: async (c) => {
      const t = Date.now()
      await c.sock.sendPresenceUpdate('available', c.jid).catch(() => {})
      await c.reply(`🏓 Pong ! *${Date.now() - t} ms*`)
    }
  },
  {
    name: 'uptime', aliases: ['runtime'], cat: 'general', desc: 'Depuis quand le bot est en ligne',
    run: async (c) => c.reply(`⏱️ Serveur actif depuis : *${U.runtime(process.uptime())}*\n📱 Cette session : *${U.runtime((Date.now() - c.sess.startedAt) / 1000)}*`)
  },
  {
    name: 'owner', aliases: ['creator', 'dev'], cat: 'general', desc: 'Contact du propriétaire',
    run: async (c) => {
      const vcard = `BEGIN:VCARD\nVERSION:3.0\nFN:${cfg.ownerName}\nORG:${cfg.botName};\nTEL;type=CELL;type=VOICE;waid=${cfg.ownerNumber}:+${cfg.ownerNumber}\nEND:VCARD`
      await c.send({ contacts: { displayName: cfg.ownerName, contacts: [{ vcard }] } })
      await c.reply(`👑 *Owner* : ${cfg.ownerName}\n📞 wa.me/${cfg.ownerNumber}\n✈️ Telegram : @${cfg.ownerTelegram}`)
    }
  },
  { name: 'channel', aliases: ['chaine'], cat: 'general', desc: 'Chaîne WhatsApp officielle', run: async (c) => c.reply(`📢 *Chaîne WhatsApp*\n${cfg.channel}`) },
  { name: 'youtube', aliases: ['yt'], cat: 'general', desc: 'Chaîne YouTube du owner', run: async (c) => c.reply(`▶️ *Chaîne YouTube*\n${cfg.youtube}`) },
  {
    name: 'botinfo', aliases: ['info'], cat: 'general', desc: 'Informations techniques du bot',
    run: async (c) => {
      const { list } = require('../lib/registry')
      const S = require('../lib/session')
      await c.reply(U.infoBox([
        `${U.mono('commandes')} : ${list.length}`, `${U.mono('sessions')} : ${S.count()}`, `${U.mono('ram')} : ${U.bytes(process.memoryUsage().rss)}`,
        `${U.mono('node')} : ${process.versions.node}`, `${U.mono('uptime')} : ${U.runtime(process.uptime())}`
      ]))
    }
  },
  {
    name: 'time', aliases: ['heure'], cat: 'general', desc: "Heure dans une ville ou un fuseau", usage: 'time Paris',
    run: async (c) => {
      const q = c.text.toLowerCase().trim()
      const tz = q ? ZONES[q] || c.text.trim().replace(/\s+/g, '_') : cfg.timezone
      try {
        const t = new Date().toLocaleString('fr-FR', { timeZone: tz, dateStyle: 'full', timeStyle: 'medium' })
        await c.reply(`🕐 *${tz}*\n${t}`)
      } catch { await c.reply(`❌ Fuseau inconnu. Essaie une ville (Paris, Kinshasa...) ou un fuseau comme Europe/Paris.`) }
    }
  },
  { name: 'date', aliases: ['jour'], cat: 'general', desc: "Date d'aujourd'hui", run: async (c) => c.reply(`📅 ${U.nowFr()}`) },
  {
    name: 'jid', cat: 'general', desc: 'Affiche les identifiants (chat / utilisateur)',
    run: async (c) => c.reply(`🆔 Chat : ${c.jid}\n👤 Toi : ${c.sender}${c.quoted ? `\n↩️ Cité : ${c.quoted.sender}` : ''}`)
  },
  {
    name: 'stats', cat: 'general', desc: 'Statistiques du bot',
    run: async (c) => c.reply(`📊 *Statistiques*\n💬 Messages lus : ${U.stats.messages}\n⚙️ Commandes exécutées : ${U.stats.commands}\n🧠 RAM : ${U.bytes(process.memoryUsage().rss)}`)
  }
].map((x) => ({ ...x, cat: x.cat || 'general' }))
