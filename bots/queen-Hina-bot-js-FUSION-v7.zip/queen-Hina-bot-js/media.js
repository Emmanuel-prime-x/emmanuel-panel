// Envoi de fichiers locaux avec cache du file_id Telegram (un fichier n'est envoyé qu'une fois en upload).
import fs from 'node:fs';
import path from 'node:path';
import * as store from './store.js';

export const AUDIO_EXT = ['.mp3', '.m4a', '.ogg', '.oga', '.wav', '.flac', '.opus', '.aac'];
export const PHOTO_EXT = ['.jpg', '.jpeg', '.png', '.webp'];
export const VIDEO_EXT = ['.mp4', '.mov', '.mkv', '.webm'];
export const MAX_UPLOAD = 49 * 1024 * 1024;

export function listFiles(dir, exts) {
  try {
    return fs.readdirSync(dir)
      .filter((f) => !f.startsWith('.') && exts.includes(path.extname(f).toLowerCase()))
      .sort((a, b) => a.localeCompare(b))
      .map((f) => path.join(dir, f));
  } catch {
    return [];
  }
}

const fileKey = (file) => {
  const st = fs.statSync(file);
  return { key: `${path.basename(file)}|${st.size}|${Math.floor(st.mtimeMs)}`, size: st.size };
};

function extractFileId(kind, msg) {
  const m = msg?.[kind] ?? msg?.document;
  if (Array.isArray(m)) return m[m.length - 1]?.file_id;
  return m?.file_id;
}

/** Envoie un fichier local (photo, video, audio, document). Utilise le cache file_id si possible. */
export async function sendLocal(ctx, kind, file, extra = {}) {
  const { key, size } = fileKey(file);
  if (size > MAX_UPLOAD) throw Object.assign(new Error('file is too big'), { description: 'file is too big' });
  const cached = store.db.songCache[key];
  if (cached) {
    try {
      return await ctx.media(kind, cached, extra);
    } catch (e) {
      if (!/wrong file identifier|file_id|wrong remote file/i.test(e.description || e.message)) throw e;
      delete store.db.songCache[key];
    }
  }
  const sent = await ctx.media(kind, { path: file, filename: path.basename(file) }, extra);
  const id = extractFileId(kind, sent);
  if (id) {
    store.db.songCache[key] = id;
    store.save();
  }
  return sent;
}
