// Registre unique des commandes + analyse du texte (/cmd, .cmd, !cmd) + contexte pratique pour les handlers.
import { isOwner } from './config.js';
import { deaccent, userName, esc } from './util.js';
import { friendlyTgError, TgError } from './telegram.js';

export const commands = new Map();   // nom ou alias -> définition
export const defs = [];              // définitions uniques
export const hooks = [];
export const errorLog = [];
export function logError(where, e) {
  errorLog.push(`${new Date().toISOString().slice(11, 19)} ${where} : ${String(e?.stack || e?.message || e).split('\n').slice(0, 2).join(' | ').slice(0, 300)}`);
  while (errorLog.length > 25) errorLog.shift();
}             // fonctions (ctx) => true si le message a été consommé

export function register(def) {
  const names = [def.name, ...(def.aliases || [])];
  for (const n of names) {
    if (!/^[a-z0-9_]{1,32}$/.test(n)) throw new Error(`Nom de commande invalide : ${n}`);
    if (commands.has(n)) throw new Error(`Commande en double : ${n}`);
    commands.set(n, def);
  }
  defs.push(def);
}
export const registerAll = (arr) => arr.forEach(register);

const CMD_RE = /^([\/.!])([\p{L}0-9_]{1,40})(?:@(\w+))?(?:\s+([\s\S]*))?$/u;

export function parseCommand(text, botUsername) {
  const m = String(text || '').trim().match(CMD_RE);
  if (!m) return null;
  const [, prefix, rawName, target, rest] = m;
  if (target && botUsername && target.toLowerCase() !== botUsername.toLowerCase()) return null; // destinée à un autre bot
  const name = deaccent(rawName).toLowerCase();
  return { prefix, name, args: (rest || '').trim() };
}

const adminCache = new Map();

export function makeCtx(tg, msg, extra = {}) {
  const chat = msg.chat;
  const from = msg.from || { id: chat.id, first_name: msg.sender_chat?.title || 'anonyme' };
  const thread = msg.is_topic_message ? msg.message_thread_id : undefined;
  const text = msg.text ?? msg.caption ?? '';
  const ctx = {
    tg, msg, chat, from, text,
    args: extra.args || '',
    argv: (extra.args || '').split(/\s+/).filter(Boolean),
    command: extra.command || '',
    isPrivate: chat.type === 'private',
    isGroup: chat.type === 'group' || chat.type === 'supergroup',
    isOwner: isOwner(from.id),
    name: userName(from),
    target: msg.reply_to_message?.from && !msg.reply_to_message.from.is_bot ? msg.reply_to_message.from : null,
    thread,
    reply: (t, o = {}) => tg.sendMessage(chat.id, t, { reply_to: msg.message_id, thread, ...o }),
    say: (t, o = {}) => tg.sendMessage(chat.id, t, { thread, ...o }),
    media: (kind, src, o = {}) => tg.sendMedia(kind, chat.id, src, { reply_to: msg.message_id, thread, ...o }),
    async isAdmin(userId = from.id) {
      if (isOwner(userId)) return true;
      if (chat.type === 'private') return true;
      if (msg.sender_chat && msg.sender_chat.id === chat.id) return true;
      const key = `${chat.id}:${userId}`;
      const hit = adminCache.get(key);
      if (hit && Date.now() - hit.t < 20000) return hit.v;
      let v = false;
      try {
        const mem = await tg.call('getChatMember', { chat_id: chat.id, user_id: userId }, { retries: 1 });
        v = mem.status === 'administrator' || mem.status === 'creator';
      } catch { v = false; }
      adminCache.set(key, { v, t: Date.now() });
      if (adminCache.size > 500) adminCache.clear();
      return v;
    },
    async botIsAdmin() {
      try {
        const mem = await tg.call('getChatMember', { chat_id: chat.id, user_id: tg.me.id }, { retries: 1 });
        return mem.status === 'administrator';
      } catch { return false; }
    },
  };
  return ctx;
}

// Lance une commande avec toutes les protections : permissions, erreurs, délai maximum.
export async function runCommand(def, ctx) {
  if (def.owner && !ctx.isOwner) return ctx.reply('🔒 Cette commande est réservée à mon créateur.');
  if (def.group && !ctx.isGroup) return ctx.reply('Cette commande fonctionne uniquement dans un groupe 😉');
  if (def.admin && !(await ctx.isAdmin())) return ctx.reply('Seuls les admins du groupe peuvent faire ça 😉');
  if (def.needsTarget && !ctx.target) return ctx.reply(def.targetHelp || 'Réponds au message de la personne concernée avec cette commande.');
  let timer;
  try {
    await Promise.race([
      Promise.resolve(def.run(ctx)),
      new Promise((_, rej) => { timer = setTimeout(() => rej(new Error('délai de la commande dépassé')), 90000); }),
    ]);
  } catch (e) {
    console.error(`[cmd:${def.name}]`, e instanceof TgError ? e.message : e);
    logError(`/${def.name}`, e);
    const msg = e instanceof TgError ? friendlyTgError(e) : 'Oups, un petit souci est survenu 😅 Réessaie dans un instant.';
    try { await ctx.reply(esc(msg)); } catch { /* on ne propage jamais */ }
  } finally {
    clearTimeout(timer);
  }
}
