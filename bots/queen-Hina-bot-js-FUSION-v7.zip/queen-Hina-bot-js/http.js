import { sleep } from './util.js';

const UA = 'QueenHinaBot/2.0 (+https://t.me/emmanuelprimex)';

export class HttpError extends Error {
  constructor(message, status, body) {
    super(message);
    this.status = status;
    this.body = body;
  }
}

// fetch avec délai maximum, nouvelles tentatives (GET uniquement) et erreurs propres.
export async function request(url, { method = 'GET', headers = {}, body, timeout = 10000, retries = 1 } = {}) {
  let lastErr;
  for (let attempt = 0; attempt <= retries; attempt += 1) {
    try {
      const res = await fetch(url, {
        method,
        headers: { 'user-agent': UA, accept: 'application/json, */*', ...headers },
        body,
        signal: AbortSignal.timeout(timeout),
        redirect: 'follow',
      });
      if (res.ok) return res;
      const text = await res.text().catch(() => '');
      const err = new HttpError(`HTTP ${res.status}`, res.status, text.slice(0, 500));
      if (method === 'GET' && (res.status >= 500 || res.status === 429) && attempt < retries) {
        lastErr = err;
        await sleep(400 * (attempt + 1));
        continue;
      }
      throw err;
    } catch (e) {
      if (e instanceof HttpError) throw e;
      lastErr = new HttpError(e?.name === 'TimeoutError' ? 'délai dépassé' : `réseau : ${e?.message || e}`, 0);
      if (method === 'GET' && attempt < retries) {
        await sleep(400 * (attempt + 1));
        continue;
      }
      throw lastErr;
    }
  }
  throw lastErr;
}

export async function getJson(url, opts) {
  const res = await request(url, opts);
  try {
    return await res.json();
  } catch {
    throw new HttpError('réponse illisible', res.status);
  }
}

export async function getBuffer(url, opts = {}) {
  const res = await request(url, { timeout: 30000, ...opts });
  return Buffer.from(await res.arrayBuffer());
}
