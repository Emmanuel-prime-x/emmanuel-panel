const U = require('../lib/utils')
const cfg = require('../config')

const use = (c, s) => c.reply(`ℹ️ Usage : ${c.prefix}${s}`)
const A = { group: true, admin: true }
const AB = { group: true, admin: true, botAdmin: true }
const mentionId = (p) => p.phoneNumber || p.id

async function participantAction(c, action, okText) {
  const t = await c.getTarget()
  if (!t) return use(c, `${c.cmd} @membre  (ou réponds à son message)`)
  const r = await c.sock.groupParticipantsUpdate(c.jid, [t], action)
  const st = String(r?.[0]?.status || '200')
  if (st !== '200') return c.reply(`❌ Action impossible (code ${st}). ${action === 'add' ? 'La personne a peut-être restreint les invitations.' : ''}`)
  await c.reply(`${okText} @${U.num(t)}`, { mentions: [t] })
}

module.exports = [
  {
    name: 'tagall', aliases: ['everyone', 'all'], cat: 'group', ...A, desc: 'Mentionne tous les membres', usage: 'tagall réunion à 20h',
    run: async (c) => {
      const meta = await c.meta()
      const ids = meta.participants.map(mentionId)
      await c.sock.sendMessage(c.jid, { text: `📢 *ATTENTION TOUT LE MONDE*\n${c.text ? `\n💬 ${c.text}\n` : ''}\n${ids.map((j) => `• @${U.num(j)}`).join('\n')}\n\n${cfg.botName}`, mentions: ids }, { quoted: c.m })
    }
  },
  {
    name: 'hidetag', aliases: ['tag', 'notify'], cat: 'group', ...A, desc: 'Message qui notifie tout le monde sans afficher les tags', usage: 'hidetag salut !',
    run: async (c) => {
      const meta = await c.meta()
      await c.sock.sendMessage(c.jid, { text: `${c.input || '📢'}\n\n${cfg.botName}`, mentions: meta.participants.map(mentionId) })
    }
  },
  { name: 'kick', aliases: ['remove', 'ban-member'], cat: 'group', ...AB, desc: 'Retire un membre', usage: 'kick @user', run: (c) => participantAction(c, 'remove', '👢 Retiré :') },
  { name: 'add', cat: 'group', ...AB, desc: 'Ajoute un membre par numéro', usage: 'add 242066474961', run: (c) => participantAction(c, 'add', '➕ Ajouté :') },
  { name: 'promote', aliases: ['admin'], cat: 'group', ...AB, desc: 'Nomme admin', usage: 'promote @user', run: (c) => participantAction(c, 'promote', '⭐ Nouvel admin :') },
  { name: 'demote', aliases: ['unadmin'], cat: 'group', ...AB, desc: 'Retire le rôle admin', usage: 'demote @user', run: (c) => participantAction(c, 'demote', '⬇️ Plus admin :') },
  {
    name: 'link', aliases: ['grouplink', 'invite'], cat: 'group', ...AB, desc: "Lien d'invitation du groupe",
    run: async (c) => c.reply(`🔗 https://chat.whatsapp.com/${await c.sock.groupInviteCode(c.jid)}`)
  },
  {
    name: 'revoke', aliases: ['resetlink'], cat: 'group', ...AB, desc: "Réinitialise le lien d'invitation",
    run: async (c) => { await c.sock.groupRevokeInvite(c.jid); await c.reply('♻️ Ancien lien annulé. Utilise ' + c.prefix + 'link pour le nouveau.') }
  },
  {
    name: 'setname', aliases: ['gname'], cat: 'group', ...AB, desc: 'Change le nom du groupe', usage: 'setname Super Groupe',
    run: async (c) => { if (!c.text) return use(c, 'setname <nom>'); await c.sock.groupUpdateSubject(c.jid, c.text.slice(0, 100)); await c.reply('✅ Nom du groupe mis à jour.') }
  },
  {
    name: 'setdesc', aliases: ['gdesc'], cat: 'group', ...AB, desc: 'Change la description', usage: 'setdesc Bienvenue !',
    run: async (c) => { if (!c.text) return use(c, 'setdesc <texte>'); await c.sock.groupUpdateDescription(c.jid, c.text.slice(0, 2000)); await c.reply('✅ Description mise à jour.') }
  },
  {
    name: 'open', aliases: ['unmute'], cat: 'group', ...AB, desc: 'Autorise tout le monde à écrire',
    run: async (c) => { await c.sock.groupSettingUpdate(c.jid, 'not_announcement'); await c.reply('🔓 Le groupe est ouvert : tout le monde peut écrire.') }
  },
  {
    name: 'close', aliases: ['mute'], cat: 'group', ...AB, desc: 'Seuls les admins peuvent écrire',
    run: async (c) => { await c.sock.groupSettingUpdate(c.jid, 'announcement'); await c.reply('🔒 Le groupe est fermé : seuls les admins peuvent écrire.') }
  },
  {
    name: 'antilink', cat: 'group', ...A, desc: 'Supprime les liens de groupe (3 avertissements = exclusion)', usage: 'antilink on',
    run: async (c) => {
      const v = U.onoff(c.args[0])
      if (v === null) return c.reply(`🚫 Anti-lien : *${c.settings.antilink[c.jid] ? 'ON' : 'OFF'}*\nUtilise ${c.prefix}antilink on/off (le bot doit être admin)`)
      if (v) c.settings.antilink[c.jid] = true; else delete c.settings.antilink[c.jid]
      c.saveSettings()
      await c.reply(`🚫 Anti-lien ${v ? 'activé' : 'désactivé'}.`)
    }
  },
  {
    name: 'welcome', aliases: ['bienvenue'], cat: 'group', ...A, desc: "Messages d'arrivée / départ", usage: 'welcome on',
    run: async (c) => {
      const v = U.onoff(c.args[0])
      if (v === null) return c.reply(`👋 Bienvenue : *${c.settings.welcome[c.jid] ? 'ON' : 'OFF'}*\nUtilise ${c.prefix}welcome on/off`)
      if (v) c.settings.welcome[c.jid] = true; else delete c.settings.welcome[c.jid]
      c.saveSettings()
      await c.reply(`👋 Messages de bienvenue ${v ? 'activés' : 'désactivés'}.`)
    }
  },
  {
    name: 'warn', aliases: ['avertir'], cat: 'group', ...A, desc: 'Avertit un membre (3 = exclusion)', usage: 'warn @user',
    run: async (c) => {
      const t = await c.getTarget()
      if (!t) return use(c, 'warn @membre')
      const n = U.num(t)
      c.settings.warns[c.jid] = c.settings.warns[c.jid] || {}
      const count = (c.settings.warns[c.jid][n] = (c.settings.warns[c.jid][n] || 0) + 1)
      c.saveSettings()
      await c.reply(`⚠️ @${n} avertissement *${count}/3*`, { mentions: [t] })
      if (count >= 3) {
        if (!c.isBotAdmin) return c.reply("Je ne peux pas l'exclure : je ne suis pas admin.")
        await c.sock.groupParticipantsUpdate(c.jid, [t], 'remove')
        c.settings.warns[c.jid][n] = 0; c.saveSettings()
        await c.reply(`👢 @${n} exclu après 3 avertissements.`, { mentions: [t] })
      }
    }
  },
  {
    name: 'resetwarn', aliases: ['unwarn'], cat: 'group', ...A, desc: 'Remet les avertissements à zéro', usage: 'resetwarn @user',
    run: async (c) => {
      const t = await c.getTarget()
      if (!t) return use(c, 'resetwarn @membre')
      if (c.settings.warns[c.jid]) delete c.settings.warns[c.jid][U.num(t)]
      c.saveSettings()
      await c.reply(`✅ Avertissements de @${U.num(t)} effacés.`, { mentions: [t] })
    }
  },
  {
    name: 'admins', aliases: ['listadmin'], cat: 'group', group: true, desc: 'Liste des admins',
    run: async (c) => {
      const meta = await c.meta()
      const admins = meta.participants.filter((p) => p.admin)
      await c.reply(`🛡️ *Admins (${admins.length})*\n\n${admins.map((p) => `• @${U.num(mentionId(p))}${p.admin === 'superadmin' ? ' 👑' : ''}`).join('\n')}`, { mentions: admins.map(mentionId) })
    }
  },
  {
    name: 'groupinfo', aliases: ['ginfo', 'infogroupe'], cat: 'group', group: true, desc: 'Informations du groupe',
    run: async (c) => {
      const m = await c.meta()
      await c.reply(`👥 *${m.subject}*\n\n🆔 ${m.id}\n👤 Membres : ${m.participants.length}\n🛡️ Admins : ${m.participants.filter((p) => p.admin).length}\n📅 Créé le : ${new Date(m.creation * 1000).toLocaleDateString('fr-FR')}\n🔒 Écriture : ${m.announce ? 'admins seulement' : 'tout le monde'}\n\n📝 ${m.desc || 'Pas de description'}`)
    }
  },
  {
    name: 'del', aliases: ['delete', 'supprimer'], cat: 'group', ...AB, desc: 'Supprime le message auquel tu réponds', usage: 'del (en répondant à un message)',
    run: async (c) => {
      if (!c.quoted) return c.reply('↩️ Réponds au message à supprimer.')
      await c.sock.sendMessage(c.jid, { delete: { remoteJid: c.jid, fromMe: false, id: c.quoted.id, participant: c.quoted.sender } })
    }
  },
  {
    name: 'poll', aliases: ['sondage'], cat: 'group', group: true, desc: 'Crée un sondage', usage: 'poll Pizza ou burger ? | Pizza | Burger',
    run: async (c) => {
      const parts = c.text.split('|').map((x) => x.trim()).filter(Boolean)
      if (parts.length < 3) return use(c, 'poll Question | Option 1 | Option 2 | ...')
      await c.sock.sendMessage(c.jid, { poll: { name: parts[0].slice(0, 200), values: parts.slice(1, 13), selectableCount: 1 } })
      await c.footer()
    }
  }
]
