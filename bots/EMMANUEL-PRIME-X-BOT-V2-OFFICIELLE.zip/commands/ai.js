const AI = require('../lib/ai')
const U = require('../lib/utils')
const cfg = require('../config')

const key = (c) => `${c.number}_${c.senderNum}`
const use = (c, s) => c.reply(`ℹ️ Usage : ${c.prefix}${s}`)

module.exports = [
  {
    name: 'ai', aliases: ['ask', 'gpt', 'chatgpt', 'gemini'], cat: 'ai', desc: "Discute avec l'IA (ChatGPT / Gemini)", usage: 'ai explique la gravité',
    run: async (c) => { if (!c.input) return use(c, 'ai <question>'); c.typing(); await c.reply(await AI.ask(c.input)) }
  },
  {
    name: 'imagine', aliases: ['img', 'image'], cat: 'ai', desc: "Génère une image à partir d'un texte", usage: 'imagine un lion astronaute',
    run: async (c) => {
      if (!c.text) return use(c, 'imagine <description>')
      await c.react('🎨')
      const url = `https://image.pollinations.ai/prompt/${encodeURIComponent(c.text)}?width=1024&height=1024&nologo=true&seed=${U.rand(1, 999999)}`
      await c.image(url, `🎨 ${c.text}`)
    }
  },
  {
    name: 'translate', aliases: ['tr', 'trad'], cat: 'ai', desc: 'Traduit un texte (réponds à un message ou écris-le)', usage: 'translate en Bonjour tout le monde',
    run: async (c) => {
      let lang = 'fr', text = c.text
      if (/^[a-z]{2}(-[A-Za-z]{2,4})?$/.test(c.args[0] || '') && (c.args.length > 1 || c.quoted?.text)) { lang = c.args[0]; text = c.args.slice(1).join(' ') || c.quoted?.text }
      else if (!text) text = c.quoted?.text || ''
      if (!text) return use(c, 'translate <langue> <texte>  (ex: translate en Salut)')
      const r = await U.translate(text, lang)
      await c.reply(`🌍 *${r.from} → ${lang}*\n\n${r.text}`)
    }
  },
  {
    name: 'summarize', aliases: ['resume', 'tldr'], cat: 'ai', desc: 'Résume un texte (réponds à un message)',
    run: async (c) => { if (!c.input) return use(c, 'summarize <texte> (ou réponds à un message)'); c.typing(); await c.reply(await AI.ask(`Résume ce texte en quelques phrases claires, dans sa langue :\n\n${c.input}`)) }
  },
  {
    name: 'fix', aliases: ['corrige'], cat: 'ai', desc: "Corrige l'orthographe et la grammaire",
    run: async (c) => { if (!c.input) return use(c, 'fix <texte>'); c.typing(); await c.reply(await AI.ask(`Corrige l'orthographe et la grammaire de ce texte sans changer le sens. Renvoie uniquement le texte corrigé :\n\n${c.input}`, undefined, { temperature: 0.2 })) }
  },
  {
    name: 'tts', aliases: ['voice', 'say'], cat: 'ai', desc: 'Transforme un texte en message vocal', usage: 'tts fr Bonjour !',
    run: async (c) => {
      let lang = 'fr', text = c.text || c.quoted?.text || ''
      if (/^[a-z]{2}(-[A-Za-z]{2})?$/.test(c.args[0] || '') && (c.args.length > 1)) { lang = c.args[0]; text = c.args.slice(1).join(' ') }
      if (!text) return use(c, 'tts [langue] <texte>')
      const parts = []
      for (let rest = text.slice(0, 900).trim(); rest.length;) { let cut = rest.length <= 180 ? rest.length : rest.lastIndexOf(' ', 180); if (cut < 40) cut = Math.min(180, rest.length); parts.push(rest.slice(0, cut).trim()); rest = rest.slice(cut).trim() }
      const bufs = []
      for (const p of parts.slice(0, 5)) bufs.push(await U.getBuffer(`https://translate.google.com/translate_tts?ie=UTF-8&client=tw-ob&tl=${lang}&q=${encodeURIComponent(p.trim())}`, { maxBytes: 5e6 }))
      await c.audio(Buffer.concat(bufs), 'audio/mpeg', 'tts')
    }
  },
  {
    name: 'code', aliases: ['dev-ai'], cat: 'ai', desc: 'Génère du code', usage: 'code python un jeu du pendu',
    run: async (c) => { if (!c.text) return use(c, 'code <langage> <ce que tu veux>'); c.typing(); await c.reply(await AI.ask(`Écris le code demandé, complet et fonctionnel, dans un bloc de code, avec 2 lignes d'explication maximum : ${c.text}`, undefined, { max: 900, temperature: 0.3 })) }
  },
  {
    name: 'explain', aliases: ['explique'], cat: 'ai', desc: "Explique simplement n'importe quoi", usage: 'explain la blockchain',
    run: async (c) => { if (!c.input) return use(c, 'explain <sujet>'); c.typing(); await c.reply(await AI.ask(`Explique simplement, comme à un ami, avec un exemple concret : ${c.input}`)) }
  }
]
