const AI = require('../lib/ai')
const U = require('../lib/utils')

const trivia = new Map()
const JOKES = [
  "Pourquoi les plongeurs plongent-ils toujours en arrière ? Parce que sinon ils tombent dans le bateau. 😄",
  "Que dit un escargot sur le dos d'une tortue ? « Wouhou, ça va vite ! » 🐌",
  "Pourquoi les poules n'ont-elles pas de dents ? Parce qu'elles ont un bec. 🐔",
  "Quel est le comble pour un électricien ? De ne pas être au courant. ⚡",
  "Comment appelle-t-on un chat tombé dans un pot de peinture le jour de Noël ? Un chat-peint de Noël. 🎄",
  "Que fait une fraise sur un cheval ? Tagada tagada ! 🍓",
  "Pourquoi le livre de maths est triste ? Parce qu'il a trop de problèmes. 📘",
  "Quel est le comble pour un jardinier ? De raconter des salades. 🥬",
  "Que dit le 0 au 8 ? « Sympa ta ceinture ! » 😂",
  "Pourquoi les fantômes sont-ils de mauvais menteurs ? Parce qu'on voit à travers eux. 👻"
]
const TRUTHS = ["Quel est ton plus gros mensonge ?", "Quelle est la chose la plus gênante qui te soit arrivée ?", "Quel est ton plus grand rêve secret ?", "As-tu déjà eu un crush sur un(e) ami(e) ici ?", "Quelle est ta plus grande peur ?", "Quel est le dernier message que tu as regretté d'avoir envoyé ?", "Quelle habitude bizarre as-tu ?", "Quelle est la plus grosse bêtise de ton enfance ?", "Qui stalkes-tu le plus sur les réseaux ?", "Quel talent caché as-tu ?"]
const DARES = ["Envoie un vocal en chantant ton refrain préféré 🎤", "Change ta photo de profil pour une image ridicule pendant 1 heure", "Écris « je suis le roi/la reine du groupe » en statut", "Imite un animal dans un vocal 🐒", "Envoie ton dernier emoji utilisé 10 fois", "Fais un compliment sincère à chaque membre en ligne", "Raconte une blague nulle, sinon gage !", "Envoie un selfie avec la pire grimace possible 🤪", "Parle uniquement en rimes pendant 5 minutes", "Écris ton nom avec les pieds et montre-le (photo)"]
const BALL = ["Oui, sans aucun doute ✅", "C'est certain 💯", "Très probablement 👍", "Les signes sont bons ✨", "Demande-moi plus tard 🤔", "Concentre-toi et redemande 🧘", "Je préfère ne pas te répondre 🤐", "N'y compte pas ❌", "Ma réponse est non 🚫", "Très douteux 😬", "Absolument pas 🙅", "Oui, fonce ! 🚀"]
const COMPLIMENTS = ["tu illumines toute la conversation ✨", "tu as un cœur en or 💛", "ton sourire est contagieux 😄", "tu es vraiment quelqu'un de spécial 🌟", "tu inspires les gens autour de toi 💪", "ton intelligence est impressionnante 🧠", "tu es une belle personne, à l'intérieur comme à l'extérieur 🌹", "on est chanceux de t'avoir ici 🙌"]
const ROASTS = ["Tu es la preuve que même le Wi-Fi peut être plus stable qu'une personne. 📶", "Ton sens de l'orientation est tel que tu pourrais te perdre dans un ascenseur. 🛗", "Tu dis « j'arrive dans 5 minutes » comme si le temps n'existait pas. ⏰", "Même ton ombre préfère marcher derrière toi. 😂"]
const bar = (p) => '█'.repeat(Math.round(p / 10)) + '░'.repeat(10 - Math.round(p / 10))
const img = (name, aliases, desc, fetcher, label) => ({ name, aliases, cat: 'fun', desc, run: async (c) => { await c.image(await fetcher(), label) } })

module.exports = [
  {
    name: 'joke', aliases: ['blague'], cat: 'fun', desc: 'Une blague au hasard',
    run: async (c) => {
      let t
      try { t = await AI.ask("Raconte une blague courte et drôle en français, tout public. Uniquement la blague, avec un emoji.", undefined, { temperature: 1, max: 200 }) } catch { t = U.pick(JOKES) }
      await c.reply('😂 ' + t)
    }
  },
  {
    name: 'fact', aliases: ['savoir'], cat: 'fun', desc: 'Un fait surprenant',
    run: async (c) => {
      const j = await U.getJson('https://uselessfacts.jsph.pl/api/v2/facts/random?language=en')
      const t = await U.translate(j.text, 'fr').catch(() => ({ text: j.text }))
      await c.reply(`🧠 *Le saviez-vous ?*\n\n${t.text}`)
    }
  },
  {
    name: 'quote', aliases: ['citation'], cat: 'fun', desc: 'Une citation inspirante',
    run: async (c) => {
      let t
      try { t = await AI.ask('Donne une citation inspirante authentique, en français, suivie de son auteur. Uniquement la citation.', undefined, { temperature: 1, max: 150 }) } catch {
        const j = await U.getJson('https://zenquotes.io/api/random')
        t = `${(await U.translate(j[0].q, 'fr').catch(() => ({ text: j[0].q }))).text}\n— ${j[0].a}`
      }
      await c.reply(`💬 ${t}`)
    }
  },
  {
    name: 'meme', cat: 'fun', desc: 'Un meme au hasard',
    run: async (c) => {
      const j = await U.getJson('https://meme-api.com/gimme')
      await c.image(j.url, `😆 ${j.title}`)
    }
  },
  img('cat', ['kitty'], 'Photo de chat 🐱', async () => (await U.getJson('https://api.thecatapi.com/v1/images/search'))[0].url, '🐱 Miaou !'),
  img('dog', ['chien'], 'Photo de chien 🐶', async () => (await U.getJson('https://dog.ceo/api/breeds/image/random')).message, '🐶 Ouaf !'),
  img('fox', ['renard'], 'Photo de renard 🦊', async () => (await U.getJson('https://randomfox.ca/floof/')).image, '🦊 Salut !'),
  {
    name: '8ball', aliases: ['boule'], cat: 'fun', desc: 'Pose une question à la boule magique', usage: '8ball vais-je réussir ?',
    run: async (c) => { if (!c.text) return c.reply(`🎱 Pose-moi une question : ${c.prefix}8ball <question>`); await c.reply(`🎱 *${c.text}*\n\n${U.pick(BALL)}`) }
  },
  {
    name: 'dice', aliases: ['de'], cat: 'fun', desc: 'Lance un dé', usage: 'dice 20',
    run: async (c) => { const n = Math.min(1000, Math.max(2, parseInt(c.args[0]) || 6)); await c.reply(`🎲 Dé à ${n} faces : *${U.rand(1, n)}*`) }
  },
  { name: 'coin', aliases: ['pile'], cat: 'fun', desc: 'Pile ou face', run: async (c) => c.reply(`🪙 *${Math.random() < 0.5 ? 'PILE' : 'FACE'}*`) },
  {
    name: 'rps', aliases: ['pfc'], cat: 'fun', desc: 'Pierre, feuille, ciseaux', usage: 'rps pierre',
    run: async (c) => {
      const map = { pierre: '🪨', feuille: '📄', ciseaux: '✂️', rock: '🪨', paper: '📄', scissors: '✂️' }
      const norm = { rock: 'pierre', paper: 'feuille', scissors: 'ciseaux' }
      let me = (c.args[0] || '').toLowerCase()
      me = norm[me] || me
      if (!map[me]) return c.reply(`✊ Choisis : ${c.prefix}rps pierre | feuille | ciseaux`)
      const bot = U.pick(['pierre', 'feuille', 'ciseaux'])
      const win = { pierre: 'ciseaux', feuille: 'pierre', ciseaux: 'feuille' }
      const res = me === bot ? '🤝 Égalité !' : win[me] === bot ? '🏆 Tu gagnes !' : '😎 Je gagne !'
      await c.reply(`Toi : ${map[me]}  VS  Moi : ${map[bot]}\n\n${res}`)
    }
  },
  {
    name: 'ship', aliases: ['love'], cat: 'fun', desc: 'Compatibilité amoureuse', usage: 'ship Awa | Kevin',
    run: async (c) => {
      let names = c.text.split(/[|&+]|\bet\b/i).map((x) => x.trim()).filter(Boolean)
      if (names.length < 2 && c.mentioned.length >= 2) names = c.mentioned.map((j) => '@' + U.num(j))
      if (names.length < 2) return c.reply(`💘 Utilise : ${c.prefix}ship Nom1 | Nom2`)
      const s = names.slice(0, 2).map((x) => x.toLowerCase()).sort().join('|')
      let h = 7
      for (const ch of s) h = (h * 31 + ch.charCodeAt(0)) % 101
      const msg = h > 80 ? 'Âmes sœurs 😍' : h > 60 ? 'Ça peut le faire 💞' : h > 40 ? 'Il faut y travailler 🤔' : 'Restez amis 😅'
      await c.reply(`💘 *${names[0]}* ❤️ *${names[1]}*\n\n${bar(h)} *${h}%*\n${msg}`)
    }
  },
  {
    name: 'rate', aliases: ['note'], cat: 'fun', desc: 'Note quelque chose sur 100', usage: 'rate ma coupe de cheveux',
    run: async (c) => { if (!c.input) return c.reply(`⭐ Utilise : ${c.prefix}rate <quelque chose>`); const n = U.rand(0, 100); await c.reply(`⭐ *${c.input}*\n\n${bar(n)} *${n}/100*`) }
  },
  {
    name: 'roast', aliases: ['clash'], cat: 'fun', desc: 'Taquine gentiment quelqu\'un', usage: 'roast @user',
    run: async (c) => {
      const who = c.mentioned[0] ? `@${U.num(c.mentioned[0])}` : c.text || 'toi'
      let t
      try { t = await AI.ask(`Écris une petite vanne taquine, drôle et bienveillante (jamais blessante, ni sur le physique, la religion, l'origine) à propos de : ${who}. Une seule phrase en français.`, undefined, { temperature: 1, max: 100 }) } catch { t = U.pick(ROASTS) }
      await c.reply(`🔥 ${who} : ${t}`, { mentions: c.mentioned })
    }
  },
  {
    name: 'compliment', aliases: ['flatter'], cat: 'fun', desc: 'Fait un compliment', usage: 'compliment @user',
    run: async (c) => {
      const who = c.mentioned[0] ? `@${U.num(c.mentioned[0])}` : c.text || (c.pushName || 'toi')
      await c.reply(`🌸 ${who}, ${U.pick(COMPLIMENTS)}`, { mentions: c.mentioned })
    }
  },
  { name: 'truth', aliases: ['verite'], cat: 'fun', desc: 'Une question vérité', run: async (c) => c.reply(`🫣 *VÉRITÉ*\n\n${U.pick(TRUTHS)}`) },
  { name: 'dare', aliases: ['action', 'gage'], cat: 'fun', desc: 'Un gage à réaliser', run: async (c) => c.reply(`😈 *ACTION*\n\n${U.pick(DARES)}`) },
  {
    name: 'trivia', aliases: ['quiz'], cat: 'fun', desc: 'Question de culture générale',
    run: async (c) => {
      const j = await U.getJson('https://opentdb.com/api.php?amount=1&type=multiple&encode=url3986')
      const q = j.results?.[0]
      if (!q) throw new Error('Pas de question disponible, réessaie.')
      const dec = decodeURIComponent
      const answer = dec(q.correct_answer)
      const options = U.shuffle([answer, ...q.incorrect_answers.map(dec)])
      const question = await U.translate(dec(q.question), 'fr').then((r) => r.text).catch(() => dec(q.question))
      trivia.set(`${c.number}:${c.jid}`, { idx: options.indexOf(answer), answer, until: Date.now() + 120000 })
      await c.reply(`🧩 *QUIZ* (${dec(q.category)})\n\n${question}\n\n${options.map((o, i) => `*${'ABCD'[i]}.* ${o}`).join('\n')}\n\n✍️ Réponds avec ${c.prefix}answer A/B/C/D (2 min)`)
    }
  },
  {
    name: 'answer', aliases: ['rep'], cat: 'fun', desc: 'Répondre au quiz', usage: 'answer B',
    run: async (c) => {
      const t = trivia.get(`${c.number}:${c.jid}`)
      if (!t || t.until < Date.now()) return c.reply(`❌ Aucun quiz en cours. Lance ${c.prefix}trivia`)
      const i = 'abcd'.indexOf((c.args[0] || '').toLowerCase())
      if (i < 0) return c.reply(`Réponds par A, B, C ou D.`)
      trivia.delete(`${c.number}:${c.jid}`)
      await c.reply(i === t.idx ? `✅ Bravo ! La réponse était bien *${t.answer}* 🎉` : `❌ Raté ! La bonne réponse était *${'ABCD'[t.idx]}. ${t.answer}*`)
    }
  },
  {
    name: 'advice', aliases: ['conseil'], cat: 'fun', desc: 'Un conseil au hasard',
    run: async (c) => {
      const j = await U.getJson('https://api.adviceslip.com/advice')
      const t = await U.translate(j.slip.advice, 'fr').catch(() => ({ text: j.slip.advice }))
      await c.reply(`💡 ${t.text}`)
    }
  }
]
