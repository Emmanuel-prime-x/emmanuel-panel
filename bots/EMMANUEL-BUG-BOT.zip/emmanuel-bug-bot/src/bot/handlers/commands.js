import {
  isOwner,
  isAdmin,
  canUseBot,
  addAdmin,
  removeAdmin,
  getAdmins,
  addPremium,
  removePremium,
  getPremiums,
  getPremiumEntry,
  isPremium,
  addVVIP,
  removeVVIP,
  getVVIPs,
  getVVIPEntry,
  isVVIP,
  getMode,
  parseDuration,
  formatDuration,
  setMode,
  getPairsForUser,
  addPairNumber,
  getAllPairs,
  removePairNumber,
  clearAllPairs,
  getUsers,
  removeUser,
  addUser,
  getBotsForUser,
  getAllBotsRaw,
  addBotEntry,
  removeBotEntry,
  findBotOwnerUid,
  createDatabaseBackup,
  restoreDatabaseBackup,
  getMaintenance,
  setMaintenance,
  isMaintenanceEnabled,
} from "../../data/database.js";
import { InputFile } from "grammy";
import fs from "fs";
import os from "os";
import path from "path";
import travas, {
  getTravasEntry,
  getTravasRegistry,
  normalizeTravasTarget,
  resolveGroupInviteTarget,
} from "../travas.js";
import { log } from "../logger.js";
import {
  initWhatsappForNumber,
  endWhatsappForNumber,
  clearAllSessions,
  getClient,
  waClients,
  clientKey,
  waitForPairSuccess as waitUntilOpen,
  sharedSessionKeyFromToken,
  describeWhatsappError,
} from "../whatsapp.js";
import {
  getVVIPUseState,
  consumeVVIPSenderUse,
  resetVVIPSenderUse,
  formatCooldownText,
} from "../vvipCooldown.js";
import {
  BOT_TOKEN,
  OWNER_ID,
  OWNER_USERNAME,
  MENU_VIDEO_URL,
  MENU_PHOTO_URL,
  MENU_MEDIA_URL,
  MENU_MEDIA_TYPE,
  MAX_PAIR_PER_USER,
  FORCE_JOIN_CHANNELS,
  BRANDING,
} from "../../config/config.js";

const START_TIME = Date.now();

export function registerCommandHandlers(bot, runtime, menu, opts = {}) {
  const pendingDatabaseRestore = new Map();
  const {
    isSubBot,
    subBotOwnerId,
    subBotToken,
    checkOwner,
    checkAdmin,
    checkAccess,
    dbScope,
    getSessionKey,
    resolveSessionKey,
    describeAssenderTarget,
    normalizeAssenderTarget,
    sanitizePhoneDigits,
    registerUserIfNeeded,
    backupUsersJsonToOwner,
    travasRun,
    actionSession,
    sendDoneCard,
    sendVVIPSelectorMenu,
    pendingAction,
    pendingTravasTarget,
    pairingLocks,
    ownerActingAs,
    getActingTarget,
    isUsingExternalSender,
  } = runtime;

  const parseRoleTargetAndDuration = (args) => {
    const raw = args.join(" ").trim();
    const commaIndex = raw.indexOf(",");

    if (commaIndex >= 0) {
      return {
        target: raw.slice(0, commaIndex).trim(),
        duration: raw.slice(commaIndex + 1).trim(),
      };
    }

    return {
      target: args[0]?.trim() || "",
      duration: args[1]?.trim() || "",
    };
  };
  const isTelegramUserId = (value) => /^\d+$/.test(String(value || "").trim());

  const {
    sendStartMenu,
    sendActionMenu,
    sendAllMenu,
    sendMyInfoMenu,
    sendSXTable,
    isUserJoinedChannel,
    joinChannelKeyboard,
    sendJoinRequiredMenu,
    botReply,
    botError,
    botSucces,
    botList,
    sendTextResult,
    streamBlocks,
  } = menu;

  // ====================================================================
  // Construction de la map de commandes depuis TRAVAS_REGISTRY
  // ====================================================================
  const buildTravasCommandMap = () => {
    const map = new Map();
    for (const entry of getTravasRegistry()) {
      const raw = String(entry.command || entry.key || "");
      const key = raw.replace(/^\//, "").toLowerCase();
      if (key) map.set(key, entry);
    }
    return map;
  };
  const travasCommandMap = buildTravasCommandMap();

  const countOnlineSessions = () => {
    let online = 0;
    let total = 0;
    for (const client of waClients.values()) {
      total++;
      if (client?.status === "open") online++;
    }
    return { online, total };
  };

  const roleLabel = (uid) => {
    if (checkOwner(uid)) return "👑 Propriétaire";
    if (checkAdmin(uid)) return "🛡️ Administrateur";
    if (isVVIP(uid, dbScope)) return "💎 VVIP";
    if (isPremium(uid, dbScope)) return "💠 Premium";
    return "🆓 Gratuit";
  };

  bot.on("message:text", async (ctx) => {
    const text = ctx.message.text.trim();
    const uid = String(ctx.from.id);
    const pendingTravas = pendingTravasTarget.get(uid);

    // ------------------------------------------------------------------
    // Cible travas en attente (l'utilisateur a choisi une action, il envoie la cible)
    // ------------------------------------------------------------------
    if (pendingTravas && !text.startsWith("/")) {
      pendingTravasTarget.delete(uid);

      const entry = getTravasEntry(pendingTravas.key);
      if (!entry) {
        return botError(ctx, "L'action travas sélectionnée n'est plus valide.");
      }

      let target = normalizeTravasTarget(entry.type, text);

      if (entry.type === "group" && !target.endsWith("@g.us")) {
        const sessionKey = resolveSessionKey(uid);
        const sessions = getPairsForUser(sessionKey);
        const active = sessions.find(
          (num) => getClient(sessionKey, num)?.status === "open",
        );

        if (!active) {
          return botError(
            ctx,
            "Aucun émetteur actif n'est disponible pour résoudre le groupe.",
            "⚠️ HORS LIGNE",
          );
        }

        const sock = getClient(sessionKey, active)?.sock;
        const resolved = await resolveGroupInviteTarget(sock, target);
        if (!resolved) {
          return botError(
            ctx,
            "Lien de groupe ou JID de groupe invalide. Envoie un lien d'invitation WhatsApp ou un ID de groupe @g.us valide.",
            "⚠️ CIBLE DE GROUPE INVALIDE",
          );
        }
        target = resolved;
      }

      if (!target) {
        return botError(ctx, `Cible ${entry.type} invalide. Réessaie.`);
      }

      await ctx.api
        .deleteMessage(ctx.chat.id, ctx.message.message_id - 1)
        .catch(() => {});

      const sessionKey = resolveSessionKey(uid);
      await actionSession(
        ctx,
        uid,
        sessionKey,
        target,
        (sock, finalTarget) => entry.run({ sock, target: finalTarget }),
        entry.key,
      );
      return;
    }

    // On ne traite que les commandes commençant par /
    if (!text.startsWith("/")) return;

    const [cmdRaw, ...args] = text.split(/\s+/);
    const command = cmdRaw.slice(1).toLowerCase();

    await registerUserIfNeeded(uid);

    // ------------------------------------------------------------------
    // Vérification de l'adhésion au channel obligatoire (sauf sous-bot & propriétaire)
    // ------------------------------------------------------------------
    if (!isSubBot && !checkOwner(uid)) {
      const joined = await isUserJoinedChannel(uid);
      if (!joined) {
        await sendJoinRequiredMenu(
          ctx,
          "Tu dois rejoindre le channel requis avant d'utiliser ce bot.",
        );
        return;
      }
    }

    // ------------------------------------------------------------------
    // MODE MAINTENANCE : bloque tout le monde sauf propriétaire/admin
    // ------------------------------------------------------------------
    if (
      !isSubBot &&
      isMaintenanceEnabled() &&
      !checkOwner(uid) &&
      !checkAdmin(uid)
    ) {
      const m = getMaintenance();
      return botError(
        ctx,
        m.message || "🛠️ Le bot est actuellement en maintenance. Réessaie plus tard.",
        "🛠️ MAINTENANCE",
      );
    }

    // ------------------------------------------------------------------
    // DISPATCHER DYNAMIQUE TRAVAS
    // ------------------------------------------------------------------
    const travasEntry = travasCommandMap.get(command);
    if (travasEntry) {
      if (!checkAccess(uid)) return botError(ctx, "Tu n'as pas accès à cette commande.");

      await travasRun(
        ctx,
        uid,
        args,
        command,
        travasEntry.type,
        (sock, target) => travasEntry.run({ sock, target }),
      );
      return;
    }

    // ------------------------------------------------------------------
    // COMMANDES SWITCH-CASE (non-travas)
    // ------------------------------------------------------------------
    switch (command) {
      // ==================================================================
      // MENU
      // ==================================================================
      case "start": {
        await sendStartMenu(ctx);
        break;
      }

      case "menu": {
        await sendAllMenu(ctx);
        break;
      }

      case "action": {
        await sendActionMenu(ctx);
        break;
      }

      case "myinfo": {
        await sendMyInfoMenu(ctx);
        break;
      }

      // ==================================================================
      // COMMANDES SYSTÈME / UTILITAIRES (nouvelles)
      // ==================================================================
      case "help": {
        await botReply(ctx, `📖 ${BRANDING.name} — AIDE`, [
          ["🚀 Démarrage", "/start • /menu • /action • /myinfo"],
          ["🆔 Divers", "/id • /ping • /help"],
          ["📊 Infos", "/stats • /health • /sessions"],
          ["👤 Profil", "/userinfo <id>"],
          ["💠 Premium", "/addprem • /delprem • /listprem • /extendprem"],
          ["💎 VVIP", "/addvvip • /delvvip • /listvvip • /resetvvipcooldown"],
          ["🛡️ Admin", "/addadmin • /deladmin • /listadmin"],
          ["👥 Utilisateurs", "/listusers • /deluser • /exportusers"],
          ["📱 Sessions", "/pair • /delpair • /listpair • /clearpair"],
          ["🤖 Sous-bots", "/addbot • /delbot • /listbot"],
          ["⚙️ Système", "/mode • /bc • /backup • /restore • /maintenance • /restart"],
          ["🎯 Actions", "Toutes les commandes d'action sont listées dans /action"],
        ]);
        break;
      }

      case "ping": {
        const t0 = Date.now();
        const sent = await botReply(ctx, "🏓 PING", [["Statut", "Calcul en cours..."]]);
        const latency = Date.now() - t0;
        await ctx.api
          .deleteMessage(ctx.chat.id, sent.message_id)
          .catch(() => {});
        await botReply(ctx, "🏓 PONG", [
          ["Latence Telegram", `${latency} ms`],
          ["Latence totale", `${Date.now() - t0} ms`],
          ["Statut", "🟢 En ligne"],
        ]);
        break;
      }

      case "id": {
        await botReply(ctx, "🆔 IDENTIFIANTS", [
          ["Ton ID Telegram", uid],
          ["ID du chat", String(ctx.chat.id)],
          ["Type de chat", ctx.chat.type],
          ["Nom", ctx.from.first_name || "-"],
          ["Username", ctx.from.username ? `@${ctx.from.username}` : "-"],
          ["Rôle", roleLabel(uid)],
        ]);
        break;
      }

      case "stats": {
        if (!checkAdmin(uid) && !checkAccess(uid))
          return botError(ctx, "Accès réservé aux administrateurs et au propriétaire.");
        const users = getUsers();
        const premiums = getPremiums(dbScope);
        const vvips = getVVIPs(dbScope);
        const admins = getAdmins(dbScope);
        const bots = isSubBot
          ? getBotsForUser(uid)
          : Object.values(getAllBotsRaw()).flat();
        const pairs = getAllPairs();
        const pairCount = Object.values(pairs).reduce(
          (acc, arr) => acc + (Array.isArray(arr) ? arr.length : 0),
          0,
        );
        const { online, total } = countOnlineSessions();
        await botReply(ctx, `📊 ${BRANDING.name} — STATISTIQUES`, [
          ["👥 Utilisateurs", users.length],
          ["💠 Premium", premiums.length],
          ["💎 VVIP", vvips.length],
          ["🛡️ Admins", admins.length],
          ["🤖 Sous-bots", bots.length],
          ["📱 Numéros appairés", pairCount],
          ["🟢 Sessions en ligne", `${online}/${total}`],
          ["⚙️ Mode", getMode(dbScope)],
          ["🛠️ Maintenance", isMaintenanceEnabled() ? "🟠 Activée" : "🟢 Désactivée"],
          ["⏱️ Uptime", formatDuration(Date.now() - START_TIME)],
        ]);
        break;
      }

      case "health": {
        if (!checkAdmin(uid) && !checkAccess(uid))
          return botError(ctx, "Accès réservé aux administrateurs et au propriétaire.");
        const mem = process.memoryUsage();
        const { online, total } = countOnlineSessions();
        const toMb = (b) => `${(b / 1024 / 1024).toFixed(1)} Mo`;
        await botReply(ctx, "🩺 ÉTAT DU SYSTÈME", [
          ["Statut", "🟢 Opérationnel"],
          ["Uptime bot", formatDuration(Date.now() - START_TIME)],
          ["Uptime serveur", formatDuration(os.uptime() * 1000)],
          ["Node.js", process.version],
          ["Plateforme", `${os.platform()} ${os.arch()}`],
          ["CPU", `${os.cpus().length} cœur(s)`],
          ["Charge (1m)", os.loadavg()[0].toFixed(2)],
          ["RAM utilisée", `${toMb(mem.rss)} (heap ${toMb(mem.heapUsed)})`],
          ["Sessions WA", `${online}/${total} en ligne`],
          ["PID", process.pid],
        ]);
        break;
      }

      case "sessions": {
        if (!checkOwner(uid) && !checkAdmin(uid))
          return botError(ctx, "Accès réservé au propriétaire et aux administrateurs.");
        const cells = [
          [
            { text: "Session", is_header: true, align: "center", valign: "middle" },
            { text: "Numéro", is_header: true, align: "center", valign: "middle" },
            { text: "Statut", is_header: true, align: "center", valign: "middle" },
          ],
        ];
        for (const [key, client] of waClients.entries()) {
          const idx = key.lastIndexOf("_");
          const ownerKey = idx >= 0 ? key.slice(0, idx) : key;
          const number = idx >= 0 ? key.slice(idx + 1) : "-";
          cells.push([
            { text: ownerKey, align: "left", valign: "middle" },
            { text: number, align: "left", valign: "middle" },
            {
              text: client?.status === "open" ? "🟢 En ligne" : "🔴 Hors ligne",
              align: "left",
              valign: "middle",
            },
          ]);
        }
        if (cells.length === 1) {
          return botError(ctx, "Aucune session WhatsApp active.", "⚠️ VIDE");
        }
        await sendSXTable(ctx, "📡 SESSIONS WHATSAPP ACTIVES", cells);
        break;
      }

      case "userinfo": {
        if (!checkOwner(uid) && !checkAdmin(uid))
          return botError(ctx, "Accès réservé au propriétaire et aux administrateurs.");
        const target = (args[0] || "").trim();
        if (!isTelegramUserId(target))
          return botError(ctx, "Utilisation : /userinfo <user_id>", "⚠️ FORMAT INVALIDE");
        const prem = getPremiumEntry(target, dbScope);
        const vvip = getVVIPEntry(target, dbScope);
        const pairs = getPairsForUser(target);
        const bots = getBotsForUser(target);
        await botReply(ctx, "👤 INFORMATIONS UTILISATEUR", [
          ["ID", target],
          ["Rôle", roleLabel(target)],
          ["Premium", prem ? (prem.expiresAt ? formatDuration(prem.expiresAt - Date.now()) : "Permanent") : "Non"],
          ["VVIP", vvip ? (vvip.expiresAt ? formatDuration(vvip.expiresAt - Date.now()) : "Permanent") : "Non"],
          ["Numéros appairés", pairs.length],
          ["Sous-bots déployés", bots.length],
        ]);
        break;
      }

      case "listusers": {
        if (!checkOwner(uid) && !checkAdmin(uid))
          return botError(ctx, "Accès réservé au propriétaire et aux administrateurs.");
        const users = getUsers();
        if (!users.length)
          return botError(ctx, "Aucun utilisateur enregistré.", "⚠️ VIDE");
        const items = users.map((u) => `${u} — ${roleLabel(u)}`);
        await botList(
          ctx,
          `👥 ${BRANDING.name} — UTILISATEURS (${users.length})`,
          items,
          "Aucun utilisateur enregistré.",
        );
        break;
      }

      case "deluser": {
        if (!checkOwner(uid)) return botError(ctx, "Réservé au propriétaire.");
        const target = (args[0] || "").trim();
        if (!isTelegramUserId(target))
          return botError(ctx, "Utilisation : /deluser <user_id>", "⚠️ FORMAT INVALIDE");
        const removed = removeUser(target);
        await botSucces(ctx, `L'utilisateur ${target} a été supprimé de la base.`);
        break;
      }

      case "exportusers": {
        if (!checkOwner(uid) && !checkAdmin(uid))
          return botError(ctx, "Accès réservé au propriétaire et aux administrateurs.");
        if (ctx.chat.type !== "private")
          return botError(ctx, "Lance /exportusers en privé pour protéger les données.");
        const users = getUsers();
        const payload = {
          exportType: "emmanuel-users-export",
          generatedAt: new Date().toISOString(),
          totalUsers: users.length,
          users,
        };
        const filename = `utilisateurs-${new Date().toISOString().replace(/[:.]/g, "-")}.json`;
        await ctx.api.sendDocument(
          ctx.chat.id,
          new InputFile(Buffer.from(JSON.stringify(payload, null, 2)), filename),
          { caption: `👥 Export de ${users.length} utilisateur(s).` },
        );
        break;
      }

      // ==================================================================
      // PREMIUM
      // ==================================================================
      case "addprem": {
        if (!checkAdmin(uid))
          return botError(ctx, "Réservé aux administrateurs et au propriétaire.");

        const { target, duration: durasiRaw } =
          parseRoleTargetAndDuration(args);

        if (!isTelegramUserId(target)) {
          return botError(
            ctx,
            "Utilisation : /addprem <user_id>[,<durée>]\nExemple : /addprem 12345,1d ou /addprem 12345 1d\nUtilise un ID Telegram numérique. Unités : m(minutes), h(heures), d(jours), w(semaines), mo(mois), y(années). Utilise 0 ou laisse vide pour un accès permanent.",
            "⚠️ FORMAT INVALIDE",
          );
        }

        let durationMs = null;
        if (durasiRaw) {
          const parsed = parseDuration(durasiRaw);
          if (parsed === undefined) {
            return botError(
              ctx,
              "Durée invalide. Utilise 1d, 12h, 30m, 2w, 1mo, 1y, ou 0 pour un accès permanent.",
              "⚠️ FORMAT INVALIDE",
            );
          }
          durationMs = parsed;
        }

        const entry = addPremium(target, durationMs, dbScope);
        await botSucces(
          ctx,
          `${target} a été ajouté comme utilisateur premium${isSubBot ? " (ce bot uniquement)" : ""}.\nDurée : ${entry.expiresAt ? formatDuration(entry.expiresAt - Date.now()) : "Permanent"}`,
        );
        break;
      }

      case "extendprem": {
        if (!checkAdmin(uid))
          return botError(ctx, "Réservé aux administrateurs et au propriétaire.");
        const { target, duration: durasiRaw } = parseRoleTargetAndDuration(args);
        if (!isTelegramUserId(target) || !durasiRaw) {
          return botError(
            ctx,
            "Utilisation : /extendprem <user_id> <durée>\nExemple : /extendprem 12345 7d",
            "⚠️ FORMAT INVALIDE",
          );
        }
        const parsed = parseDuration(durasiRaw);
        if (parsed === undefined || parsed === null) {
          return botError(
            ctx,
            "Durée invalide. Utilise 1d, 12h, 30m, 2w, 1mo, 1y.",
            "⚠️ FORMAT INVALIDE",
          );
        }
        const existing = getPremiumEntry(target, dbScope);
        const base = existing?.expiresAt ? Math.max(existing.expiresAt, Date.now()) : Date.now();
        const newExpiry = base + parsed;
        const entry = addPremium(target, newExpiry - Date.now(), dbScope);
        await botSucces(
          ctx,
          `Le premium de ${target} a été prolongé.\nNouvelle expiration : ${entry.expiresAt ? formatDuration(entry.expiresAt - Date.now()) : "Permanent"}`,
        );
        break;
      }

      case "delprem": {
        if (!checkAdmin(uid))
          return botError(ctx, "Réservé aux administrateurs et au propriétaire.");
        const target = args[0]?.trim();
        if (!isTelegramUserId(target))
          return botError(ctx, "Utilisation : /delprem <user_id>", "⚠️ FORMAT INVALIDE");
        removePremium(target, dbScope);
        await botSucces(ctx, `${target} a été retiré du premium.`);
        break;
      }

      case "listprem": {
        if (!checkAdmin(uid))
          return botError(ctx, "Réservé aux administrateurs et au propriétaire.");
        const premiums = getPremiums(dbScope);
        const items = premiums.map((e) => {
          const sisa = e.expiresAt
            ? formatDuration(e.expiresAt - Date.now())
            : "Permanent";
          return `${e.id} — ${sisa}`;
        });
        await botList(
          ctx,
          `💠 ${BRANDING.name} — LISTE PREMIUM`,
          items,
          "Aucun utilisateur premium pour le moment.",
        );
        break;
      }

      // ==================================================================
      // VVIP
      // ==================================================================
      case "addvvip": {
        if (!checkAdmin(uid))
          return botError(ctx, "Réservé aux administrateurs et au propriétaire.");

        const { target, duration: durasiRaw } =
          parseRoleTargetAndDuration(args);

        if (!isTelegramUserId(target)) {
          return botError(
            ctx,
            "Utilisation : /addvvip <user_id>[,<durée>]\nExemple : /addvvip 12345,1d ou /addvvip 12345 1d\nUtilise un ID Telegram numérique. Utilise 0 ou laisse vide pour un accès permanent.",
            "⚠️ FORMAT INVALIDE",
          );
        }

        let durationMs = null;
        if (durasiRaw) {
          const parsed = parseDuration(durasiRaw);
          if (parsed === undefined) {
            return botError(
              ctx,
              "Durée invalide. Utilise 1d, 12h, 30m, 2w, 1mo, 1y, ou 0 pour un accès permanent.",
              "⚠️ FORMAT INVALIDE",
            );
          }
          durationMs = parsed;
        }

        const entry = addVVIP(target, durationMs, dbScope);
        await botSucces(
          ctx,
          `${target} a été ajouté comme utilisateur VVIP${isSubBot ? " (ce bot uniquement)" : ""}.\nDurée : ${entry.expiresAt ? formatDuration(entry.expiresAt - Date.now()) : "Permanent"}`,
        );
        break;
      }

      case "delvvip": {
        if (!checkAdmin(uid))
          return botError(ctx, "Réservé aux administrateurs et au propriétaire.");
        const target = args[0]?.trim();
        if (!isTelegramUserId(target))
          return botError(ctx, "Utilisation : /delvvip <user_id>", "⚠️ FORMAT INVALIDE");
        removeVVIP(target, dbScope);
        await botSucces(ctx, `${target} a été retiré du VVIP.`);
        break;
      }

      case "listvvip": {
        if (!checkAdmin(uid))
          return botError(ctx, "Réservé aux administrateurs et au propriétaire.");
        const vvipUsers = getVVIPs(dbScope);
        const items = vvipUsers.map((e) => {
          const sisa = e.expiresAt
            ? formatDuration(e.expiresAt - Date.now())
            : "Permanent";
          return `${e.id} — ${sisa}`;
        });
        await botList(
          ctx,
          `💎 ${BRANDING.name} — LISTE VVIP`,
          items,
          "Aucun utilisateur VVIP pour le moment.",
        );
        break;
      }

      case "resetvvipcooldown": {
        if (!checkOwner(uid)) return botError(ctx, "Réservé au propriétaire.");
        const targetId = (args[0] || "").trim() || String(uid);
        resetVVIPSenderUse(targetId);
        await botSucces(
          ctx,
          `Le cooldown de l'émetteur VVIP a été réinitialisé pour ${targetId}.`,
          "✅ COOLDOWN RÉINITIALISÉ",
        );
        break;
      }

      // ==================================================================
      // ADMIN
      // ==================================================================
      case "addadmin": {
        if (!checkOwner(uid)) return botError(ctx, "Réservé au propriétaire.");
        const target = args[0]?.trim();
        if (!isTelegramUserId(target))
          return botError(ctx, "Utilisation : /addadmin <user_id>", "⚠️ FORMAT INVALIDE");
        addAdmin(target, dbScope);
        await botSucces(
          ctx,
          `${target} a été ajouté comme administrateur${isSubBot ? " (ce bot uniquement)" : ""}.`,
        );
        break;
      }

      case "deladmin": {
        if (!checkOwner(uid)) return botError(ctx, "Réservé au propriétaire.");
        const target = args[0]?.trim();
        if (!isTelegramUserId(target))
          return botError(ctx, "Utilisation : /deladmin <user_id>", "⚠️ FORMAT INVALIDE");
        removeAdmin(target, dbScope);
        await botSucces(ctx, `${target} a été retiré des administrateurs.`);
        break;
      }

      case "listadmin": {
        if (!checkOwner(uid)) return botError(ctx, "Réservé au propriétaire.");
        await botList(
          ctx,
          `🛡️ ${BRANDING.name} — LISTE ADMIN`,
          getAdmins(dbScope),
          "Aucun administrateur pour le moment.",
        );
        break;
      }

      // ==================================================================
      // MODE
      // ==================================================================
      case "mode": {
        if (!checkOwner(uid)) return botError(ctx, "Réservé au propriétaire.");
        const target = (args[0] || "").toLowerCase();
        if (!["privat", "private", "public"].includes(target)) {
          return botError(ctx, "Utilisation : /mode <private/public>", "⚠️ FORMAT INVALIDE");
        }
        const mode =
          target.startsWith("privat") || target === "private"
            ? "private"
            : "public";
        setMode(mode, dbScope);
        await botSucces(
          ctx,
          `Le mode du bot${isSubBot ? "" : ""} a été changé en ${mode}.`,
        );
        break;
      }

      // ==================================================================
      // MAINTENANCE
      // ==================================================================
      case "maintenance": {
        if (!checkOwner(uid)) return botError(ctx, "Réservé au propriétaire.");
        const action = (args[0] || "").toLowerCase();
        if (!["on", "off", "status"].includes(action)) {
          return botError(
            ctx,
            "Utilisation : /maintenance <on|off|status> [message]\nExemple : /maintenance on Maintenance en cours, revenez plus tard.",
            "⚠️ FORMAT INVALIDE",
          );
        }
        if (action === "status") {
          const m = getMaintenance();
          return botReply(ctx, "🛠️ STATUT MAINTENANCE", [
            ["État", m.enabled ? "🟠 Activée" : "🟢 Désactivée"],
            ["Message", m.message || "-"],
            ["Mise à jour", m.updatedAt || "-"],
          ]);
        }
        const enabled = action === "on";
        const message = args.slice(1).join(" ").trim();
        setMaintenance(enabled, message);
        await botSucces(
          ctx,
          enabled
            ? `🛠️ Maintenance activée.${message ? `\nMessage : ${message}` : ""}`
            : "🟢 Maintenance désactivée. Le bot est de nouveau accessible.",
          enabled ? "🛠️ MAINTENANCE ON" : "✅ MAINTENANCE OFF",
        );
        break;
      }

      // ==================================================================
      // RESTART
      // ==================================================================
      case "restart": {
        if (!checkOwner(uid)) return botError(ctx, "Réservé au propriétaire.");
        await botSucces(
          ctx,
          "♻️ Redémarrage du bot en cours... Le processus va se relancer automatiquement.",
          "♻️ RESTART",
        );
        setTimeout(async () => {
          try {
            const { spawn } = await import("child_process");
            const child = spawn(process.execPath, process.argv.slice(1), {
              detached: true,
              stdio: "inherit",
              cwd: process.cwd(),
              env: process.env,
            });
            child.unref();
          } catch (e) {
            log.error(`Échec du redémarrage (spawn) : ${e.message}`);
          }
          process.exit(0);
        }, 1200);
        break;
      }

      // ==================================================================
      // BROADCAST
      // ==================================================================
      case "bc": {
        if (isSubBot)
          return botError(
            ctx,
            "Cette fonctionnalité n'est disponible que sur le bot principal.",
            "⚠️ NON DISPONIBLE",
          );
        if (!checkAdmin(uid))
          return botError(ctx, "Réservé aux administrateurs et au propriétaire.");

        const users = getUsers();
        if (!users.length)
          return botError(ctx, "Aucun utilisateur enregistré pour le moment.", "⚠️ VIDE");

        const replied = ctx.message.reply_to_message;
        const textArg = args.join(" ");

        if (!replied && !textArg) {
          return botError(
            ctx,
            "/bc <texte>, ou réponds à un message/média puis envoie /bc",
            "⚠️ FORMAT INVALIDE",
          );
        }

        const wait = await botReply(ctx, "📤 DIFFUSION EN COURS", [
          ["Progression", `Envoi à ${users.length} utilisateurs...`],
        ]);

        let success = 0;
        let failed = 0;
        let cleaned = 0;

        for (const targetId of users) {
          try {
            if (replied) {
              await ctx.api.copyMessage(
                targetId,
                ctx.chat.id,
                replied.message_id,
              );
            } else {
              await ctx.api.sendMessage(targetId, textArg);
            }
            success++;
          } catch (err) {
            failed++;
            const code = err?.error_code;
            const desc = String(err?.description || err?.message || "");
            if (
              code === 403 ||
              /blocked|chat not found|deactivated|kicked/i.test(desc)
            ) {
              removeUser(targetId);
              cleaned++;
            }
          }
          await new Promise((r) => setTimeout(r, 100));
        }

        await ctx.api
          .deleteMessage(ctx.chat.id, wait.message_id)
          .catch(() => {});
        await botReply(ctx, "✅ DIFFUSION TERMINÉE", [
          ["Total utilisateurs", users.length],
          ["Réussis", `🟢 ${success}`],
          ["Échoués", `🔴 ${failed}`],
          ["Utilisateurs supprimés", cleaned],
        ]);
        break;
      }

      // ==================================================================
      // DÉPLOIEMENT DE BOT
      // ==================================================================
      case "addbot": {
        if (isSubBot)
          return botError(
            ctx,
            "Cette fonctionnalité n'est disponible que sur le bot principal.",
            "⚠️ NON DISPONIBLE",
          );
        const isOwnerUser = checkOwner(uid);
        const isAdminUser = checkAdmin(uid);
        const isVVIPUser = isVVIP(uid, dbScope);
        const isPremiumUser = isPremium(uid, dbScope);
        const canDeployBot =
          isOwnerUser || isAdminUser || isVVIPUser || isPremiumUser;

        if (!canDeployBot) {
          return botError(
            ctx,
            "Les utilisateurs gratuits ne peuvent utiliser que le bot principal. Le déploiement de bot nécessite un accès Premium, VVIP, Admin ou Propriétaire.",
            "⚠️ ACCÈS DÉPLOIEMENT REQUIS",
          );
        }

        const botLimit =
          isOwnerUser || isAdminUser
            ? Infinity
            : isVVIPUser
              ? 10
              : isPremiumUser
                ? 3
                : 1;
        const currentBotCount = getBotsForUser(uid).length;

        if (Number.isFinite(botLimit) && currentBotCount >= botLimit) {
          return botError(
            ctx,
            isPremiumUser
              ? "Les utilisateurs Premium peuvent déployer au maximum 3 bots."
              : isVVIPUser
                ? "Les utilisateurs VVIP peuvent déployer au maximum 10 bots."
                : "Les utilisateurs gratuits peuvent déployer au maximum 1 bot.",
            "⚠️ LIMITE DE BOTS ATTEINTE",
          );
        }

        const raw = args.join(" ");
        const [token, ownerId] = raw.split(",").map((s) => s?.trim());

        if (!token || !ownerId) {
          return botError(
            ctx,
            "Utilisation : /addbot <token>,<owner_id>",
            "⚠️ FORMAT INVALIDE",
          );
        }

        const { startDeployedBot, describeDeployError } =
          await import("../deploy.js");

        const added = addBotEntry(uid, token, ownerId);
        if (!added)
          return botError(
            ctx,
            "Ce token est déjà enregistré par un autre déployeur.",
          );

        const wait = await botReply(ctx, "⏳ DÉPLOIEMENT", [
          ["Statut", "Activation du nouveau bot..."],
        ]);

        try {
          await startDeployedBot(token, ownerId, uid);
          await ctx.api
            .deleteMessage(ctx.chat.id, wait.message_id)
            .catch(() => {});
          await botSucces(
            ctx,
            `Bot déployé avec succès avec l'ID propriétaire ${ownerId}.\nCe bot possède des paramètres admin, premium et mode totalement séparés.`,
            "✅ BOT DÉPLOYÉ",
          );
        } catch (err) {
          removeBotEntry(uid, token);
          const notifyOwnerId = String(ownerId || uid || OWNER_ID || "");
          const deployError = describeDeployError(err);

          if (notifyOwnerId) {
            try {
              await bot.api.sendMessage(
                notifyOwnerId,
                `⚠️ Le déploiement du bot a échoué et a été supprimé automatiquement.\nSuffixe du token : ...${token.slice(-6)}\nID propriétaire : ${ownerId}\nDéployeur : ${uid}\nErreur : ${deployError}`,
              );
            } catch {}
          }

          await ctx.api
            .deleteMessage(ctx.chat.id, wait.message_id)
            .catch(() => {});
          await botError(ctx, deployError, "❌ ÉCHEC DU DÉPLOIEMENT");
        }
        break;
      }

      case "delbot": {
        if (isSubBot)
          return botError(
            ctx,
            "Cette fonctionnalité n'est disponible que sur le bot principal.",
            "⚠️ NON DISPONIBLE",
          );

        const rawToken = args[0];
        if (!rawToken)
          return botError(ctx, "Utilisation : /delbot <token>", "⚠️ FORMAT INVALIDE");

        const isOwnerUser = checkOwner(uid);
        const allBots = isOwnerUser
          ? Object.entries(getAllBotsRaw()).flatMap(([deployerUid, bots]) =>
              bots.map((bot) => ({ ...bot, deployerUid })),
            )
          : getBotsForUser(uid).map((bot) => ({ ...bot, deployerUid: uid }));

        const match = allBots.find(
          (bot) => bot.token === rawToken || bot.token.startsWith(rawToken),
        );

        if (!match) {
          return botError(
            ctx,
            isOwnerUser
              ? "Ce token de bot est introuvable."
              : "Ce token ne t'appartient pas ou est introuvable.",
          );
        }

        const { stopDeployedBot } = await import("../deploy.js");
        await stopDeployedBot(match.token);
        removeBotEntry(match.deployerUid, match.token);

        await botSucces(ctx, "Le bot a été arrêté et supprimé avec succès.");
        break;
      }

      case "listbot": {
        if (isSubBot)
          return botError(
            ctx,
            "Cette fonctionnalité n'est disponible que sur le bot principal.",
            "⚠️ NON DISPONIBLE",
          );

        const isOwnerUser = checkOwner(uid);
        const myBots = isOwnerUser
          ? Object.entries(getAllBotsRaw()).flatMap(([deployerUid, bots]) =>
              bots.map((bot) => ({ ...bot, deployerUid })),
            )
          : getBotsForUser(uid);
        if (!myBots.length)
          return botError(
            ctx,
            "Tu n'as déployé aucun bot pour le moment.",
            "⚠️ VIDE",
          );

        const { deployedBots } = await import("../deploy.js");

        const cells = [
          [
            { text: "Token", is_header: true, align: "center", valign: "middle" },
            {
              text: "ID Propriétaire",
              is_header: true,
              align: "center",
              valign: "middle",
            },
            ...(isOwnerUser
              ? [
                  {
                    text: "Déployé Par",
                    is_header: true,
                    align: "center",
                    valign: "middle",
                  },
                ]
              : []),
            {
              text: "Statut",
              is_header: true,
              align: "center",
              valign: "middle",
            },
          ],
        ];

        myBots.forEach((b) => {
          const masked = `${b.token.slice(0, 8)}...${b.token.slice(-4)}`;
          const status = deployedBots.has(b.token)
            ? "🟢 En ligne"
            : "🔴 Hors ligne";
          cells.push([
            { text: masked, align: "left", valign: "middle" },
            { text: b.ownerId, align: "left", valign: "middle" },
            ...(isOwnerUser
              ? [{ text: b.deployerUid, align: "left", valign: "middle" }]
              : []),
            { text: status, align: "left", valign: "middle" },
          ]);
        });

        await sendSXTable(ctx, `🤖 ${BRANDING.name} — MES BOTS DÉPLOYÉS`, cells);
        break;
      }

      // ==================================================================
      // SAUVEGARDE / RESTAURATION DB
      // ==================================================================
      case "backup": {
        if (isSubBot || !checkOwner(uid)) {
          return botError(
            ctx,
            "La sauvegarde de la base est réservée au propriétaire du bot principal.",
            "⚠️ NON DISPONIBLE",
          );
        }
        if (ctx.chat.type !== "private") {
          return botError(
            ctx,
            "Lance /backup en chat privé pour que le contenu de la base ne soit pas exposé.",
          );
        }

        try {
          const backup = createDatabaseBackup();
          const filename = `database-backup-${new Date().toISOString().replace(/[:.]/g, "-")}.json`;
          await ctx.api.sendDocument(
            ctx.chat.id,
            new InputFile(
              Buffer.from(JSON.stringify(backup, null, 2)),
              filename,
            ),
            {
              caption: `Sauvegarde de la base : ${Object.keys(backup.files).length} fichiers JSON.`,
            },
          );
        } catch (error) {
          log.error(`Échec de la sauvegarde de la base : ${error.message}`);
          return botError(
            ctx,
            "Impossible de créer la sauvegarde. Vérifie les logs du serveur.",
            "❌ ÉCHEC DE LA SAUVEGARDE",
          );
        }
        break;
      }

      case "restore": {
        if (isSubBot || !checkOwner(uid)) {
          return botError(
            ctx,
            "La restauration de la base est réservée au propriétaire du bot principal.",
            "⚠️ NON DISPONIBLE",
          );
        }
        if (ctx.chat.type !== "private") {
          return botError(
            ctx,
            "Lance /restore en chat privé pour garder les fichiers de base privés.",
          );
        }

        pendingDatabaseRestore.set(uid, Date.now());
        await botReply(ctx, "📦 RESTAURATION DE LA BASE", [
          [
            "Étape suivante",
            "Envoie le fichier JSON de sauvegarde dans ce chat privé.",
          ],
          ["Validité", "La demande d'envoi expire après 10 minutes."],
          [
            "Sécurité",
            "Un instantané de la base actuelle est sauvegardé avant la restauration.",
          ],
        ]);
        break;
      }

      // ==================================================================
      // APPAIRAGE
      // ==================================================================
      case "pair": {
        if (!checkAccess(uid)) return botError(ctx, "Tu n'as pas accès.");

        const sessionKey = getSessionKey(uid);
        const notifyTarget = isSubBot ? subBotOwnerId : uid;

        const number = sanitizePhoneDigits(args);
        if (!number)
          return botError(ctx, "Utilisation : /pair <628xxxxxxxx>", "⚠️ FORMAT INVALIDE");

        const current = getPairsForUser(sessionKey);
        if (current.includes(number))
          return botError(ctx, "Ce numéro est déjà appairé.");
        if (current.length >= MAX_PAIR_PER_USER)
          return botError(
            ctx,
            `Maximum ${MAX_PAIR_PER_USER} numéros autorisés.`,
          );

        if (pairingLocks.has(sessionKey)) {
          return botError(
            ctx,
            "Un autre processus d'appairage est déjà en cours pour cette session. Attends qu'il se termine ou expire.",
            "⏳ EN COURS",
          );
        }
        pairingLocks.add(sessionKey);

        const deleteMsg = async (msg) => {
          if (!msg?.message_id) return;
          await ctx.api
            .deleteMessage(ctx.chat.id, msg.message_id)
            .catch(() => {});
        };

        let statusMsg = await botReply(ctx, "⏳ TRAITEMENT", [
          ["Statut", "Génération du code d'appairage..."],
        ]);

        (async () => {
          try {
            const sock = await initWhatsappForNumber(
              bot,
              sessionKey,
              number,
              0,
              notifyTarget,
              { forceNew: true },
            );

            await new Promise((r) => setTimeout(r, 3000));
            const code = await sock.requestPairingCode(number);

            await deleteMsg(statusMsg);

            const blocks = [
              { type: "heading", text: "🔐 APPAIRAGE WHATSAPP", size: 1 },
              {
                type: "table",
                cells: [
                  [
                    {
                      text: "Ce code d'appairage est valable 90 secondes. Colle-le dans WhatsApp > Appareils connectés.",
                      is_header: false,
                      align: "center",
                      valign: "middle",
                    },
                  ],
                ],
                is_bordered: true,
                is_striped: true,
              },
              { type: "divider" },
              {
                type: "paragraph",
                text: [{ type: "bold", text: "Numéro WhatsApp : " }, number],
              },
              {
                type: "paragraph",
                text: [{ type: "bold", text: "Code d'appairage : " }, code],
              },
              { type: "divider" },
              {
                type: "buttons",
                buttons: [
                  {
                    text: "Copier le code d'appairage",
                    style: "success",
                    copy_text: { text: String(code) },
                  },
                ],
              },
            ];

            try {
              statusMsg = await streamBlocks(ctx, blocks);
            } catch (uiErr) {
              log.error(uiErr);
              statusMsg = await botReply(ctx, "🔐 APPAIRAGE WHATSAPP", [
                ["Numéro", number],
                ["Code d'appairage", code],
                [
                  "Info",
                  "Colle ce code dans WhatsApp > Appareils connectés.",
                ],
              ]);
            }

            const connected = await waitUntilOpen(sessionKey, number, 90000);

            if (!connected) {
              throw new Error("Délai d'attente de connexion WhatsApp dépassé.");
            }

            addPairNumber(sessionKey, number);

            await deleteMsg(statusMsg);
            await botSucces(
              ctx,
              `Le numéro ${number} s'est connecté avec succès.`,
              "✅ APPAIRAGE RÉUSSI",
            );
          } catch (err) {
            log.error(err);
            await endWhatsappForNumber(sessionKey, number).catch(() => {});
            await deleteMsg(statusMsg);
            await botError(
              ctx,
              describeWhatsappError(err),
              "❌ ÉCHEC DE L'APPAIRAGE",
            );
          } finally {
            pairingLocks.delete(sessionKey);
          }
        })().catch((err) => {
          log.error(err);
          pairingLocks.delete(sessionKey);
        });

        break;
      }

      case "delpair": {
        if (!checkAccess(uid)) return botError(ctx, "Tu n'as pas accès.");

        const sessionKey = getSessionKey(uid);
        const number = sanitizePhoneDigits(args);
        if (!number)
          return botError(ctx, "Utilisation : /delpair <numéro>", "⚠️ FORMAT INVALIDE");

        const current = getPairsForUser(sessionKey);
        if (!current.includes(number)) {
          return botError(
            ctx,
            isSubBot
              ? "Ce numéro n'est pas appairé avec ce bot."
              : "Ce numéro n'est pas appairé avec ton compte.",
          );
        }

        await endWhatsappForNumber(sessionKey, number);
        removePairNumber(sessionKey, number);
        await botSucces(ctx, `La session WhatsApp ${number} a été supprimée.`);
        break;
      }

      case "listpair": {
        if (!checkAccess(uid)) return botError(ctx, "Tu n'as pas accès.");

        if (isSubBot) {
          const sessionKey = getSessionKey(uid);
          const numbers = getPairsForUser(sessionKey);
          if (!numbers.length)
            return botError(
              ctx,
              "Aucun numéro n'est encore appairé avec ce bot.",
              "⚠️ VIDE",
            );

          const cells = [
            [
              {
                text: "Numéro",
                is_header: true,
                align: "center",
                valign: "middle",
              },
              {
                text: "Statut",
                is_header: true,
                align: "center",
                valign: "middle",
              },
            ],
          ];

          for (const number of numbers) {
            const client = getClient(sessionKey, number);
            cells.push([
              { text: number, align: "left", valign: "middle" },
              {
                text: client?.status === "open" ? "🟢 En ligne" : "🔴 Hors ligne",
                align: "left",
                valign: "middle",
              },
            ]);
          }

          await sendSXTable(
            ctx,
            "📱 SESSION PARTAGÉE — TOUS LES UTILISATEURS DE CE BOT",
            cells,
          );
          break;
        }

        const cells = [
          [
            {
              text: "ID Utilisateur",
              is_header: true,
              align: "center",
              valign: "middle",
            },
            {
              text: "Numéro",
              is_header: true,
              align: "center",
              valign: "middle",
            },
            {
              text: "Statut",
              is_header: true,
              align: "center",
              valign: "middle",
            },
          ],
        ];

        if (checkOwner(uid)) {
          for (const [userId, numbers] of Object.entries(getAllPairs())) {
            for (const number of numbers) {
              const client = getClient(userId, number);
              cells.push([
                { text: userId, align: "left", valign: "middle" },
                { text: number, align: "left", valign: "middle" },
                {
                  text:
                    client?.status === "open" ? "🟢 En ligne" : "🔴 Hors ligne",
                  align: "left",
                  valign: "middle",
                },
              ]);
            }
          }
        } else {
          const numbers = getPairsForUser(uid);
          if (!numbers.length)
            return botError(ctx, "Aucun numéro n'est encore appairé.", "⚠️ VIDE");

          for (const number of numbers) {
            const client = getClient(uid, number);
            cells.push([
              { text: uid, align: "left", valign: "middle" },
              { text: number, align: "left", valign: "middle" },
              {
                text: client?.status === "open" ? "🟢 En ligne" : "🔴 Hors ligne",
                align: "left",
                valign: "middle",
              },
            ]);
          }
        }

        await sendSXTable(ctx, `📱 ${BRANDING.name} — LISTE DES APPAIRAGES`, cells);
        break;
      }

      case "clearpair": {
        if (isSubBot)
          return botError(
            ctx,
            "Cette fonctionnalité n'est disponible que sur le bot principal.",
            "⚠️ NON DISPONIBLE",
          );
        if (!checkOwner(uid)) return botError(ctx, "Réservé au propriétaire.");
        await clearAllSessions();
        clearAllPairs();
        await botSucces(
          ctx,
          "Toutes les sessions WhatsApp de tous les utilisateurs ont été supprimées.",
        );
        break;
      }

      // ==================================================================
      // PROPRIÉTAIRE : AGIR EN TANT QU'ÉMETTEUR
      // ==================================================================
      case "assender": {
        if (isSubBot)
          return botError(
            ctx,
            "Cette fonctionnalité n'est disponible que sur le bot principal (les sessions des sous-bots sont partagées).",
            "⚠️ NON DISPONIBLE",
          );
        if (!checkOwner(uid)) return botError(ctx, "Réservé au propriétaire.");

        const arg = (args[0] || "").trim();

        if (!arg) {
          const current = ownerActingAs.get(String(uid));
          if (!current)
            return botError(
              ctx,
              "Tu utilises ton propre émetteur. Utilisation : /assender <user_id|sub_bot_session|sub_bot_token> ou /assender off",
              "ℹ️ STATUT",
            );
          return botSucces(
            ctx,
            `Tu utilises ${describeAssenderTarget(current)}.\nUtilise /assender off pour revenir à ton propre émetteur.`,
            "ℹ️ AGIR EN TANT QUE",
          );
        }

        const target = normalizeAssenderTarget(arg);

        if (target.action === "off") {
          if (!ownerActingAs.has(String(uid)))
            return botError(ctx, "Tu utilises déjà ton propre émetteur.");
          ownerActingAs.delete(String(uid));
          return botSucces(
            ctx,
            "Retour à ton propre émetteur.",
            "✅ RÉINITIALISÉ",
          );
        }

        if (target.action === "invalid") {
          return botError(
            ctx,
            "Utilisation : /assender <user_id|sub_bot_session|sub_bot_token> ou /assender off",
            "⚠️ FORMAT INVALIDE",
          );
        }

        const targetKey = target.targetKey;

        if (targetKey === String(uid)) {
          return botError(
            ctx,
            "C'est ton propre ID utilisateur ; aucun changement nécessaire.",
          );
        }

        const targetSenders = getPairsForUser(targetKey);
        if (!targetSenders.length) {
          return botError(
            ctx,
            `La cible \`${targetKey}\` n'a aucun émetteur appairé.`,
            "⚠️ VIDE",
          );
        }

        ownerActingAs.set(String(uid), targetKey);

        await botSucces(
          ctx,
          `Tu utilises maintenant ${describeAssenderTarget(targetKey)} (${targetSenders.length} numéro(s)) pour toutes les actions.\nUtilise /assender off pour revenir à ton propre émetteur.`,
          "✅ AGIR EN TANT QU'ACTIF",
        );
        break;
      }

      // ==================================================================
      // VVIP : AGIR EN TANT QU'ÉMETTEUR
      // ==================================================================
      case "xvvip":
      case "vvipassender": {
        if (isSubBot)
          return botError(
            ctx,
            "Cette fonctionnalité n'est disponible que sur le bot principal (les sessions des sous-bots sont partagées).",
            "⚠️ NON DISPONIBLE",
          );

        const isPrivilegedVVIPUser =
          checkOwner(uid) || checkAdmin(uid) || isVVIP(uid, dbScope);

        if (getMode(dbScope) === "public" && !isPrivilegedVVIPUser) {
          return botError(
            ctx,
            "Cette fonctionnalité d'émetteur VVIP est désactivée en mode public/gratuit pour les utilisateurs gratuits.",
            "⚠️ NON DISPONIBLE",
          );
        }

        if (!isPrivilegedVVIPUser)
          return botError(ctx, "Un accès VVIP est requis pour cette fonctionnalité.");

        const arg = (args[0] || "").trim();

        if (arg) {
          const target = normalizeAssenderTarget(arg);

          if (target.action === "off") {
            if (!ownerActingAs.has(String(uid)))
              return botError(ctx, "Tu utilises déjà ton propre émetteur.");
            ownerActingAs.delete(String(uid));
            return botSucces(
              ctx,
              "Retour à ton propre émetteur.",
              "✅ RÉINITIALISÉ",
            );
          }

          if (target.action === "invalid") {
            return botError(
              ctx,
              "Utilisation : /xvvip ou /vvipassender off",
              "⚠️ FORMAT INVALIDE",
            );
          }

          const targetKey = target.targetKey;
          const currentTarget = getActingTarget(uid);

          if (targetKey === currentTarget) {
            return botError(
              ctx,
              isUsingExternalSender(uid)
                ? `Tu utilises déjà un émetteur VVIP de ${describeAssenderTarget(targetKey)}.`
                : "Tu utilises déjà ta propre session d'émetteur.",
              "⚠️ SESSION DÉJÀ ACTIVE",
            );
          }

          const targetSenders = getPairsForUser(targetKey);
          if (!targetSenders.length) {
            return botError(
              ctx,
              `La cible \`${targetKey}\` n'a aucun émetteur appairé.`,
              "⚠️ VIDE",
            );
          }

          if (!checkOwner(uid)) {
            const usage = consumeVVIPSenderUse(uid);
            if (!usage.allowed) {
              const waitSeconds = Math.ceil(usage.waitMs / 1000);
              const minutes = Math.ceil(waitSeconds / 60);
              return botError(
                ctx,
                `Limite d'émetteur VVIP atteinte. Attends ${minutes} minute(s) avant de réessayer.`,
                "⏳ COOLDOWN",
              );
            }
          }

          ownerActingAs.set(String(uid), targetKey);
          await botSucces(
            ctx,
            `Accès VVIP activé : tu utilises maintenant ${describeAssenderTarget(targetKey)} (${targetSenders.length} numéro(s)) pour toutes les actions.\nUtilise /xvvip off ou /vvipassender off pour revenir à ton propre émetteur.`,
            "✅ VVIP AGIR EN TANT QU'ACTIF",
          );
          break;
        }

        if (isUsingExternalSender(uid)) {
          const activeTarget = getActingTarget(uid);
          return botError(
            ctx,
            `Tu utilises déjà un émetteur VVIP de ${describeAssenderTarget(activeTarget)}. Utilise /xvvip off avant de sélectionner un autre émetteur.`,
            "⚠️ SESSION DÉJÀ ACTIVE",
          );
        }

        await sendVVIPSelectorMenu(ctx, {
          checkOwner,
          checkAdmin,
          dbScope,
          botError,
        });
        break;
      }

      // ==================================================================
      // DÉFAUT
      // ==================================================================
      default: {
        return;
      }
    }
  });

  // ====================================================================
  // HANDLER : Upload du fichier de sauvegarde pour /restore
  // ====================================================================
  bot.on("message:document", async (ctx) => {
    const uid = String(ctx.from.id);
    const requestTime = pendingDatabaseRestore.get(uid);
    if (!requestTime) return;

    if (isSubBot || !checkOwner(uid) || ctx.chat.type !== "private") {
      pendingDatabaseRestore.delete(uid);
      return botError(
        ctx,
        "La restauration de la base est disponible dans le chat privé du bot principal, réservée au propriétaire.",
        "⚠️ NON DISPONIBLE",
      );
    }

    if (Date.now() - requestTime > 10 * 60 * 1000) {
      pendingDatabaseRestore.delete(uid);
      return botError(
        ctx,
        "La demande de restauration a expiré. Relance /restore.",
        "⌛ EXPIRÉ",
      );
    }

    const document = ctx.message.document;
    if (!document.file_name?.toLowerCase().endsWith(".json")) {
      return botError(
        ctx,
        "Envoie un fichier de sauvegarde de base au format .json.",
        "⚠️ FICHIER INVALIDE",
      );
    }
    if (document.file_size && document.file_size > 20 * 1024 * 1024) {
      return botError(
        ctx,
        "Le fichier de sauvegarde est trop volumineux. La taille maximale est de 20 Mo.",
        "⚠️ FICHIER TROP VOLUMINEUX",
      );
    }

    try {
      const file = await ctx.getFile();
      if (!file.file_path)
        throw new Error("Telegram n'a pas fourni de chemin de fichier.");
      const fileUrl = `https://api.telegram.org/file/bot${BOT_TOKEN}/${file.file_path}`;
      const response = await fetch(fileUrl);
      if (!response.ok)
        throw new Error(`Échec du téléchargement du fichier Telegram (${response.status}).`);

      const rawBackup = await response.text();
      if (Buffer.byteLength(rawBackup, "utf8") > 20 * 1024 * 1024) {
        throw new Error("Le fichier de sauvegarde est trop volumineux. La taille maximale est de 20 Mo.");
      }

      const backup = JSON.parse(rawBackup);
      const result = restoreDatabaseBackup(backup);
      pendingDatabaseRestore.delete(uid);

      const { deployedBots, stopDeployedBot, restoreDeployedBots } =
        await import("../deploy.js");
      for (const token of [...deployedBots.keys()]) {
        await stopDeployedBot(token);
      }
      await restoreDeployedBots(bot);

      await botSucces(
        ctx,
        `${result.restoredCount} fichiers de base restaurés. Une copie de sécurité pré-restauration a été sauvegardée sous ${path.basename(result.safetyCopy)}. Les fichiers de session WhatsApp sont stockés séparément et ne font pas partie de cette sauvegarde.`,
        "✅ BASE RESTAURÉE",
      );
    } catch (error) {
      log.error(
        `Échec de la restauration de la base pour le propriétaire ${uid} : ${error.message}`,
      );
      return botError(
        ctx,
        `Échec de la restauration : ${error.message}`,
        "❌ ÉCHEC DE LA RESTAURATION",
      );
    }
  });
}
