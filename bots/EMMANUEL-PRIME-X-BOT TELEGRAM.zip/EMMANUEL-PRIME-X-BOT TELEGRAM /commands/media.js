const Y = require('../lib/ytdl')

const NEED = (c, what) => c.reply(`📎 ${what}`)

async function imageToWebp(buffer) {
  let sharp
  try { sharp = require('sharp') } catch { throw new Error("Le module 'sharp' n'est pas installé sur le serveur.") }
  return sharp(buffer, { animated: false }).resize(512, 512, { fit: 'contain', background: { r: 0, g: 0, b: 0, alpha: 0 } }).webp({ quality: 80 }).toBuffer()
}

module.exports = [
  {
    name: 'sticker', aliases: ['s', 'stiker'], cat: 'media', desc: 'Crée un sticker (image, GIF ou vidéo ≤ 7 s)', usage: 'sticker (en répondant à une image)',
    run: async (c) => {
      const media = await c.getMedia()
      if (!media || !['image', 'video'].includes(media.kind)) return NEED(c, 'Envoie ou réponds à une image / GIF / courte vidéo avec cette commande.')
      await c.react('⏳')
      let webp
      if (media.kind === 'image') webp = await imageToWebp(media.buffer)
      else {
        if (media.seconds > 10) return c.reply('⏱️ Vidéo trop longue (10 s max pour un sticker).')
        webp = await Y.ffmpeg(media.buffer, 'mp4', [
          '-t', '6', '-vf', 'fps=10,scale=512:512:force_original_aspect_ratio=decrease,format=rgba,pad=512:512:(ow-iw)/2:(oh-ih)/2:color=0x00000000',
          '-loop', '0', '-an', '-c:v', 'libwebp', '-q:v', '45', '-compression_level', '6'
        ], 'webp')
        if (webp.length > 1024 * 1024) throw new Error('Sticker animé trop lourd, essaie une vidéo plus courte.')
      }
      await c.sticker(webp)
    }
  },
  {
    name: 'toimg', aliases: ['toimage'], cat: 'media', desc: 'Sticker → image', usage: 'toimg (en répondant à un sticker)',
    run: async (c) => {
      const media = await c.getMedia()
      if (!media || media.kind !== 'sticker') return NEED(c, 'Réponds à un sticker avec cette commande.')
      let sharp
      try { sharp = require('sharp') } catch { throw new Error("Le module 'sharp' n'est pas installé sur le serveur.") }
      await c.image(await sharp(media.buffer).png().toBuffer(), '🖼️ Voilà ton image')
    }
  },
  {
    name: 'vv', aliases: ['viewonce', 'reveal'], cat: 'media', owner: true, desc: 'Récupère un média "vue unique"', usage: 'vv (en répondant à la vue unique)',
    run: async (c) => {
      const media = await c.getMedia({ quotedOnly: true })
      if (!media) return NEED(c, 'Réponds à un message à vue unique avec cette commande.')
      if (media.kind === 'image') return c.image(media.buffer, '👁️ Vue unique récupérée')
      if (media.kind === 'video') return c.video(media.buffer, '👁️ Vue unique récupérée')
      if (media.kind === 'audio') return c.audio(media.buffer, 'audio/mp4', 'vocal')
      throw new Error('Type de média non pris en charge.')
    }
  },
  {
    name: 'getpp', aliases: ['pp', 'avatar'], cat: 'media', desc: "Photo de profil d'un utilisateur", usage: 'getpp @user',
    run: async (c) => {
      const target = (await c.getTarget().catch(() => null)) || c.sender
      let url
      try { url = await c.sock.profilePictureUrl(target, 'image') } catch { return c.reply("❌ Pas de photo de profil (ou elle est privée).") }
      await c.image(url, '🖼️ Photo de profil')
    }
  },
  {
    name: 'tomp3', aliases: ['toaudio'], cat: 'media', desc: 'Vidéo → audio MP3', usage: 'tomp3 (en répondant à une vidéo)',
    run: async (c) => {
      const media = await c.getMedia()
      if (!media || !['video', 'audio'].includes(media.kind)) return NEED(c, 'Réponds à une vidéo ou un vocal avec cette commande.')
      await c.react('⏳')
      const mp3 = await Y.toMp3(media.buffer, media.kind === 'video' ? 'mp4' : 'ogg')
      await c.audio(mp3, 'audio/mpeg', 'audio')
    }
  }
]
