import { WORDS, QUIZ } from '../content.js';
import { hooks } from '../router.js';
import * as store from '../store.js';
import { esc, pick, randInt, shuffle, normalize, deaccent, calc } from '../util.js';

const games = new Map(); // `${type}:${chatId}` -> état
const TTL = 15 * 60 * 1000;
const get = (type, chatId) => {
  const g = games.get(`${type}:${chatId}`);
  if (g && g.until < Date.now()) { games.delete(`${type}:${chatId}`); return null; }
  return g || null;
};
const set = (type, chatId, state) => games.set(`${type}:${chatId}`, { ...state, until: Date.now() + TTL });
const del = (type, chatId) => games.delete(`${type}:${chatId}`);
const reward = (user, n) => { store.econ(user.id).coins += n; store.save(); };
setInterval(() => { const now = Date.now(); for (const [k, g] of games) if (g.until < now) games.delete(k); }, 60000).unref();

const HANG = ['', '😐', '😐\n/', '😐\n/|', '😐\n/|\\', '😐\n/|\\\n/', '😐\n/|\\\n/ \\', '💀'];
const hangText = (g) => {
  const mask = [...g.word].map((c) => (g.found.has(normalize(c)) || !/[a-z]/i.test(deaccent(c)) ? c : '_')).join(' ');
  return `🔤 <b>Pendu</b>\n<code>${esc(mask)}</code>\nErreurs : ${g.wrong.size}/6 ${[...g.wrong].join(' ')}\n${esc(HANG[g.wrong.size])}`;
};

// Jeux de dés Telegram : la réponse est envoyée EN DIFFÉRÉ (sans bloquer le chat) quand l'animation se termine.
const DICE = {
  '🎰': { wait: 2800, out: (v) => (v === 64 ? { win: true, gain: 100, t: '🎰 JACKPOT ! Triple 7 !' } : [1, 22, 43].includes(v) ? { win: true, gain: 40, t: '🎰 Trois symboles identiques !' } : { win: false, t: '🎰 Perdu… retente ta chance 😏' }) },
  '🏀': { wait: 4200, out: (v) => (v >= 4 ? { win: true, gain: 25, t: '🏀 Panier ! Joli tir !' } : v === 3 ? { win: false, t: '🏀 Sur le cercle… presque !' } : { win: false, t: '🏀 Raté, la prochaine sera la bonne !' }) },
  '⚽': { wait: 4200, out: (v) => (v >= 3 ? { win: true, gain: 25, t: '⚽ BUUUT !' } : { win: false, t: '⚽ Raté ! Le gardien veille 🧤' }) },
  '🎯': { wait: 3600, out: (v) => (v === 6 ? { win: true, gain: 40, t: '🎯 En plein dans le mille !' } : v >= 4 ? { win: false, t: '🎯 Pas mal, tu es proche !' } : { win: false, t: '🎯 Raté la cible…' }) },
  '🎳': { wait: 3600, out: (v) => (v === 6 ? { win: true, gain: 30, t: '🎳 STRIKE !' } : v >= 4 ? { win: false, t: '🎳 Beaucoup de quilles tombées !' } : { win: false, t: '🎳 Quelques quilles seulement…' }) },
};

async function playDice(ctx, emoji) {
  const m = await ctx.tg.call('sendDice', { chat_id: ctx.chat.id, emoji, ...(ctx.thread ? { message_thread_id: ctx.thread } : {}) }, { retries: 2, timeout: 10000 });
  const v = m?.dice?.value;
  const rule = DICE[emoji];
  if (!v || !rule) return;
  const user = ctx.from; const chatId = ctx.chat.id; const thread = ctx.thread; const tg = ctx.tg;
  setTimeout(async () => {
    try {
      const o = rule.out(v);
      let text = o.t;
      if (o.win) { reward(user, o.gain); text += ` +${o.gain} 🪙`; }
      await tg.sendMessage(chatId, esc(text), { reply_to: m.message_id, thread });
    } catch (e) { console.warn('[dice]', e.message); }
  }, rule.wait);
}

const diceCmd = (name, emoji, aliases, label) => ({
  name, aliases, cat: '🎮 Jeux', desc: `${emoji} ${label}`, cooldown: 3000,
  run: (ctx) => playDice(ctx, emoji),
});

export const defs = [
  diceCmd('slot', '🎰', ['machine'], 'machine à sous'),
  diceCmd('basket', '🏀', [], 'tir au panier'),
  diceCmd('foot', '⚽', ['penalty'], 'tir au but'),
  diceCmd('dart', '🎯', ['fleche'], 'fléchettes'),
  diceCmd('bowling', '🎳', ['quille'], 'bowling'),
  {
    name: 'pfc', aliases: ['chifoumi', 'rps'], cat: '🎮 Jeux', desc: 'pierre-feuille-ciseaux (/pfc pierre)',
    run(ctx) {
      const opts = { pierre: '🪨', feuille: '📄', ciseaux: '✂️' };
      const me = normalize(ctx.args);
      const mine = Object.keys(opts).find((k) => k.startsWith(me) && me);
      if (!mine) return ctx.reply('Joue avec : /pfc pierre, /pfc feuille ou /pfc ciseaux');
      const her = pick(Object.keys(opts));
      const beats = { pierre: 'ciseaux', feuille: 'pierre', ciseaux: 'feuille' };
      let res = 'Égalité !'; 
      if (beats[mine] === her) { res = '🎉 Tu gagnes ! +5 🪙'; reward(ctx.from, 5); } else if (beats[her] === mine) res = '😏 J’ai gagné !';
      return ctx.reply(`Toi : ${opts[mine]}  |  Moi : ${opts[her]}\n${res}`);
    },
  },
  {
    name: 'devine', aliases: ['nombremystere'], cat: '🎮 Jeux', desc: 'devine mon nombre (/devine 100)',
    run(ctx) {
      if (/^(stop|fin|abandon)/i.test(ctx.args)) { del('guess', ctx.chat.id); return ctx.reply('Partie annulée.'); }
      const max = Math.min(Math.max(parseInt(ctx.args, 10) || 100, 10), 1000000);
      set('guess', ctx.chat.id, { n: randInt(1, max), max, tries: 0 });
      return ctx.reply(`🔢 J’ai choisi un nombre entre 1 et ${max}. Envoie tes propositions en message ! (/devine stop pour abandonner)`);
    },
  },
  {
    name: 'pendu', aliases: ['hangman'], cat: '🎮 Jeux', desc: 'jeu du pendu (envoie des lettres)',
    run(ctx) {
      if (/^(stop|fin|abandon)/i.test(ctx.args)) { const g = get('hang', ctx.chat.id); del('hang', ctx.chat.id); return ctx.reply(g ? `Abandon ! C’était <b>${esc(g.word)}</b>.` : 'Pas de partie en cours.'); }
      const g = { word: pick(WORDS), found: new Set(), wrong: new Set() };
      set('hang', ctx.chat.id, g);
      return ctx.reply(`${hangText(g)}\n\nEnvoie une lettre (ou le mot entier). /pendu stop pour abandonner.`);
    },
  },
  {
    name: 'melange', aliases: ['anagrammejeu', 'scramble'], cat: '🎮 Jeux', desc: 'remets les lettres dans l’ordre',
    run(ctx) {
      const w = pick(WORDS.filter((x) => x.length > 4));
      let s = w; for (let i = 0; i < 10 && s === w; i += 1) s = shuffle([...w]).join('');
      set('scr', ctx.chat.id, { w });
      return ctx.reply(`🔀 Retrouve le mot : <b>${esc(s.toUpperCase())}</b>`);
    },
  },
  {
    name: 'calcul', aliases: ['math', 'defimath'], cat: '🎮 Jeux', desc: 'défi de calcul mental',
    run(ctx) {
      const a = randInt(2, 30); const b = randInt(2, 20); const op = pick(['+', '-', '×']);
      const ans = op === '+' ? a + b : op === '-' ? a - b : a * b;
      set('math', ctx.chat.id, { ans });
      return ctx.reply(`🧮 Combien font <b>${a} ${op} ${b}</b> ? (premier à répondre gagne)`);
    },
  },
  {
    name: 'quiz', aliases: ['qcm'], cat: '🎮 Jeux', desc: 'une question de culture générale', cooldown: 4000,
    async run(ctx) {
      const q = pick(QUIZ);
      await ctx.tg.call('sendPoll', {
        chat_id: ctx.chat.id, question: q.q.slice(0, 300), options: q.o.map((x) => x.slice(0, 100)), type: 'quiz', correct_option_id: q.c,
        is_anonymous: false, ...(ctx.thread ? { message_thread_id: ctx.thread } : {}),
      });
    },
  },
];

// Réponses libres aux jeux en cours
hooks.push(async (ctx) => {
  const t = (ctx.msg.text || '').trim();
  if (!t || t.length > 40) return false;
  const id = ctx.chat.id;
  const math = get('math', id);
  if (math && /^-?\d+$/.test(t)) {
    if (parseInt(t, 10) === math.ans) { del('math', id); reward(ctx.from, 10); await ctx.reply(`✅ Bravo ${esc(ctx.name)} ! +10 🪙`); return true; }
  }
  const g = get('guess', id);
  if (g && /^\d{1,7}$/.test(t)) {
    const n = parseInt(t, 10); g.tries += 1;
    if (n === g.n) { del('guess', id); reward(ctx.from, 20); await ctx.reply(`🎉 Trouvé en ${g.tries} essai(s), ${esc(ctx.name)} ! +20 🪙`); } else await ctx.reply(n < g.n ? '⬆️ Plus grand !' : '⬇️ Plus petit !');
    return true;
  }
  const scr = get('scr', id);
  if (scr && normalize(t) === normalize(scr.w)) { del('scr', id); reward(ctx.from, 10); await ctx.reply(`✅ Bien joué ${esc(ctx.name)} ! C’était <b>${esc(scr.w)}</b>. +10 🪙`); return true; }
  const h = get('hang', id);
  if (h && /^\p{L}+$/u.test(t)) {
    const guess = normalize(t);
    if (guess.length === 1) {
      if (h.found.has(guess) || h.wrong.has(guess)) { await ctx.reply('Cette lettre a déjà été jouée.'); return true; }
      if (normalize(h.word).includes(guess)) h.found.add(guess); else h.wrong.add(guess);
    } else if (guess.length === normalize(h.word).length) {
      if (guess === normalize(h.word)) [...guess].forEach((c) => h.found.add(c)); else { h.wrong.add('✖'); }
    } else return false;
    const complete = [...normalize(h.word)].every((c) => h.found.has(c));
    if (complete) { del('hang', id); reward(ctx.from, 15); await ctx.reply(`🎉 Gagné ! Le mot était <b>${esc(h.word)}</b>. +15 🪙`); } else if (h.wrong.size >= 6) { del('hang', id); await ctx.reply(`${hangText(h)}\n💀 Perdu ! C’était <b>${esc(h.word)}</b>.`); } else await ctx.reply(hangText(h));
    return true;
  }
  return false;
});
// Un dé/emoji envoyé en privé : on joue avec lui au lieu de le confier à l'IA.
hooks.push(async (ctx) => {
  if (!ctx.isPrivate) return false;
  const d = ctx.msg.dice;
  if (d && DICE[d.emoji]) {
    const o = DICE[d.emoji].out(d.value);
    await ctx.reply(esc(`${o.t}${o.win ? ' (bravo !)' : ''}`));
    return true;
  }
  const t = (ctx.msg.text || '').replace(/\uFE0F/g, '').trim();
  if (DICE[t]) { await playDice(ctx, t); return true; }
  return false;
});
export default defs;
