import fs from 'node:fs';
import * as store from '../store.js';
import * as ai from '../ai.js';
import { DATA_FILE } from '../config.js';
import { esc, sleep, fmtDuration } from '../util.js';
import { errorLog } from '../router.js';

const O = { cat: '👑 Propriétaire', owner: true };

export const defs = [
  {
    ...O, name: 'broadcast', aliases: ['diffusion', 'bc'], desc: 'envoyer un message à tous les chats',
    async run(ctx) {
      const text = ctx.args || ctx.msg.reply_to_message?.text;
      if (!text) return ctx.reply('Usage : /broadcast ton message');
      const ids = Object.values(store.db.chats).map((c) => c.id);
      await ctx.reply(`📣 Envoi à ${ids.length} chat(s)…`);
      let ok = 0; let ko = 0;
      for (const id of ids) {
        try { await ctx.tg.sendMessage(id, esc(text)); ok += 1; } catch (e) {
          ko += 1;
          if (/blocked|deactivated|kicked|not found|not a member/i.test(e.description || '')) delete store.db.chats[String(id)];
        }
        await sleep(60);
      }
      store.save();
      return ctx.reply(`✅ Envoyé : ${ok} · échecs : ${ko}`);
    },
  },
  {
    ...O, name: 'users', desc: 'nombre d’utilisateurs et de groupes',
    run(ctx) {
      const chats = Object.values(store.db.chats);
      return ctx.reply(`👥 Utilisateurs : ${Object.keys(store.db.users).length}\n💬 Privés : ${chats.filter((c) => c.type === 'private').length}\n🏘️ Groupes : ${chats.filter((c) => c.type !== 'private').length}\n⏱️ En ligne depuis ${fmtDuration(process.uptime())}`);
    },
  },
  {
    ...O, name: 'blacklist', aliases: ['bl'], desc: 'bloquer un utilisateur (réponds ou /blacklist ID)',
    run(ctx) {
      const id = ctx.target?.id || parseInt(ctx.args, 10);
      if (!Number.isFinite(id)) return ctx.reply('Usage : réponds à quelqu’un ou /blacklist 123456');
      if (!store.db.blacklist.includes(id)) store.db.blacklist.push(id);
      store.save();
      return ctx.reply(`🚫 ${id} est ignoré par le bot.`);
    },
  },
  {
    ...O, name: 'unblacklist', aliases: ['unbl'], desc: 'débloquer un utilisateur',
    run(ctx) {
      const id = ctx.target?.id || parseInt(ctx.args, 10);
      store.db.blacklist = store.db.blacklist.filter((x) => x !== id); store.save();
      return ctx.reply(`✅ ${id} n’est plus ignoré.`);
    },
  },
  {
    ...O, name: 'say', aliases: ['dis'], desc: 'faire parler le bot (/say texte)',
    async run(ctx) {
      if (!ctx.args) return ctx.reply('Usage : /say texte');
      await ctx.say(esc(ctx.args));
      if (ctx.isGroup) await ctx.tg.call('deleteMessage', { chat_id: ctx.chat.id, message_id: ctx.msg.message_id }).catch(() => {});
    },
  },
  {
    ...O, name: 'backup', desc: 'recevoir le fichier de données',
    async run(ctx) {
      store.flush();
      if (!fs.existsSync(DATA_FILE)) return ctx.reply('Aucune donnée à sauvegarder pour l’instant.');
      await ctx.tg.sendMedia('document', ctx.chat.id, { buffer: fs.readFileSync(DATA_FILE), filename: 'queen-hina-backup.json', contentType: 'application/json' }, { caption: '💾 Sauvegarde' });
    },
  },
  {
    ...O, name: 'aistatus', aliases: ['ia_status'], desc: 'état des fournisseurs IA',
    run(ctx) {
      const st = ai.status();
      if (!st.length) return ctx.reply('Aucune clé IA configurée (OPENROUTER_API_KEY, GROQ_API_KEY ou GEMINI_API_KEY dans .env).');
      return ctx.reply(st.map((s) => `${s.available ? '🟢' : '🔴'} <b>${esc(s.name)}</b> (${esc(s.models)})${s.waitSec ? ` — pause ${fmtDuration(s.waitSec)}${s.quota ? ' (quota journalier)' : ''}` : ''}${s.lastError ? `\n   dernière erreur : ${esc(s.lastError)}` : ''}`).join('\n'));
    },
  },
  {
    ...O, name: 'errors', aliases: ['erreurs', 'debug'], desc: 'dernières erreurs internes du bot',
    run(ctx) { return ctx.reply(errorLog.length ? `🐞 <b>Dernières erreurs</b>\n<code>${esc(errorLog.slice(-12).join('\n'))}</code>` : '✅ Aucune erreur depuis le démarrage.'); },
  },
  {
    ...O, name: 'leave', desc: 'quitter ce groupe', group: true,
    async run(ctx) { await ctx.say('Au revoir ! 👋'); await ctx.tg.call('leaveChat', { chat_id: ctx.chat.id }); },
  },
];
export default defs;
