import * as ai from '../ai.js';
import { esc } from '../util.js';
import { chatLocked, lockedReply } from './access.js';

const src = (ctx) => ctx.args || ctx.msg.reply_to_message?.text || ctx.msg.reply_to_message?.caption || '';

function aiCmd(name, desc, instruction, { aliases = [], need = true, usage } = {}) {
  return {
    name, aliases, desc, cat: '🤖 IA', cooldown: 4000,
    async run(ctx) {
      if (chatLocked(ctx.from.id)) return lockedReply(ctx, { always: true }); // chat payant : commandes IA réservées aux abonnés
      const input = src(ctx);
      if (need && !input) return ctx.reply(usage || `Usage : /${name} &lt;texte&gt; (ou réponds à un message)`);
      if (!ai.hasProvider()) return ctx.reply('L’IA n’est pas configurée (clé manquante dans .env) 🙈');
      ctx.tg.typing(ctx.chat.id, 'typing', ctx.thread);
      const r = await ai.task(instruction, input || 'Surprends-moi.');
      await ctx.reply(r.text ? esc(r.text) : esc(ai.fallbackReply(r.error === 'quota')));
    },
  };
}

export const defs = [
  aiCmd('ia', 'pose une question à l’IA', 'Tu es un assistant francophone clair, précis et concis.', { aliases: ['ask', 'q', 'gpt'], usage: 'Usage : /ia Pourquoi le ciel est bleu ?' }),
  aiCmd('explique', 'explique simplement un sujet', 'Explique le sujet de façon simple et claire, comme à un débutant curieux, en 6 phrases maximum.', { aliases: ['eli5'] }),
  aiCmd('resume', 'résume un texte (réponds à un message)', 'Résume le texte en quelques points essentiels, dans la langue du texte.', { aliases: ['summary', 'tldr'] }),
  aiCmd('corrige', 'corrige l’orthographe', 'Corrige l’orthographe, la grammaire et la ponctuation du texte sans changer le sens. Donne uniquement le texte corrigé.', { aliases: ['correct'] }),
  aiCmd('reformule', 'reformule un texte', 'Reformule le texte de manière plus claire et élégante, en gardant le sens. Donne uniquement la reformulation.', { aliases: ['rewrite'] }),
  aiCmd('poeme', 'un poème sur un thème', 'Écris un court poème (8 lignes maximum) en français sur le thème donné.', { aliases: ['poem'], usage: 'Usage : /poeme la mer' }),
  aiCmd('histoire', 'une mini-histoire sur un thème', 'Écris une mini-histoire captivante en français (120 mots maximum) sur le thème donné.', { aliases: ['story'], usage: 'Usage : /histoire un dragon timide' }),
  aiCmd('conseil', 'un conseil bienveillant', 'Donne un conseil bienveillant, concret et chaleureux en français (5 phrases maximum). Si c’est un sujet de santé ou de droit, rappelle de consulter un professionnel.', { aliases: ['advice'], usage: 'Usage : /conseil je stresse avant mon examen' }),
  aiCmd('idee', 'des idées créatives', 'Propose 5 idées originales et concrètes en français sur le sujet, sous forme de courte liste.', { aliases: ['brainstorm'], need: false }),
  aiCmd('blagueia', 'une blague inventée par l’IA', 'Raconte une blague courte, drôle et inédite en français, tout public.', { aliases: ['jokeia'], need: false }),
  aiCmd('devinettia', 'une énigme inventée par l’IA', 'Invente une énigme originale en français, puis donne la réponse après "Réponse :" séparée par une ligne vide.', { need: false }),
  aiCmd('recette', 'une recette avec tes ingrédients', 'Propose une recette simple en français avec les ingrédients ou le plat indiqué : ingrédients puis étapes courtes.', { aliases: ['cuisine'], usage: 'Usage : /recette poulet riz tomates' }),
  aiCmd('code', 'aide en programmation', 'Tu es un développeur expert. Réponds brièvement avec un exemple de code clair en texte brut.', { aliases: ['dev'], usage: 'Usage : /code boucle for en python' }),
  aiCmd('definition', 'définition d’un mot', 'Donne la définition claire d’un mot ou d’une expression en français, avec un exemple de phrase.', { aliases: ['def', 'dico'], usage: 'Usage : /definition éphémère' }),
  aiCmd('citationia', 'une citation inventée sur un thème', 'Invente une citation inspirante originale en français sur le thème donné (sans l’attribuer à une personne réelle).', { need: false }),
];
export default defs;
