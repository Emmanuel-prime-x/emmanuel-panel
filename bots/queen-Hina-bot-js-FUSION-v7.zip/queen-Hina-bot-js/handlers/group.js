import { BOT_NAME } from '../config.js';
import * as store from '../store.js';
import { hooks } from '../router.js';
import { esc, mentionHtml, userName, parseDuration, fmtDuration, pick } from '../util.js';

const G = { cat: '👥 Groupe', group: true };
const ADM = { ...G, admin: true };
const URL_RE = /(https?:\/\/|www\.|t\.me\/|\b[a-z0-9-]+\.(?:com|net|org|io|me|ly|gg|xyz|fr)\b)/i;

export async function onJoin(tg, msg) {
  const s = store.chatSettings(msg.chat.id);
  for (const m of msg.new_chat_members) {
    if (m.id === tg.me.id) {
      await tg.sendMessage(msg.chat.id, `Coucou tout le monde ✨ Je suis <b>${esc(BOT_NAME)}</b> ! Tape /menu pour voir ce que je sais faire. Pour la modération, mets-moi administratrice 🙏`);
      continue;
    }
    if (m.is_bot || !s.welcomeEnabled) continue;
    const tpl = s.welcomeText || 'Bienvenue {name} dans {group} ! Ravie de t’avoir parmi nous ✨';
    const text = esc(tpl).replace(/\{name\}/g, mentionHtml(m)).replace(/\{group\}/g, esc(msg.chat.title || 'le groupe'));
    await tg.sendMessage(msg.chat.id, text);
  }
}

const toggle = (key, label) => ({
  name: key.toLowerCase(), cat: '👥 Groupe', group: true, admin: true, desc: `activer/désactiver : ${label} (on/off)`,
  run(ctx) {
    const a = ctx.args.toLowerCase();
    if (a !== 'on' && a !== 'off') return ctx.reply(`Usage : /${key.toLowerCase()} on ou /${key.toLowerCase()} off (actuellement : ${store.chatSettings(ctx.chat.id)[key] ? 'on' : 'off'})`);
    store.setChatSetting(ctx.chat.id, { [key]: a === 'on' });
    return ctx.reply(`${label} : <b>${a}</b> ✅`);
  },
});

export const defs = [
  { ...toggle('antilink', 'anti-liens (supprime les liens des non-admins)') },
  {
    name: 'bienvenue', cat: '👥 Groupe', group: true, admin: true, desc: 'message de bienvenue on/off',
    run(ctx) {
      const a = ctx.args.toLowerCase();
      if (a !== 'on' && a !== 'off') return ctx.reply('Usage : /bienvenue on ou off');
      store.setChatSetting(ctx.chat.id, { welcomeEnabled: a === 'on' });
      return ctx.reply(`Message de bienvenue ${a === 'on' ? 'activé' : 'désactivé'} ✅`);
    },
  },
  {
    ...ADM, name: 'textebienvenue', desc: 'texte de bienvenue ({name} {group})',
    run(ctx) {
      if (!ctx.args) return ctx.reply('Usage : /textebienvenue Bienvenue {name} dans {group} !');
      store.setChatSetting(ctx.chat.id, { welcomeText: ctx.args.slice(0, 800) });
      return ctx.reply('Texte de bienvenue mis à jour ✅');
    },
  },
  {
    ...ADM, name: 'setregles', aliases: ['setrules'], desc: 'définir les règles',
    run(ctx) {
      if (!ctx.args) return ctx.reply('Usage : /setregles <texte>');
      store.setChatSetting(ctx.chat.id, { rulesText: ctx.args.slice(0, 2000) });
      return ctx.reply('Règles enregistrées ✅');
    },
  },
  {
    ...G, name: 'regles', aliases: ['rules'], desc: 'afficher les règles',
    run(ctx) {
      const r = store.chatSettings(ctx.chat.id).rulesText;
      return ctx.reply(r ? `📋 <b>Règles du groupe</b>\n\n${esc(r)}` : 'Aucune règle définie pour ce groupe.');
    },
  },
  {
    ...ADM, name: 'silence', aliases: ['tais'], desc: 'je ne discute plus dans ce groupe',
    run(ctx) { store.setChatSetting(ctx.chat.id, { muted: true }); return ctx.reply('Je me tais dans ce groupe jusqu’à /reveil 🤐'); },
  },
  {
    ...ADM, name: 'reveil', aliases: ['parle'], desc: 'je rediscute dans ce groupe',
    run(ctx) { store.setChatSetting(ctx.chat.id, { muted: false }); return ctx.reply('Je suis de retour ! 👋'); },
  },
  {
    ...G, name: 'top', aliases: ['actifs'], desc: 'membres les plus actifs',
    run(ctx) {
      const m = store.db.chats[String(ctx.chat.id)]?.members || {};
      const rows = Object.values(m).sort((a, b) => b.count - a.count).slice(0, 10);
      if (!rows.length) return ctx.reply('Pas encore assez de messages pour un classement.');
      return ctx.reply(`🏆 <b>Membres les plus actifs</b>\n${rows.map((r, i) => `${['🥇', '🥈', '🥉'][i] || `${i + 1}.`} ${esc(r.name)} — ${r.count}`).join('\n')}`);
    },
  },
  {
    ...G, name: 'designer', aliases: ['tirage', 'who'], desc: 'désigne quelqu’un au hasard',
    run(ctx) {
      const m = Object.entries(store.db.chats[String(ctx.chat.id)]?.members || {});
      if (!m.length) return ctx.reply('Je n’ai pas encore vu assez de monde parler ici.');
      const [id, u] = pick(m);
      return ctx.reply(`🎯 ${mentionHtml({ id, first_name: u.name })} ${ctx.args ? `: ${esc(ctx.args)}` : 'a été désigné(e) !'}`);
    },
  },
  {
    ...ADM, name: 'tagall', aliases: ['tous', 'everyone'], desc: 'mentionne les membres récents',
    async run(ctx) {
      const m = Object.entries(store.db.chats[String(ctx.chat.id)]?.members || {}).sort((a, b) => b[1].last - a[1].last).slice(0, 60);
      if (!m.length) return ctx.reply('Je n’ai pas encore vu de membres parler ici.');
      const tags = m.map(([id, u]) => mentionHtml({ id, first_name: u.name }));
      for (let i = 0; i < tags.length; i += 15) await ctx.say(`${i === 0 && ctx.args ? `📢 ${esc(ctx.args)}\n` : ''}${tags.slice(i, i + 15).join(' ')}`);
    },
  },
  {
    ...ADM, name: 'warn', needsTarget: true, desc: 'avertir un membre (3 = exclusion)',
    async run(ctx) {
      if (ctx.target.id === ctx.tg.me.id) return ctx.reply('Pas moi, voyons 😇');
      if (await ctx.isAdmin(ctx.target.id)) return ctx.reply('Je ne peux pas avertir un admin.');
      const key = `${ctx.chat.id}:${ctx.target.id}`;
      const n = (store.db.warns[key] || 0) + 1; store.db.warns[key] = n; store.save();
      if (n >= 3) {
        delete store.db.warns[key]; store.save();
        await ctx.tg.call('banChatMember', { chat_id: ctx.chat.id, user_id: ctx.target.id });
        await ctx.tg.call('unbanChatMember', { chat_id: ctx.chat.id, user_id: ctx.target.id, only_if_banned: true });
        return ctx.say(`🚫 ${mentionHtml(ctx.target)} a atteint 3 avertissements et a été exclu(e).`);
      }
      return ctx.say(`⚠️ ${mentionHtml(ctx.target)} : avertissement <b>${n}/3</b>${ctx.args ? ` — ${esc(ctx.args)}` : ''}`);
    },
  },
  { ...ADM, name: 'unwarn', needsTarget: true, desc: 'retirer les avertissements', run(ctx) { delete store.db.warns[`${ctx.chat.id}:${ctx.target.id}`]; store.save(); return ctx.reply(`✅ Avertissements de ${mentionHtml(ctx.target)} remis à zéro.`); } },
  { ...G, name: 'warns', needsTarget: false, desc: 'voir les avertissements', run(ctx) { const u = ctx.target || ctx.from; return ctx.reply(`⚠️ ${mentionHtml(u)} : ${store.db.warns[`${ctx.chat.id}:${u.id}`] || 0}/3`); } },
  {
    ...ADM, name: 'kick', aliases: ['exclure'], needsTarget: true, desc: 'exclure un membre (peut revenir)',
    async run(ctx) {
      if (ctx.target.id === ctx.from.id) return ctx.reply('Tu ne peux pas t’exclure toi-même 😄');
      await ctx.tg.call('banChatMember', { chat_id: ctx.chat.id, user_id: ctx.target.id });
      await ctx.tg.call('unbanChatMember', { chat_id: ctx.chat.id, user_id: ctx.target.id, only_if_banned: true });
      return ctx.say(`👢 ${mentionHtml(ctx.target)} a été exclu(e)${ctx.args ? ` (${esc(ctx.args)})` : ''}.`);
    },
  },
  {
    ...ADM, name: 'ban', aliases: ['bannir'], needsTarget: true, desc: 'bannir un membre',
    async run(ctx) {
      if (ctx.target.id === ctx.from.id) return ctx.reply('Tu ne peux pas te bannir toi-même 😄');
      await ctx.tg.call('banChatMember', { chat_id: ctx.chat.id, user_id: ctx.target.id });
      return ctx.say(`🚫 ${mentionHtml(ctx.target)} a été banni(e)${ctx.args ? ` (${esc(ctx.args)})` : ''}.`);
    },
  },
  {
    ...ADM, name: 'unban', aliases: ['debannir'], needsTarget: true, desc: 'débannir un membre',
    async run(ctx) { await ctx.tg.call('unbanChatMember', { chat_id: ctx.chat.id, user_id: ctx.target.id, only_if_banned: true }); return ctx.say(`✅ ${mentionHtml(ctx.target)} peut revenir.`); },
  },
  {
    ...ADM, name: 'mute', aliases: ['muet'], needsTarget: true, desc: 'rendre muet (/mute 10m)',
    async run(ctx) {
      const secs = parseDuration(ctx.args) || 0;
      const until = secs >= 30 ? Math.floor(Date.now() / 1000) + secs : 0; // 0 = indéfiniment
      await ctx.tg.call('restrictChatMember', { chat_id: ctx.chat.id, user_id: ctx.target.id, permissions: { can_send_messages: false }, ...(until ? { until_date: until } : {}) });
      return ctx.say(`🔇 ${mentionHtml(ctx.target)} est muet(te) ${until ? `pendant ${fmtDuration(secs)}` : 'jusqu’à /unmute'}.`);
    },
  },
  {
    ...ADM, name: 'unmute', needsTarget: true, desc: 'redonner la parole',
    async run(ctx) {
      const all = { can_send_messages: true, can_send_audios: true, can_send_documents: true, can_send_photos: true, can_send_videos: true, can_send_video_notes: true, can_send_voice_notes: true, can_send_polls: true, can_send_other_messages: true, can_add_web_page_previews: true, can_invite_users: true };
      await ctx.tg.call('restrictChatMember', { chat_id: ctx.chat.id, user_id: ctx.target.id, permissions: all });
      return ctx.say(`🔊 ${mentionHtml(ctx.target)} peut de nouveau parler.`);
    },
  },
  {
    ...ADM, name: 'pin', aliases: ['epingler'], desc: 'épingler (réponds à un message)',
    async run(ctx) {
      if (!ctx.msg.reply_to_message) return ctx.reply('Réponds au message à épingler avec /pin');
      await ctx.tg.call('pinChatMessage', { chat_id: ctx.chat.id, message_id: ctx.msg.reply_to_message.message_id });
      return ctx.say('📌 Message épinglé.');
    },
  },
  {
    ...ADM, name: 'unpin', aliases: ['depingler'], desc: 'désépingler',
    async run(ctx) {
      await ctx.tg.call('unpinChatMessage', { chat_id: ctx.chat.id, ...(ctx.msg.reply_to_message ? { message_id: ctx.msg.reply_to_message.message_id } : {}) });
      return ctx.say('📌 Message désépinglé.');
    },
  },
  {
    ...ADM, name: 'del', aliases: ['supprimer', 'delete'], desc: 'supprimer le message auquel tu réponds',
    async run(ctx) {
      if (!ctx.msg.reply_to_message) return ctx.reply('Réponds au message à supprimer avec /del');
      await ctx.tg.call('deleteMessage', { chat_id: ctx.chat.id, message_id: ctx.msg.reply_to_message.message_id });
      await ctx.tg.call('deleteMessage', { chat_id: ctx.chat.id, message_id: ctx.msg.message_id }).catch(() => {});
    },
  },
  {
    ...ADM, name: 'promouvoir', aliases: ['promote'], needsTarget: true, desc: 'nommer modérateur',
    async run(ctx) {
      await ctx.tg.call('promoteChatMember', { chat_id: ctx.chat.id, user_id: ctx.target.id, can_delete_messages: true, can_restrict_members: true, can_pin_messages: true, can_invite_users: true, can_manage_chat: true });
      return ctx.say(`⭐ ${mentionHtml(ctx.target)} est maintenant modérateur/trice.`);
    },
  },
  {
    ...ADM, name: 'retrograder', aliases: ['demote'], needsTarget: true, desc: 'retirer les droits d’admin',
    async run(ctx) {
      await ctx.tg.call('promoteChatMember', { chat_id: ctx.chat.id, user_id: ctx.target.id, can_delete_messages: false, can_restrict_members: false, can_pin_messages: false, can_invite_users: false, can_manage_chat: false, can_promote_members: false, can_change_info: false });
      return ctx.say(`${mentionHtml(ctx.target)} n’est plus modérateur/trice.`);
    },
  },
  {
    ...ADM, name: 'settitle', aliases: ['titre'], desc: 'changer le nom du groupe',
    async run(ctx) { if (!ctx.args) return ctx.reply('Usage : /settitle Nouveau nom'); await ctx.tg.call('setChatTitle', { chat_id: ctx.chat.id, title: ctx.args.slice(0, 128) }); },
  },
  {
    ...ADM, name: 'setdesc', desc: 'changer la description du groupe',
    async run(ctx) { await ctx.tg.call('setChatDescription', { chat_id: ctx.chat.id, description: ctx.args.slice(0, 255) }); return ctx.reply('✅ Description mise à jour.'); },
  },
  {
    ...ADM, name: 'invite', aliases: ['lien'], desc: 'lien d’invitation',
    async run(ctx) { const l = await ctx.tg.call('exportChatInviteLink', { chat_id: ctx.chat.id }); return ctx.reply(`🔗 ${esc(l)}`); },
  },
  {
    ...G, name: 'admins', aliases: ['staff'], desc: 'liste des admins',
    async run(ctx) {
      const list = await ctx.tg.call('getChatAdministrators', { chat_id: ctx.chat.id });
      const lines = (Array.isArray(list) ? list : []).filter((a) => !a.user.is_bot).map((a) => `${a.status === 'creator' ? '👑' : '⭐'} ${mentionHtml(a.user)}`);
      return ctx.reply(`<b>Administrateurs</b>\n${lines.join('\n') || '—'}`);
    },
  },
  {
    cat: '👥 Groupe', name: 'groupinfo', aliases: ['ginfo'], group: true, desc: 'infos du groupe',
    async run(ctx) {
      const [chat, count] = await Promise.all([ctx.tg.call('getChat', { chat_id: ctx.chat.id }), ctx.tg.call('getChatMemberCount', { chat_id: ctx.chat.id })]);
      return ctx.reply(`<b>${esc(chat.title || 'Ce chat')}</b>\nType : ${chat.type}\nID : <code>${chat.id}</code>\nMembres : ${count}${chat.description ? `\n\n${esc(chat.description)}` : ''}`);
    },
  },
  {
    cat: '👥 Groupe', name: 'whois', aliases: ['qui'], desc: 'infos sur une personne (réponds à son message)',
    run(ctx) {
      const u = ctx.target || ctx.from;
      return ctx.reply(`👤 ${mentionHtml(u)}\n${u.username ? `Pseudo : @${esc(u.username)}\n` : ''}ID : <code>${u.id}</code>${u.language_code ? `\nLangue : ${esc(u.language_code)}` : ''}`);
    },
  },
  {
    cat: '👥 Groupe', name: 'afk', desc: 'te déclarer absent (/afk raison)', group: true,
    run(ctx) {
      store.db.afk[ctx.from.id] = { since: Date.now(), reason: ctx.args.slice(0, 100) }; store.save();
      return ctx.reply(`😴 ${esc(ctx.name)} est maintenant AFK${ctx.args ? ` : ${esc(ctx.args.slice(0, 100))}` : ''}`);
    },
  },
];

// ---- hooks de groupe : retour d'AFK, mentions d'absents, anti-liens ----
hooks.push(async (ctx) => {
  if (!ctx.isGroup) return false;
  const text = ctx.text || '';
  const s = store.chatSettings(ctx.chat.id);
  if (s.antilink && text && (URL_RE.test(text) || (ctx.msg.entities || []).some((e) => e.type === 'text_link' || e.type === 'url'))) {
    if (!(await ctx.isAdmin()) && (await ctx.botIsAdmin())) {
      try { await ctx.tg.call('deleteMessage', { chat_id: ctx.chat.id, message_id: ctx.msg.message_id }); await ctx.say(`🔗 ${mentionHtml(ctx.from)}, les liens ne sont pas autorisés ici.`); return true; } catch { /* ignore */ }
    }
  }
  const back = store.db.afk[ctx.from.id];
  if (back) {
    delete store.db.afk[ctx.from.id]; store.save();
    await ctx.say(`👋 Bon retour ${esc(ctx.name)} ! (absent depuis ${fmtDuration((Date.now() - back.since) / 1000)})`);
  }
  const ids = new Set();
  if (ctx.msg.reply_to_message?.from) ids.add(ctx.msg.reply_to_message.from.id);
  for (const e of ctx.msg.entities || []) {
    if (e.type === 'text_mention' && e.user) ids.add(e.user.id);
    if (e.type === 'mention') {
      const uname = text.slice(e.offset + 1, e.offset + e.length).toLowerCase();
      const u = Object.values(store.db.users).find((x) => x.username && x.username.toLowerCase() === uname);
      if (u) ids.add(u.id);
    }
  }
  for (const id of ids) {
    const a = store.db.afk[id];
    if (a) await ctx.reply(`😴 ${esc(store.db.users[id]?.name || 'Cette personne')} est AFK depuis ${fmtDuration((Date.now() - a.since) / 1000)}${a.reason ? ` : ${esc(a.reason)}` : ''}`);
  }
  return false;
});
export default defs;
