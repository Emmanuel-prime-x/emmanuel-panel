# 👑 Queen Hina v2 — bot Telegram (Node.js, zéro dépendance)

Compagne virtuelle IA + **261 commandes** : réactions animées nekos.best (`.kiss` `.hug`…), tes propres chansons, jeux, économie, modération de groupe, outils, IA.

## Installation sur le panel (KataBump / Pterodactyl)
1. Envoie tous les fichiers à la racine du serveur (supprime l'ancienne version avant).
2. Fichier de démarrage : **`index.js`**. Node 18 ou plus (ton panel a Node 24 ✅).
3. **Aucun `npm install` nécessaire** (le bot n'utilise aucune bibliothèque externe).
4. Ouvre `.env` et vérifie `TELEGRAM_TOKEN`, `OPENROUTER_API_KEY` et `OWNER_ID`.
5. Démarre. La console doit afficher `✅ Queen Hina est prête !`.

> ⚠️ Ton token Telegram et ta clé OpenRouter ont été partagés dans une conversation : va sur @BotFather → `/revoke` pour en générer un nouveau et change-le dans `.env`. Ne partage jamais `.env`.

## Utilisation
- Préfixes acceptés : `/commande`, `.commande`, `!commande` (ex : `.kiss`, `!hug`).
- `/menu` : menu interactif par catégories. `/id` : ton ID (à mettre dans `OWNER_ID`).
- Privé : parle-lui directement. Groupe : mentionne `@pseudo_du_bot`, réponds à un de ses messages ou écris « Hina ».
- `/errors` (propriétaire) : dernières erreurs internes. `/aistatus` : état de l'IA.
- Modération (`/kick /ban /mute /warn /del…`) : mets le bot **administrateur** du groupe.

## 🎭 Réactions (nekos.best)
Réponds au message de quelqu'un puis `.kiss` `.hug` `.pat` `.cuddle` `.slap` `.punch` `.pied` `.bite` `.poke` `.tickle` `.feed`… ou seul : `.cry` `.dance` `.blush` `.laugh`… Images : `.neko` `.waifu` `.kitsune` `.husbando`. Liste : `/reactions`.

## 🎵 Ta propre chanson
- **Méthode 1** : dépose tes fichiers (`.mp3 .m4a .ogg .wav .flac`, 50 Mo max) dans `media/songs/`.
- **Méthode 2** : envoie un audio au bot puis réponds-y avec `/addsong Titre` (propriétaire uniquement).
- `/chanson` (ou `/song`) envoie une chanson, `/chanson 2` ou `/chanson nom` en choisit une, `/chansons` liste, `/delsong` supprime.
- Photos : `media/photos/`, vidéos : `media/videos/` (`/photo`, `/video`).

## 🎲 Jeux à plusieurs (dans un groupe)
`/jeux` : liste. `/morpion` (réponds à quelqu'un pour le défier, boutons), `/duel 50` (pierre-feuille-ciseaux avec mise, réponds à l'adversaire), `/quizmulti 5` (quiz à boutons + classement), `/tournoi 5` (le plus rapide à répondre), `/roulette 20` (roulette russe avec cagnotte). `/stopjeu` (admin) arrête les parties. Les parties vivent en mémoire : un redémarrage les annule.

## 🪙 Pièces
Le propriétaire (`OWNER_ID`) a des pièces illimitées (∞). Les autres joueurs gagnent leurs pièces avec `/daily`, `/work`, les jeux et les étoiles envoyées.

## 🛍️ Économie avancée
- **Niveaux & XP** : chaque message (toutes les 30 s max) donne de l'XP, `/daily` et `/work` aussi. Montée de niveau = pièces offertes. `/niveau`, `/topxp`.
- **Boutique** : `/boutique`, `/acheter bouclier 2`, `/inventaire`, `/utiliser bouclier`, `/vendre` (50 %). Objets : 🛡️ bouclier (anti-vol 24 h), 🍀 trèfle (pari à 65 %), ⛏️ pioche (/work ×2), 🗝️ crochet (vol à 75 %), 🧪 potion d'XP, 🎟️ ticket à gratter, et les badges 💍 👑 💎.
- **Banque** : `/banque`, `/depot 100`, `/retrait 100`. Les pièces en banque sont à l'abri des vols et rapportent 2 %/jour (plafond qui grandit avec le niveau).
- **Vol** : réponds à quelqu'un avec `/voler` (50 % de réussite, amende si échec, 30 min de délai). Le créateur ne peut pas être volé.

## 🎮 Nouveaux jeux

`/blackjack 50` (boutons Tirer / Rester / Doubler, blackjack payé 3:2, reste automatique après 3 min d'inactivité), `/puissance4` (à deux, réponds à quelqu'un pour le défier), `/roue 50` (roue de la fortune, de ×0 à ×5).

## 🧠 Personnalité de Hina
- `/souvenir j'adore les chats` : Hina retient jusqu'à 15 faits sur toi et s'en sert naturellement. `/souvenirs`, `/oublier 2`, `/oublier tout`.
- `/affinite` : plus vous discutez, plus Hina est proche de toi (5 paliers) et plus son ton devient complice.
- `/humeurhina` : humeur du jour (change chaque jour ; le créateur peut la forcer ou remettre `auto`).
- `/style douce|taquine|pro|poete|genz|normal` : choisis sa façon de te répondre.
- En groupe, Hina distingue maintenant qui parle (les messages sont préfixés par le prénom dans l'historique).

## 🔒 Chat payant (étoiles Telegram)
Le créateur peut réserver **la discussion libre avec Hina et toutes les commandes IA** (/ia, /explique, /resume, /poeme, /histoire…) aux personnes qui ont payé. Les autres commandes (menu, jeux, boutique…) restent gratuites, et le créateur a tout gratuitement.
- `/chatpayant on` · `/chatpayant off` : activer / désactiver.
- `/chatpayant prix 50` (étoiles) · `/chatpayant jours 30` (durée de l'accès) · `/chatpayant` (état).
- `/chatpayant donner 30` (en réponse à quelqu'un) offre un accès · `/chatpayant retirer` le retire · `/chatpayant liste`.
- Les autres voient un message avec un bouton ⭐ qui ouvre la facture ; après paiement l'accès est activé tout de suite et tu es prévenu. `/acces` montre l'accès restant. `/refundstar ID` rembourse et retire l'accès correspondant.

## 🛠️ Gestion (créateur uniquement)
Tout fonctionne avec des boutons, même en privé.
- `/utilisateurs` : liste de tous ceux qui utilisent le bot (pages ◀️ ▶️). `/utilisateurs lea` pour chercher. Appuie sur un nom : **profil complet** (messages, niveau, pièces, groupes en commun, accès payant…) avec bouton **🚫 Bloquer / ✅ Débloquer**. Aussi `/voiruser @pseudo | ID | nom` (ou en réponse à un message).
- `/groupes` : tous les groupes où est le bot. Appuie sur un groupe : fiche (membres, messages, dernière activité, bot admin ou non, plus actifs) avec bouton **🚪 Quitter ce groupe** (confirmation demandée). Aussi `/voirgroupe` et `/quitter <ID ou nom>`.
- `/bloquer`, `/debloquer` (en réponse, par ID ou @pseudo), `/bloques` (liste avec boutons pour débloquer). Un utilisateur bloqué est complètement ignoré (messages et boutons). Le créateur ne peut pas être bloqué.

## ⭐ Soutenir le créateur (étoiles Telegram)
`/soutenir` affiche des boutons (10, 25, 50, 100, 250, 500 ⭐) ou `/soutenir 75` pour un montant libre. Le paiement se fait dans Telegram, sans configuration. Le soutien est remercié, le propriétaire est prévenu, le donateur reçoit des pièces en cadeau. `/supporters` = classement, `/refundstar ID` = remboursement (propriétaire).

## Pourquoi il ne plante plus
Routeur unique, timeouts sur tous les appels réseau, nouvelles tentatives automatiques, messages Telegram renvoyés en texte brut si le formatage échoue, erreurs IA jamais enregistrées en mémoire (réponse de secours en personnage), pause automatique si le quota gratuit est atteint, sauvegarde atomique des données, reprise après coupure réseau ou conflit 409, anti-spam.

## IA gratuite : limites
OpenRouter gratuit ≈ 50 messages IA/jour sans crédit. Quand c'est atteint, Hina répond qu'elle recharge ses batteries (les commandes continuent). Pour plus : ajoute gratuitement `GROQ_API_KEY` (console.groq.com) ou `GEMINI_API_KEY` dans `.env` : le bot bascule automatiquement.

## Tests
`node test/run.mjs` lance 156 vérifications avec de faux serveurs Telegram/nekos.best/IA.
