# 𝐄𝐌𝐌𝐀𝐍𝐔𝐄𝐋 𝐏𝐑𝐈𝐌𝐄 𝐗 𝐁𝐎𝐓 — V2

Bot WhatsApp (Baileys) avec appairage via Telegram — 138 commandes.

## Nouveautés V2

- **Image du bot** : `assets/bot.jpg` accompagne le message de connexion et `assets/menu-thumb.jpg` s'affiche en haut du `.menu` (même message que la liste des commandes). La photo de profil WhatsApp n'est PAS modifiée.
- **Telegram : le bot ne répond plus dans les groupes** (il ne répond qu'en message privé). Sur WhatsApp, les commandes fonctionnent normalement, groupes compris (`RESPOND_IN_GROUPS=false` pour les couper si besoin).
- **Téléchargements réécrits** (`.song .video .ytmp3 .ytmp4 .tiktok .facebook .instagram .twitter .dl`) : yt-dlp (6 clients YouTube, version Python si le binaire ne se lance pas) → plusieurs API de secours par site. Le vrai type de fichier est détecté (une page d'erreur n'est plus envoyée comme vidéo) et les vidéos webm/mkv sont converties en MP4.
- La recherche YouTube a un secours via yt-dlp si `yt-search` est bloqué.
- **Corrections** : `GEMINI_API_KEY` était ignorée (clé jamais lue) ; la clé OpenRouter était collée à la place du nom de variable dans `config.js` (donc inutilisée) → utilise maintenant `OPENROUTER_API_KEY` ; `.tts` coupait mal les textes sans espaces ; `.tourl` a deux hébergeurs de secours ; `OWNER_NUMBER` configurable.
- Cookies YouTube : colle le contenu du fichier Netscape dans la variable `YT_COOKIES` (ou garde `data/cookies.txt`).

### Changements du 8 nov.
- Supprimées : `.time` (fusionnée dans `.date`, ex. `.date Paris`), `.bot` `.botreset` `.botmemory` `.autochat`, et les outils inutiles (`.b64 .unb64 .hash .uuid .morse .unmorse .binary .reverse .upper .lower .count`). Pour discuter avec l'IA : `.ai` (alias `.chatgpt` `.gemini` `.gpt` `.ask`).
- Ajoutées : `.kickall oui`, `.goodbye`, `.setwelcome`, `.setgoodbye` (variables `{user} {group} {count}`), `.autoreact on/off`.
- `.welcome` ne concerne plus que les arrivées ; les départs se gèrent avec `.goodbye`.
- Menu et infos du bot avec emojis. Jusqu'à **250 comptes** WhatsApp (`MAX_SESSIONS`), compte ~40 à 60 Mo de RAM par numéro connecté : prévois 6 à 10 Go de RAM pour 150 comptes.

### Telegram : accès verrouillé, owner, clés API
- **Obligation de rejoindre** tes groupes / chaînes Telegram avant d'utiliser le bot : mets leurs @noms dans la variable `REQUIRED_CHATS` (ex. `@ma_chaine,@mon_groupe`) ou dans `requiredChats` de `config.js`. **Ajoute le bot Telegram comme ADMIN** de chaque groupe / chaîne, sinon il ne peut pas vérifier. Le bouton « J'ai rejoint » revérifie.
- **Commandes réservées à toi** : mets ton ID Telegram dans `OWNER_TG_IDS` (envoie `/id` au bot pour le connaître). Elles : `/users /sessions /broadcast /kill /restart /ban /unban /banned /stats /setmax`.
- **Clés API** : fichier `api-keys.js` (GROK_API_KEY, OPENROUTER_API_KEY, GEMINI_API_KEY, OPENAI_API_KEY) ou variables du panel (prioritaires). Ordre utilisé : Grok → OpenRouter → Gemini → OpenAI → gratuit.
- **Fun** : actions animées via nekos.best (`.hug .kiss .pat .slap .cuddle .poke .bite .tickle .punch .wave .highfive .handhold .wink .bonk .yeet .shoot .feed .cry .dance .laugh .blush .smile .happy .sleep`), images `.neko .waifu .husbando .kitsune`, et `.pickup .emojimix .slot .iq .charisme`.

- **Bouton « Voir la chaîne »** sur le message de connexion, `.menu`, `.botinfo` et les messages de bienvenue / au revoir (bouton natif WhatsApp ; variable `BUTTONS=false` pour le remplacer par une carte cliquable si ton WhatsApp l'affiche mal). Le lien vient de `channel` dans `config.js`.

### Mise à jour du 8 nov. (soir)
- **Telegram** : `/menu`, `/start`, `/info` ne répondaient pas à cause d'un bouton au lien invalide : le bot renvoie maintenant toujours la réponse (sans bouton si besoin) et le pseudo owner est nettoyé automatiquement.
- **YouTube** : « Sign in to confirm you're not a bot » = YouTube bloque l'IP de l'hébergeur. Solution fiable : envoie ton fichier cookies.txt YouTube au bot Telegram (en tant que owner, ou après `/setcookies`) : il l'enregistre tout seul. `/testdl` teste chaque source de téléchargement et dit laquelle marche.
- **IA** : `.ai`, `.chatgpt`, `.gemini`, `.grok`, `.deepseek` (chacun utilise sa clé en priorité), avec plusieurs IA gratuites de secours. Pour une IA toujours fiable : clé Gemini gratuite sur aistudio.google.com → `GEMINI_API_KEY`.
- **Fun** : nekos.best renvoie 403 sur certains serveurs : secours waifu.pics, purrbot et otakugifs.
- **Nouveau** : `.vv2` (vue unique → chat du bot) et `.vv3` (vue unique → ton chat privé).

## Installation sur Pterodactyl

1. Crée un serveur avec l'egg **Node.js** (Node 20 ou 22 — Node 18 n'est plus accepté). RAM conseillée : 512 Mo minimum (1 Go si plusieurs numéros).
2. Envoie `emmanuel-prime-x-bot.zip` dans le gestionnaire de fichiers, puis **Unarchive**. Les fichiers (`index.js`, `package.json`...) doivent être à la racine.
3. Onglet **Startup** : `JS file` (ou `MAIN_FILE`) = `index.js`. Laisse l'installation automatique des paquets activée (le serveur lance `npm install`).
4. Clique **Start**. Au premier démarrage le bot télécharge `yt-dlp` tout seul (pour `.song`, `.video`, `.tiktok`...).
5. Sur Telegram, ouvre ton bot, envoie `/pair 242XXXXXXXXX` (numéro WhatsApp avec l'indicatif, sans `+`).
6. Tu reçois un code : WhatsApp › Appareils connectés › Connecter un appareil › **Connecter avec un numéro de téléphone** › saisis le code.
7. Sur WhatsApp, envoie `.menu`.


## Nouveau : le bot arrête tout seul les anciennes copies

Ce bot vérifie maintenant, à chaque démarrage, si une **autre** copie de lui-même tourne déjà sur le serveur
(même si ses fichiers ont été supprimés du disque entre-temps) et l'arrête automatiquement. Ça règle le cas,
très fréquent sur certains panels, où "Restart" ou "Reinstall" ne tue pas vraiment l'ancien processus : celui-ci
continuait de répondre sur WhatsApp/Telegram avec l'ancien code, ce qui donnait l'impression qu'aucun correctif
ne changeait quoi que ce soit.

**Pour vérifier que tu parles bien au bon processus :** compare le `PID` affiché dans la boîte "DEMARRAGE" de la
console juste après un démarrage avec le `PID` renvoyé par `/status` sur Telegram. S'ils sont différents, une
ancienne copie répond encore quelque part (le nouveau démarrage devrait l'avoir arrêtée automatiquement — si ce
n'est pas le cas, redémarre une deuxième fois, ou mieux, redémarre le **serveur entier** depuis le panel, pas
juste l'application).

## ⚠️ Problème « En attente de ce message » : à lire absolument

Ce message est un bug connu et non résolu de la librairie Baileys elle-même (utilisée par ce bot et par tous les bots WhatsApp en Node.js) :
plusieurs signalements identiques existent sur son dépôt officiel, certains ouverts cette semaine, sans solution garantie de leur côté à ce jour.
Ce bot inclut déjà toutes les corrections connues de la communauté (voir plus bas), mais je ne peux pas te promettre que ça règle 100% des cas tant que Baileys n'a pas corrigé le problème lui-même.

Cela dit, la cause la plus fréquente en pratique n'est PAS un bug : c'est **deux copies du bot qui tournent en même temps** sur le même numéro
(par exemple un ancien process resté actif sur le panel après un "Restart" mal fait, ou le bot lancé aussi sur un PC/Termux). Les deux copies écrivent
les clés de chiffrement en même temps et se marchent dessus, ce qui casse la conversation en boucle. Ce bot bloque maintenant ce cas automatiquement.

### Checklist à suivre DANS L'ORDRE, sans en sauter une seule

1. Sur le panel, clique **Stop** (pas Restart) et attends que le statut passe bien à "Offline". Vérifie qu'aucune autre copie du bot ne tourne ailleurs
   (autre serveur Pterodactyl, PC, Termux) avec ce même numéro.
2. Supprime les dossiers `node_modules` et `sessions`, ainsi que `package-lock.json` s'il existe, et le fichier `.bot.lock` s'il existe.
3. Envoie et décompresse (Unarchive) les fichiers de cette version.
4. Démarre le bot. **Regarde tout de suite la console** : elle doit afficher une boîte "DEMARRAGE" avec le numéro de version de Baileys et le PID.
   Si tu ne vois pas cette boîte, tu ne tournes pas avec cette version — recommence l'étape 3.
5. Sur WhatsApp (avec le numéro à connecter) : Appareils connectés › supprime l'ancien appareil lié au bot.
6. Sur Telegram : `/pair 242XXXXXXXXX`. Il faut vraiment repartir de zéro : garder d'anciennes clés de chiffrement abîmées reproduit le problème.
7. Teste `.ping` **depuis un autre numéro que celui du bot** (pas depuis le numéro du bot lui-même).

Si le bot refuse de démarrer en affichant « Une autre instance semble déjà tourner », c'est le signe n°1 ci-dessus : une ancienne copie est toujours active.

### Comment lire la console pour un diagnostic

- `📩 privé de ...` : un message privé est arrivé.
- `⇐ .menu (privé • numéro)` : une commande a été reconnue.
- `✔ 120 ms` : la commande a été traitée et une réponse envoyée.
- `[signal] nouvelle session de chiffrement créée (#N)` : normal une ou deux fois après un nouveau pairing ; anormal si ça revient à chaque message (indique des clés qui ne se conservent pas).
- `⚠️ Message ... non déchiffré` : le téléphone de la personne n'a pas réussi à chiffrer son message pour le bot ; WhatsApp doit le renvoyer automatiquement.

`LOG_LEVEL=debug` en variable du panel affiche tous les détails bruts de Baileys si besoin d'aller plus loin.

### Ça vient de se re-produire malgré tout : ce que ce nouveau correctif fait

Le journal `failed to decrypt message` / `No session record` pour un identifiant `@lid` avec `fromMe:true` correspond à un échec de synchronisation
entre le bot et **ton propre téléphone** (pas un contact), juste après l'appairage. Ce bot désactive maintenant la synchronisation de l'historique
(`shouldSyncHistoryMessage: false`), qui est la cause la plus documentée de ce type d'échec juste après un nouveau pairing. La console résume
maintenant ces erreurs en une ligne `[signal] N échec(s) de déchiffrement...` au lieu d'un pavé JSON illisible.

**Pour vérifier si le bot est réellement en ligne, ne te fie pas à "Dernière activité" dans Appareils connectés** (ce champ ne bouge que s'il y a du
trafic) : envoie plutôt `/mybots` à ton bot Telegram. `🟢 en ligne depuis ...` = le bot est bien connecté au niveau protocole. Si c'est `🟡` quelque
chose, la connexion n'est pas encore établie et le problème est ailleurs (regarde les toutes premières lignes de la console au démarrage).

Si tu vois encore `[signal] ... échec(s)` en continu après 2-3 minutes (et pas seulement juste après le pairing), c'est que le problème vient de
Baileys lui-même dans ce cas précis, comme expliqué plus haut — envoie-moi alors : une capture de `/mybots`, et le tout début de la console (les 10
premières lignes après le démarrage, avec la boîte "DEMARRAGE").

## Variables optionnelles (Startup > Variables, ou fichier `config.js`)

| Variable | Rôle |
|---|---|
| `TELEGRAM_TOKEN` | Token du bot Telegram (déjà renseigné par défaut) |
| `OPENROUTER_API_KEY` | Clé OpenRouter (optionnelle) |
| `YT_COOKIES` | Contenu du fichier cookies YouTube (format Netscape) |
| `RESPOND_IN_GROUPS` | `false` pour que le bot WhatsApp ignore les groupes (défaut : `true`) |
| `OWNER_NUMBER` | Numéro owner (défaut dans `config.js`) |
| `GEMINI_API_KEY` | **Recommandé** : clé gratuite (aistudio.google.com) pour que `.ai` soit rapide et stable |
| `OPENAI_API_KEY` | Alternative à Gemini |
| `PREFIX` | Préfixe des commandes (défaut `.`) |
| `MAX_SESSIONS` | Nombre max de numéros connectés (défaut 20) |
| `LOG_LEVEL` | Détail des logs Baileys : `error` (défaut), `warn`, `info`, `debug` |

Sans clé IA, `.ai` utilise un service gratuit public (Pollinations) qui peut être lent ou indisponible.

## Si `.song` est bloqué par YouTube

Le bot essaie dans l'ordre : yt-dlp (4 clients YouTube différents) → 3 API de secours.
Si YouTube bloque l'IP de ton hébergeur ("Sign in to confirm you're not a bot") :
- exporte tes cookies YouTube au format Netscape (extension « Get cookies.txt LOCALLY ») et mets le fichier dans `data/cookies.txt` : c'est la solution la plus fiable ;
- ou modifie la liste `ytAudioApis` / `ytVideoApis` dans `config.js`.

## Commandes Telegram

`/start` `/menu` `/pair` `/unpair` `/mybots` `/status` `/ping` `/info` `/owner` `/channel` `/youtube`
Owner : `/users` `/sessions` `/broadcast` `/kill`

## Sécurité

Le token Telegram est visible dans ta conversation : régénère-le dans @BotFather (`/revoke`) et mets le nouveau dans la variable `TELEGRAM_TOKEN`.
Ne partage jamais le dossier `sessions/` (il contient l'accès à tes comptes WhatsApp).
