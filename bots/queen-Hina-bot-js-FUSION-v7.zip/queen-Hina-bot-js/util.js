import crypto from 'node:crypto';

export const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

export const esc = (s) =>
  String(s ?? '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
export const unesc = (s) =>
  String(s ?? '').replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&quot;/g, '"').replace(/&amp;/g, '&');
export const stripTags = (s) => unesc(String(s ?? '').replace(/<[^>]*>/g, ''));

export function chunkText(text, max = 4000) {
  const s = String(text ?? '');
  if (s.length <= max) return [s];
  const out = [];
  let rest = s;
  while (rest.length > max) {
    let cut = rest.lastIndexOf('\n', max);
    if (cut < max * 0.5) cut = rest.lastIndexOf(' ', max);
    if (cut < max * 0.5) cut = max;
    out.push(rest.slice(0, cut));
    rest = rest.slice(cut).replace(/^\s+/, '');
  }
  if (rest) out.push(rest);
  return out;
}

export function randInt(min, max) {
  // inclusif des deux côtés, sans jamais lever d'exception
  min = Math.ceil(Number(min));
  max = Math.floor(Number(max));
  if (!Number.isFinite(min) || !Number.isFinite(max) || max < min) return Number.isFinite(min) ? min : 0;
  if (max === min) return min;
  if (max - min + 1 > 2 ** 40) return min + Math.floor(Math.random() * (max - min + 1));
  return crypto.randomInt(min, max + 1);
}
export const pick = (arr) => arr[randInt(0, arr.length - 1)];
export const shuffle = (arr) => {
  const a = [...arr];
  for (let i = a.length - 1; i > 0; i -= 1) {
    const j = randInt(0, i);
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
};

export const clamp = (n, lo, hi) => Math.min(hi, Math.max(lo, n));
export const fmtNum = (n) => Number(n).toLocaleString('fr-FR', { maximumFractionDigits: 6 });

export function fmtDuration(totalSec) {
  let s = Math.max(0, Math.floor(totalSec));
  const d = Math.floor(s / 86400); s -= d * 86400;
  const h = Math.floor(s / 3600); s -= h * 3600;
  const m = Math.floor(s / 60); s -= m * 60;
  const parts = [];
  if (d) parts.push(`${d}j`);
  if (h) parts.push(`${h}h`);
  if (m) parts.push(`${m}min`);
  if (s || parts.length === 0) parts.push(`${s}s`);
  return parts.join(' ');
}

// "10m", "2h30", "1j", "45s", "15" (= 15 minutes) -> secondes
export function parseDuration(str) {
  const t = String(str || '').toLowerCase().trim();
  if (!t) return null;
  if (/^\d+$/.test(t)) return parseInt(t, 10) * 60;
  const re = /(\d+)\s*(secondes?|sec|s|minutes?|min|m|heures?|h|jours?|j|d)(?![a-z])/g;
  let total = 0;
  let found = false;
  let m;
  let consumed = '';
  while ((m = re.exec(t))) {
    found = true;
    consumed += m[0];
    const n = parseInt(m[1], 10);
    const u = m[2][0];
    if (u === 's') total += n;
    else if (u === 'm') total += n * 60;
    else if (u === 'h') total += n * 3600;
    else total += n * 86400;
  }
  const trail = t.replace(re, '').trim();
  if (/^\d+$/.test(trail) && found) total += parseInt(trail, 10) * 60; // "2h30"
  return found ? total : null;
}

export const normalize = (s) =>
  String(s ?? '').toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '').replace(/[^a-z0-9]/g, '');
export const deaccent = (s) => String(s ?? '').normalize('NFD').replace(/[̀-ͯ]/g, '');

export const userName = (u) => (u && (u.first_name || u.username || u.name)) || 'toi';
export const mentionHtml = (u) => {
  if (!u) return 'quelqu’un';
  if (u.id && !u.is_bot_placeholder) return `<a href="tg://user?id=${u.id}">${esc(userName(u))}</a>`;
  return esc(userName(u));
};

export const truncate = (s, n) => {
  const t = String(s ?? '');
  return t.length > n ? `${t.slice(0, n - 1)}…` : t;
};

// ---- Calculatrice sûre (aucun eval) ----
export function calc(expr) {
  const s = String(expr)
    .toLowerCase()
    .replace(/×/g, '*').replace(/÷/g, '/').replace(/\*\*/g, '^').replace(/,/g, '.').replace(/\s+/g, '');
  if (!s || s.length > 200) throw new Error('expression invalide');
  let i = 0;
  const fns = {
    sqrt: Math.sqrt, abs: Math.abs, sin: Math.sin, cos: Math.cos, tan: Math.tan,
    log: Math.log10, ln: Math.log, exp: Math.exp, round: Math.round, floor: Math.floor, ceil: Math.ceil,
  };
  const consts = { pi: Math.PI, e: Math.E };
  function expr_() {
    let v = term();
    while (s[i] === '+' || s[i] === '-') {
      const op = s[i++];
      const r = term();
      v = op === '+' ? v + r : v - r;
    }
    return v;
  }
  function term() {
    let v = power();
    while (s[i] === '*' || s[i] === '/' || s[i] === '%') {
      const op = s[i++];
      const r = power();
      if (op === '*') v *= r;
      else if (op === '/') v /= r;
      else v %= r;
    }
    return v;
  }
  function power() {
    const base = unary();
    if (s[i] === '^') {
      i += 1;
      return base ** power();
    }
    return base;
  }
  function unary() {
    if (s[i] === '-') { i += 1; return -unary(); }
    if (s[i] === '+') { i += 1; return unary(); }
    return atom();
  }
  function atom() {
    if (s[i] === '(') {
      i += 1;
      const v = expr_();
      if (s[i] !== ')') throw new Error('parenthèse manquante');
      i += 1;
      return v;
    }
    const num = s.slice(i).match(/^\d+(\.\d+)?|^\.\d+/);
    if (num) { i += num[0].length; return parseFloat(num[0]); }
    const name = s.slice(i).match(/^[a-z]+/);
    if (name) {
      i += name[0].length;
      if (name[0] in consts) return consts[name[0]];
      if (name[0] in fns && s[i] === '(') {
        i += 1;
        const v = expr_();
        if (s[i] !== ')') throw new Error('parenthèse manquante');
        i += 1;
        return fns[name[0]](v);
      }
    }
    throw new Error('expression invalide');
  }
  const result = expr_();
  if (i !== s.length) throw new Error('expression invalide');
  if (!Number.isFinite(result)) throw new Error('résultat non défini');
  return result;
}

export function bar(percent, width = 10) {
  const p = clamp(Math.round(percent), 0, 100);
  const filled = Math.round((p / 100) * width);
  return '█'.repeat(filled) + '░'.repeat(width - filled);
}
