// Commandes ajoutées le 9 nov. : 11 groupe, 5 outils, 5 média
const U = require('../lib/utils')
const cfg = require('../config')
const Y = require('../lib/ytdl')

const A = { group: true, admin: true }
const AB = { group: true, admin: true, botAdmin: true }
const G = { group: true }
const use = (c, s) => c.reply(`ℹ️ Usage : ${c.prefix}${s}`)
const NEED = (c, w) => c.reply(`📎 ${w}`)
const ids = (meta) => meta.participants.map((p) => p.id)

// ---------- GROUPE ----------
const group = [
  {
    name: 'tagadmins', aliases: ['admintag', 'calladmins'], cat: 'group', ...G, desc: 'Mentionne tous les admins', usage: 'tagadmins besoin d\'aide',
    run: async (c) => {
      const admins = (await c.meta()).participants.filter((p) => p.admin)
      await c.sock.sendMessage(c.jid, { text: `🛡️ *APPEL AUX ADMINS*\n${c.text ? `\n💬 ${c.text}\n` : ''}\n${admins.map((p) => `• @${U.num(p.id)}`).join('\n')}\n\n${cfg.botName}`, mentions: admins.map((p) => p.id) }, { quoted: c.m })
    }
  },
  {
    name: 'members', aliases: ['membres', 'listmembers'], cat: 'group', ...G, desc: 'Nombre et liste des membres',
    run: async (c) => {
      const ps = (await c.meta()).participants
      const lines = ps.slice(0, 100).map((p, i) => `${i + 1}. @${U.num(p.id)}${p.admin ? ' 🛡️' : ''}`)
      await c.reply(`👥 *Membres : ${ps.length}* (dont ${ps.filter((p) => p.admin).length} admins)\n\n${lines.join('\n')}${ps.length > 100 ? `\n… et ${ps.length - 100} autres` : ''}`, { mentions: ps.slice(0, 100).map((p) => p.id) })
    }
  },
  {
    name: 'randommember', aliases: ['tirage', 'randomtag'], cat: 'group', ...G, desc: 'Tire un membre au hasard', usage: 'randommember',
    run: async (c) => {
      const p = U.pick((await c.meta()).participants)
      await c.reply(`🎲 Le sort a désigné : @${U.num(p.id)} 🎉`, { mentions: [p.id] })
    }
  },
  {
    name: 'setrules', cat: 'group', ...A, desc: 'Définit les règles du groupe', usage: 'setrules 1. Respect 2. Pas de spam',
    run: async (c) => {
      c.settings.rules = c.settings.rules || {}
      if (!c.text) return use(c, 'setrules <texte des règles>')
      if (/^(reset|off|delete)$/i.test(c.text)) delete c.settings.rules[c.jid]; else c.settings.rules[c.jid] = c.text.slice(0, 2000)
      c.saveSettings()
      await c.reply(/^(reset|off|delete)$/i.test(c.text) ? '🗑️ Règles supprimées.' : `✅ Règles enregistrées. Utilise ${c.prefix}rules pour les afficher.`)
    }
  },
  {
    name: 'rules', aliases: ['regles', 'règles'], cat: 'group', ...G, desc: 'Affiche les règles du groupe',
    run: async (c) => {
      const r = c.settings.rules?.[c.jid]
      await c.reply(r ? `📜 *Règles du groupe*\n\n${r}` : `📜 Aucune règle définie. Un admin peut utiliser ${c.prefix}setrules <texte>.`)
    }
  },
  {
    name: 'setgpp', aliases: ['setgroupicon', 'gicon'], cat: 'group', ...AB, desc: 'Change la photo du groupe', usage: 'setgpp (en répondant à une image)',
    run: async (c) => {
      const media = await c.getMedia()
      if (!media || media.kind !== 'image') return NEED(c, 'Envoie ou réponds à une image avec cette commande.')
      const img = await Y.ffmpeg(media.buffer, 'bin', ['-frames:v', '1', '-vf', "crop='min(iw,ih)':'min(iw,ih)',scale=640:640", '-q:v', '3'], 'jpg')
      try { await c.sock.updateProfilePicture(c.jid, img) } catch {
        await c.sock.query({ tag: 'iq', attrs: { target: c.jid, to: '@s.whatsapp.net', type: 'set', xmlns: 'w:profile:picture' }, content: [{ tag: 'picture', attrs: { type: 'image' }, content: img }] })
      }
      await c.reply('🖼️ Photo du groupe mise à jour.')
    }
  },
  {
    name: 'grouppp', aliases: ['gpp', 'groupicon'], cat: 'group', ...G, desc: 'Affiche la photo du groupe',
    run: async (c) => {
      let url
      try { url = await c.sock.profilePictureUrl(c.jid, 'image') } catch { return c.reply('❌ Ce groupe n\'a pas de photo.') }
      await c.image(url, '🖼️ Photo du groupe')
    }
  },
  {
    name: 'disappear', aliases: ['ephemeral', 'messagestemp'], cat: 'group', ...AB, desc: 'Messages éphémères : 24h / 7d / 90d / off', usage: 'disappear 7d',
    run: async (c) => {
      const map = { off: 0, '24h': 86400, '1d': 86400, '7d': 604800, '90d': 7776000 }
      const v = (c.args[0] || '').toLowerCase()
      if (!(v in map)) return use(c, 'disappear 24h | 7d | 90d | off')
      await c.sock.groupToggleEphemeral(c.jid, map[v])
      await c.reply(v === 'off' ? '⏳ Messages éphémères désactivés.' : `⏳ Messages éphémères activés (${v}).`)
    }
  },
  {
    name: 'lockinfo', aliases: ['editinfo'], cat: 'group', ...AB, desc: 'Seuls les admins modifient les infos du groupe', usage: 'lockinfo on',
    run: async (c) => {
      const v = U.onoff(c.args[0])
      if (v === null) return use(c, 'lockinfo on/off')
      await c.sock.groupSettingUpdate(c.jid, v ? 'locked' : 'unlocked')
      await c.reply(v ? '🔐 Seuls les admins peuvent modifier les infos du groupe.' : '🔓 Tous les membres peuvent modifier les infos du groupe.')
    }
  },
  {
    name: 'warnlist', aliases: ['warns', 'avertissements'], cat: 'group', ...G, desc: 'Liste des avertissements du groupe',
    run: async (c) => {
      const w = Object.entries(c.settings.warns?.[c.jid] || {}).filter(([, n]) => n > 0)
      if (!w.length) return c.reply('✅ Aucun avertissement dans ce groupe.')
      await c.reply(`⚠️ *Avertissements*\n\n${w.map(([n, k]) => `• @${n} : ${k}/3`).join('\n')}`, { mentions: w.map(([n]) => n + '@s.whatsapp.net') })
    }
  }
]

// ---------- OUTILS ----------
const dur = { s: 1, m: 60, h: 3600, d: 86400 }
const tools = [
  {
    name: 'remind', aliases: ['rappel', 'reminder'], cat: 'tools', desc: 'Te rappelle quelque chose (10s, 5m, 2h, max 24h)', usage: 'remind 30m appeler maman',
    run: async (c) => {
      const m = (c.args[0] || '').match(/^(\d+)(s|m|h|d)$/i)
      const what = c.args.slice(1).join(' ')
      if (!m || !what) return use(c, 'remind 30m <message>   (s = secondes, m = minutes, h = heures)')
      const secs = Number(m[1]) * dur[m[2].toLowerCase()]
      if (secs < 5 || secs > 86400) return c.reply('⏰ Choisis une durée entre 5 secondes et 24 heures.')
      const { sock, jid, sender } = c
      setTimeout(() => sock.sendMessage(jid, { text: `⏰ *Rappel* pour @${U.num(sender)} :\n${what}`, mentions: [sender] }).catch(() => {}), secs * 1000)
      await c.reply(`✅ Je te rappellerai dans *${m[1]}${m[2].toLowerCase()}* : ${what}\n\n_(si le bot redémarre avant, le rappel est perdu)_`)
    }
  },
  {
    name: 'choose', aliases: ['choisir', 'pick'], cat: 'tools', desc: 'Choisit pour toi entre plusieurs options', usage: 'choose pizza | burger | tacos',
    run: async (c) => {
      const opts = c.text.split(/\s*(?:\||,|;|\bou\b)\s*/i).map((x) => x.trim()).filter(Boolean)
      if (opts.length < 2) return use(c, 'choose option1 | option2 | option3')
      await c.reply(`🤔 Je choisis : *${U.pick(opts)}*`)
    }
  },
  {
    name: 'age', aliases: ['anniversaire'], cat: 'tools', desc: 'Calcule un âge depuis une date de naissance', usage: 'age 25/12/2000',
    run: async (c) => {
      const m = (c.args[0] || '').match(/^(\d{1,2})[\/.-](\d{1,2})[\/.-](\d{4})$/)
      if (!m) return use(c, 'age JJ/MM/AAAA')
      const [d, mo, y] = [Number(m[1]), Number(m[2]), Number(m[3])]
      const b = new Date(y, mo - 1, d), now = new Date()
      if (b.getFullYear() !== y || b.getMonth() !== mo - 1 || b > now) return c.reply('❌ Date invalide.')
      let years = now.getFullYear() - y, months = now.getMonth() - (mo - 1), days = now.getDate() - d
      if (days < 0) { months--; days += new Date(now.getFullYear(), now.getMonth(), 0).getDate() }
      if (months < 0) { years--; months += 12 }
      const next = new Date(now.getFullYear(), mo - 1, d); if (next < now) next.setFullYear(now.getFullYear() + 1)
      await c.reply(`🎂 *${years} ans, ${months} mois, ${days} jours*\n📅 Prochain anniversaire dans ${Math.ceil((next - now) / 86400000)} jour(s)`)
    }
  },
  {
    name: 'imc', aliases: ['bmi'], cat: 'tools', desc: "Calcule l'indice de masse corporelle", usage: 'imc 70 175   (kg, cm)',
    run: async (c) => {
      const kg = parseFloat((c.args[0] || '').replace(',', '.')); let h = parseFloat((c.args[1] || '').replace(',', '.'))
      if (!(kg > 0) || !(h > 0)) return use(c, 'imc <poids en kg> <taille en cm>')
      if (h > 3) h /= 100
      const v = kg / (h * h)
      const cat = v < 18.5 ? 'Insuffisance pondérale' : v < 25 ? 'Corpulence normale ✅' : v < 30 ? 'Surpoids' : 'Obésité'
      await c.reply(`⚖️ *IMC : ${v.toFixed(1)}*\n${cat}\n\n_Indication générale, pas un avis médical._`)
    }
  },
  {
    name: 'checkwa', aliases: ['onwhatsapp', 'wacheck'], cat: 'tools', desc: 'Vérifie si des numéros sont sur WhatsApp', usage: 'checkwa 242061234567 33612345678',
    run: async (c) => {
      const nums = c.args.map((a) => a.replace(/\D/g, '')).filter((n) => n.length >= 8).slice(0, 10)
      if (!nums.length) return use(c, 'checkwa <numéro avec indicatif> [autres numéros]')
      const res = await c.sock.onWhatsApp(...nums.map((n) => n + '@s.whatsapp.net'))
      const ok = new Map((res || []).map((r) => [U.num(r.jid), r.exists]))
      await c.reply(`🔎 *Vérification WhatsApp*\n\n${nums.map((n) => `${ok.get(n) ? '✅' : '❌'} +${n}`).join('\n')}`)
    }
  }
]

// ---------- MÉDIA (ffmpeg) ----------
const audioFx = (name, aliases, desc, filter) => ({
  name, aliases, cat: 'media', desc, usage: `${name} (en répondant à un audio ou une vidéo)`,
  run: async (c) => {
    const media = await c.getMedia()
    if (!media || !['audio', 'video'].includes(media.kind)) return NEED(c, 'Réponds à un audio / vocal / vidéo avec cette commande.')
    await c.react('🎧')
    const out = await Y.ffmpeg(media.buffer, 'bin', ['-vn', '-af', filter, '-b:a', '128k'], 'mp3')
    await c.audio(out, 'audio/mpeg', name)
  }
})
const imageFx = (name, aliases, desc, vf) => ({
  name, aliases, cat: 'media', desc, usage: `${name} (en répondant à une image)`,
  run: async (c) => {
    const media = await c.getMedia()
    if (!media || !['image', 'sticker'].includes(media.kind)) return NEED(c, 'Envoie ou réponds à une image avec cette commande.')
    const out = await Y.ffmpeg(media.buffer, 'bin', ['-frames:v', '1', '-vf', vf, '-q:v', '3'], 'jpg')
    await c.image(out, `✨ ${name}`)
  }
})
const media = [
  audioFx('bass', ['basse', 'bassboost'], 'Booste les basses d\'un audio', 'bass=g=18,volume=1.4'),
  audioFx('nightcore', ['fast'], 'Audio accéléré façon nightcore', 'asetrate=44100*1.25,aresample=44100'),
  imageFx('blur', ['flou'], 'Rend une image floue', 'gblur=sigma=14'),
  imageFx('grayscale', ['gris', 'bw'], 'Image en noir et blanc', 'hue=s=0'),
  imageFx('rotate', ['tourner'], 'Tourne une image de 90°', 'transpose=1')
]

module.exports = [...group, ...tools, ...media]
