import chalk from "chalk";

function getTimeStamp() {
  return new Date().toLocaleTimeString("fr-FR", {
    hour12: false,
  });
}

function badge(label, color) {
  return color.bold(`[${label}]`);
}

function print(label, color, message) {
  console.log(`\n${chalk.gray(getTimeStamp())} ${badge(label, color)} ${message}`);
}

export const log = {
  info: (message) => print("INFO", chalk.cyan, message),
  success: (message) => print("SUCCÈS", chalk.green, message),
  warning: (message) => print("ATTENTION", chalk.yellow, message),
  error: (message) => print("ERREUR", chalk.red, message),
  loading: (message) => print("TRAITEMENT", chalk.blue, message),
  whatsapp: (message) => print("WHATSAPP", chalk.greenBright, message),
};
