// Chat payant : le créateur peut réserver la discussion avec Hina aux personnes qui ont payé en étoiles Telegram (⭐).
// Les commandes (/menu, jeux, boutique…) restent gratuites ; seule la conversation libre avec l'IA est verrouillée.
import { OWNER_NAME, BOT_NAME, isOwner } from '../config.js';
import * as store from '../store.js';
import { esc, fmtNum, fmtDuration, mentionHtml, clamp } from '../util.js';

const DAY = 86400000;
export const cfg = () => {
  const p = store.db.premium && typeof store.db.premium === 'object' ? store.db.premium : (store.db.premium = {});
  p.enabled ??= false; p.price ??= 50; p.days ??= 30; p.users ??= {};
  return p;
};
export const accessUntil = (userId) => cfg().users[String(userId)] || 0;
export const hasAccess = (userId) => isOwner(userId) || !cfg().enabled || accessUntil(userId) > Date.now();
/** true si cette personne doit payer avant de pouvoir discuter avec Hina. */
export const chatLocked = (userId) => !hasAccess(userId);

export function grantAccess(userId, days) {
  const p = cfg(); const k = String(userId);
  p.users[k] = Math.max(p.users[k] || 0, Date.now()) + days * DAY;
  store.save();
  return p.users[k];
}
export function revokeAccess(userId, days) {
  const p = cfg(); const k = String(userId);
  if (days === undefined) delete p.users[k]; else p.users[k] = (p.users[k] || 0) - days * DAY;
  if ((p.users[k] || 0) <= Date.now()) delete p.users[k];
  store.save();
}

export function sendAccessInvoice(tg, chatId, userId, thread) {
  const p = cfg();
  return tg.call('sendInvoice', {
    chat_id: chatId,
    title: `Discuter avec ${BOT_NAME}`.slice(0, 32),
    description: `Accès à ${BOT_NAME} (chat + commandes IA) pendant ${p.days} jour${p.days > 1 ? 's' : ''} (${p.price} ⭐).`,
    payload: `access:${userId}:${p.price}:${p.days}`,
    currency: 'XTR',
    prices: [{ label: `Chat ${p.days} j`, amount: p.price }],
    ...(thread ? { message_thread_id: thread } : {}),
  }, { retries: 2, timeout: 15000 });
}

export async function handleAccessCallback(tg, cq) {
  await tg.call('answerCallbackQuery', { callback_query_id: cq.id }, { retries: 1, timeout: 8000 }).catch(() => {});
  const msg = cq.message; if (!msg) return;
  if (!cfg().enabled) return tg.sendMessage(msg.chat.id, 'Le chat est gratuit pour le moment, profites-en ! 💬').catch(() => {});
  try {
    await sendAccessInvoice(tg, msg.chat.id, cq.from.id, msg.is_topic_message ? msg.message_thread_id : undefined);
  } catch (e) {
    console.warn('[access] invoice:', e.message);
    await tg.sendMessage(msg.chat.id, 'Je n’arrive pas à créer la facture pour le moment 🙏 Réessaie dans un instant.').catch(() => {});
  }
}

const buyKb = () => ({ inline_keyboard: [[{ text: `⭐ Débloquer ${cfg().days} j (${cfg().price} ⭐)`, callback_data: 'a:buy' }]] });
const nagged = new Map();
/** Message envoyé à quelqu'un qui n'a pas accès (au plus une fois par minute et par personne). */
export async function lockedReply(ctx, { always = false } = {}) {
  const now = Date.now();
  if (!always && now - (nagged.get(ctx.from.id) || 0) < 60000) return;
  nagged.set(ctx.from.id, now);
  if (nagged.size > 2000) nagged.clear();
  const p = cfg();
  await ctx.reply(`🔒 <b>L’IA de ${esc(BOT_NAME)} est réservée</b> (discussion libre et commandes /ia, /poeme, /resume…)\nPour en profiter, débloque l’accès pour <b>${p.days} jour${p.days > 1 ? 's' : ''}</b> avec <b>${p.price} ⭐</b> étoiles Telegram, offertes à ${esc(OWNER_NAME)} 💖\n\nMes autres commandes (/menu, jeux, boutique…) restent gratuites !`, { reply_markup: buyKb() });
}

const when = (ts) => fmtDuration(Math.max(0, ts - Date.now()) / 1000);
export const defs = [
  {
    name: 'acces', aliases: ['premium', 'abonnement', 'passchat'], cat: '⭐ Soutien', desc: 'ton accès au chat avec Hina', cooldown: 3000,
    async run(ctx) {
      const p = cfg();
      if (ctx.isOwner) return ctx.reply('👑 Créateur : tu as toujours accès à tout.');
      if (!p.enabled) return ctx.reply('💬 Le chat avec moi est <b>gratuit</b> pour le moment, profites-en !');
      const until = accessUntil(ctx.from.id);
      if (until > Date.now()) return ctx.reply(`✅ Ton accès au chat est actif encore <b>${when(until)}</b>.\nTu peux le prolonger de ${p.days} j avec le bouton ci-dessous.`, { reply_markup: buyKb() });
      return ctx.reply(`🔒 Tu n’as pas (ou plus) accès au chat.\nAccès de <b>${p.days} jour${p.days > 1 ? 's' : ''}</b> pour <b>${p.price} ⭐</b> :`, { reply_markup: buyKb() });
    },
  },
  {
    name: 'chatpayant', aliases: ['paywall', 'chatpremium', 'chatpay'], cat: '👑 Propriétaire', owner: true, desc: '(owner) chat payant : on/off, prix, durée, donner, retirer',
    run(ctx) {
      const p = cfg(); const a = (ctx.argv[0] || 'statut').toLowerCase(); const n = parseInt(ctx.argv[1], 10);
      if (['on', 'activer', 'oui'].includes(a)) { p.enabled = true; store.save(); return ctx.reply(`🔒 <b>Chat payant ACTIVÉ</b>\nLe chat avec moi <b>et les commandes IA</b> (/ia, /poeme, /resume…) sont réservés à ceux qui paient <b>${p.price} ⭐</b> pour ${p.days} j. Toi, tu as tout gratuitement.`); }
      if (['off', 'desactiver', 'non'].includes(a)) { p.enabled = false; store.save(); return ctx.reply('🔓 <b>Chat payant DÉSACTIVÉ</b> : tout le monde peut discuter avec moi et utiliser les commandes IA gratuitement.'); }
      if (['prix', 'price'].includes(a)) {
        if (!Number.isFinite(n) || n < 1 || n > 10000) return ctx.reply('Usage : /chatpayant prix 50 (de 1 à 10 000 ⭐)');
        p.price = n; store.save(); return ctx.reply(`💰 Prix du chat : <b>${n} ⭐</b> pour ${p.days} j.`);
      }
      if (['jours', 'duree', 'days'].includes(a)) {
        if (!Number.isFinite(n) || n < 1 || n > 365) return ctx.reply('Usage : /chatpayant jours 30 (de 1 à 365)');
        p.days = clamp(n, 1, 365); store.save(); return ctx.reply(`⏳ Durée de l’accès : <b>${p.days} jour(s)</b> pour ${p.price} ⭐.`);
      }
      if (['donner', 'give', 'offrir'].includes(a)) {
        if (!ctx.target) return ctx.reply('Réponds au message de la personne : /chatpayant donner 30');
        const d = Number.isFinite(n) ? clamp(n, 1, 365) : p.days;
        const until = grantAccess(ctx.target.id, d);
        return ctx.reply(`🎁 ${mentionHtml(ctx.target)} a maintenant accès au chat pendant encore <b>${when(until)}</b>.`);
      }
      if (['retirer', 'revoke', 'ban'].includes(a)) {
        if (!ctx.target) return ctx.reply('Réponds au message de la personne : /chatpayant retirer');
        revokeAccess(ctx.target.id); return ctx.reply(`🚫 Accès retiré à ${mentionHtml(ctx.target)}.`);
      }
      if (['liste', 'list'].includes(a)) {
        const rows = Object.entries(p.users).filter(([, t]) => t > Date.now()).sort((x, y) => y[1] - x[1]).slice(0, 20);
        if (!rows.length) return ctx.reply('Personne n’a d’accès actif pour le moment.');
        return ctx.reply(`👥 <b>Accès actifs</b> (${rows.length})\n${rows.map(([id, t]) => `• ${esc(store.db.users[id]?.name || id)} — encore ${when(t)}`).join('\n')}`);
      }
      const active = Object.values(p.users).filter((t) => t > Date.now()).length;
      return ctx.reply(`${p.enabled ? '🔒 Chat payant : <b>ACTIVÉ</b>' : '🔓 Chat payant : <b>désactivé</b>'}\n💰 Prix : ${fmtNum(p.price)} ⭐ · ⏳ Durée : ${p.days} j · 👥 Accès actifs : ${active}\n\n<b>Commandes</b>\n/chatpayant on · off\n/chatpayant prix 50\n/chatpayant jours 30\n/chatpayant donner 30 (en réponse)\n/chatpayant retirer (en réponse)\n/chatpayant liste`);
    },
  },
];
export default defs;
