// Couche IA robuste : plusieurs fournisseurs, sélection automatique de BONS modèles gratuits, timeouts, retries,
// rejet des réponses absurdes (ex : modèles "guard" qui répondent "User Safety: safe"), pause en cas de quota.
// Une erreur IA n'est JAMAIS enregistrée dans l'historique et ne fait jamais planter le bot.
import { AI, SYSTEM_PROMPT, BOT_NAME } from './config.js';
import * as store from './store.js';
import { pick, sleep } from './util.js';

const FALLBACKS = [
  'Mmh, j’ai la tête ailleurs une seconde… redemande-moi dans un petit moment ? 💫',
  'Oups, mon cerveau a buggé un instant 😅 Réessaie dans quelques secondes !',
  'Attends, je reprends mes esprits… renvoie-moi ton message dans un instant ✨',
];
const QUOTA_FALLBACK =
  'J’ai énormément discuté aujourd’hui, je recharge mes batteries ✨ Je reviens très vite ! En attendant, mes commandes marchent toujours : tape /menu 😉';
export const fallbackReply = (quota = false) => (quota ? QUOTA_FALLBACK : pick(FALLBACKS));

const provState = new Map();   // fournisseur -> {until, lastError, quota}
const modelState = new Map();  // "fournisseur|modèle" -> {until, why}
const pst = (n) => { if (!provState.has(n)) provState.set(n, { until: 0, lastError: null, quota: false }); return provState.get(n); };
const mkey = (p, m) => `${p}|${m}`;
const modelOk = (p, m) => (modelState.get(mkey(p, m))?.until || 0) <= Date.now();
const benchModel = (p, m, ms, why) => modelState.set(mkey(p, m), { until: Date.now() + ms, why });

// ---------- modèles OpenRouter gratuits (découverte automatique) ----------
const AVOID = /guard|safety|moderat|embed|image|vision|whisper|tts|audio|lyria|ocr|rerank|classif|reward|sora|veo|flux|diffusion/i;
const PREFER = [/llama-3\.3/i, /llama-4/i, /gpt-oss/i, /gemma-3/i, /mistral/i, /qwen/i, /deepseek/i, /glm/i, /kimi/i, /nemotron/i, /hermes/i, /llama/i];
let modelCache = { at: 0, list: [], failedAt: 0 };

async function openrouterModels(p) {
  if (!(p.models.length === 1 && p.models[0] === 'openrouter/free')) return p.models; // liste choisie par l'utilisateur
  const now = Date.now();
  if (modelCache.list.length && now - modelCache.at < 60 * 60 * 1000) return modelCache.list;
  if (now - modelCache.failedAt > 5 * 60 * 1000 || !modelCache.list.length) {
    try {
      const res = await fetch(`${AI.openrouterBase}/models`, { signal: AbortSignal.timeout(8000), headers: { accept: 'application/json' } });
      if (res.ok) {
        const data = (await res.json())?.data || [];
        const free = data.filter((m) => {
          const id = String(m.id || '');
          const zero = Number(m.pricing?.prompt) === 0 && Number(m.pricing?.completion) === 0;
          const textOut = !m.architecture?.output_modalities || m.architecture.output_modalities.includes('text');
          return (id.endsWith(':free') || zero) && textOut && !AVOID.test(id) && !AVOID.test(m.name || '') && (m.context_length || 0) >= 8000 && id !== 'openrouter/free';
        });
        const rank = (m) => { const i = PREFER.findIndex((r) => r.test(m.id)); return (i === -1 ? 50 : i) - Math.min((m.context_length || 0) / 1e6, 0.9); };
        const list = free.sort((a, b) => rank(a) - rank(b)).slice(0, 8).map((m) => m.id);
        if (list.length) { modelCache = { at: now, list: [...list, 'openrouter/free'], failedAt: 0 }; return modelCache.list; }
      }
    } catch { /* on retombe sur le routeur */ }
    modelCache.failedAt = now;
  }
  return modelCache.list.length ? modelCache.list : ['openrouter/free'];
}

function providers() {
  const list = [];
  if (AI.customBase) list.push({ name: 'custom', url: `${AI.customBase.replace(/\/+$/, '')}/chat/completions`, key: AI.customKey, models: [AI.customModel] });
  if (AI.openrouterKey) list.push({ name: 'openrouter', url: `${AI.openrouterBase}/chat/completions`, key: AI.openrouterKey, models: AI.openrouterModels, dynamic: true, extra: { 'HTTP-Referer': 'https://t.me/emmanuelprimex', 'X-Title': BOT_NAME } });
  if (AI.groqKey) list.push({ name: 'groq', url: 'https://api.groq.com/openai/v1/chat/completions', key: AI.groqKey, models: [AI.groqModel] });
  if (AI.geminiKey) list.push({ name: 'gemini', url: 'https://generativelanguage.googleapis.com/v1beta/openai/chat/completions', key: AI.geminiKey, models: [AI.geminiModel] });
  return list;
}
export const hasProvider = () => providers().length > 0;

export function status() {
  return providers().map((p) => {
    const s = pst(p.name);
    const wait = Math.max(0, Math.ceil((s.until - Date.now()) / 1000));
    const benched = [...modelState.entries()].filter(([k, v]) => k.startsWith(`${p.name}|`) && v.until > Date.now()).length;
    return { name: p.name, models: p.dynamic && modelCache.list.length ? `${modelCache.list.length} modèles gratuits (${modelCache.list[0]}…)` : p.models.join(', '), available: wait === 0, waitSec: wait, lastError: s.lastError, quota: s.quota, benched };
  });
}

// ---------- nettoyage / validation ----------
function clean(text) {
  return String(text || '')
    .replace(/<think>[\s\S]*?<\/think>/gi, '')
    .replace(/<\|[^|>]*\|>/g, '')
    .replace(/\*\*(.+?)\*\*/g, '$1')
    .replace(/^#{1,6}\s+/gm, '')
    .trim();
}
// Réponses qui ne sont pas du texte de conversation (modèles de modération, jetons de contrôle, etc.)
const BAD_OUTPUT = /^\s*(?:user\s+safety|assistant\s+safety|safety\s*(?:assessment|category|:)|\[?(?:un)?safe\]?\s*$|\s*(?:safe|unsafe)\s*(?:\n|$)|<\/?s>|\[INST\])/i;
function sane(text) {
  if (!text || text.length < 2) return false;
  if (BAD_OUTPUT.test(text)) return false;
  if (/^(?:safe|unsafe)\b[\s\S]{0,40}$/i.test(text)) return false;
  return true;
}

async function callOnce(p, model, messages, { maxTokens, temperature, timeout }) {
  const res = await fetch(p.url, {
    method: 'POST',
    headers: { 'content-type': 'application/json', ...(p.key ? { authorization: `Bearer ${p.key}` } : {}), ...(p.extra || {}) },
    body: JSON.stringify({ model, messages, max_tokens: maxTokens, temperature }),
    signal: AbortSignal.timeout(timeout),
  });
  const raw = await res.text();
  let data = null;
  try { data = JSON.parse(raw); } catch { /* ignore */ }
  if (!res.ok) {
    const err = new Error(data?.error?.message || `HTTP ${res.status}`);
    err.status = res.status; err.body = raw.slice(0, 400);
    err.retryAfter = parseInt(res.headers.get('retry-after') || '', 10) || 0;
    throw err;
  }
  const text = clean(data?.choices?.[0]?.message?.content);
  if (!sane(text)) { const err = new Error(text ? 'réponse inutilisable' : 'réponse vide'); err.status = 204; err.bad = true; throw err; }
  return text;
}

/** @returns {Promise<{text:string, provider:string, model:string}|{error:'quota'|'down'}>} */
export async function chat(messages, { maxTokens = 500, temperature = 0.85 } = {}) {
  const list = providers();
  if (list.length === 0) return { error: 'down', reason: 'aucune clé IA configurée' };
  const deadline = Date.now() + 50000;
  let quota = false;
  for (const p of list) {
    const s = pst(p.name);
    if (Date.now() < s.until) { quota = quota || s.quota; continue; }
    const models = p.dynamic ? await openrouterModels(p) : p.models;
    let tried = 0;
    for (const model of models) {
      if (!modelOk(p.name, model)) continue;
      const remaining = deadline - Date.now();
      if (remaining < 4000 || tried >= 5) break;
      tried += 1;
      let stop = false;
      for (let attempt = 0; attempt < (p.dynamic ? 1 : 2) && !stop; attempt += 1) {
        const left = deadline - Date.now();
        if (left < 4000) break;
        try {
          const text = await callOnce(p, model, messages, { maxTokens, temperature, timeout: Math.min(AI.timeoutMs, p.dynamic ? 22000 : AI.timeoutMs, left) });
          s.lastError = null; s.quota = false; s.fails = 0;
          return { text: text.slice(0, 3800), provider: p.name, model };
        } catch (e) {
          const status = e.status || 0;
          s.lastError = `${model}: ${status || 'réseau'} ${String(e.message).slice(0, 100)}`;
          if (status === 429) {
            const daily = /per-day|per day|daily|free-models-per-day|exhausted|quota/i.test(`${e.message} ${e.body}`);
            if (daily) { s.quota = true; s.until = Date.now() + 30 * 60 * 1000; quota = true; stop = true; break; }
            if (p.dynamic) benchModel(p.name, model, Math.max(60, e.retryAfter || 90) * 1000, '429');
            else s.until = Date.now() + Math.max(20, Math.min(e.retryAfter || 45, 120)) * 1000;
            break;
          }
          if (status === 401 || status === 402 || status === 403) { s.until = Date.now() + 30 * 60 * 1000; stop = true; break; }
          if (status === 404 || status === 400) { if (p.dynamic) benchModel(p.name, model, 60 * 60 * 1000, String(status)); else s.until = Date.now() + 60 * 1000; break; }
          if (e.bad) { if (p.dynamic) { benchModel(p.name, model, 30 * 60 * 1000, 'sortie inutilisable'); break; } await sleep(300); continue; }
          // erreur passagère (5xx, délai, réseau)
          s.fails = (s.fails || 0) + 1;
          if (p.dynamic) { benchModel(p.name, model, 3 * 60 * 1000, String(status || 'réseau')); break; }
          if (s.fails >= 4) { s.until = Date.now() + 60 * 1000; stop = true; break; }
          await sleep(600);
        }
      }
      if (stop) break;
    }
  }
  return { error: quota ? 'quota' : 'down' };
}

export async function converse(chatId, userText, { userName = '', group = false, extraSystem = '' } = {}) {
  const system = [SYSTEM_PROMPT, userName ? `Tu parles avec ${userName}.` : '', group ? 'Tu es dans un groupe : sois brève (1 à 3 phrases).' : '', extraSystem].filter(Boolean).join('\n');
  const history = store.getHistory(chatId).slice(-12);
  // En groupe, on préfixe par le prénom pour que Hina distingue qui parle dans l'historique partagé.
  const tagged = group && userName ? `${userName} : ${userText}` : userText;
  const r = await chat([{ role: 'system', content: system }, ...history, { role: 'user', content: tagged.slice(0, 2000) }]);
  if (r.text) { store.pushHistory(chatId, 'user', tagged); store.pushHistory(chatId, 'assistant', r.text); }
  return r;
}

export async function task(instruction, input, opts = {}) {
  return chat([
    { role: 'system', content: `${instruction}\nRéponds uniquement avec le résultat, en texte simple sans Markdown.` },
    { role: 'user', content: String(input).slice(0, 4000) },
  ], { temperature: 0.5, maxTokens: 700, ...opts });
}
