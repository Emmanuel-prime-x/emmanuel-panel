// Réactions animées nekos.best : .kiss .hug .pat ... (préfixes / . !) + images anime.
import { NEKOS_API, BOT_NAME } from '../config.js';
import { getJson } from '../http.js';
import { esc, mentionHtml, userName } from '../util.js';

// type: duo = dirigée vers quelqu'un | solo = action seule
const R = {
  hug:       ['duo', '🤗', '{a} fait un gros câlin à {b}', ['calin']],
  kiss:      ['duo', '💋', '{a} embrasse {b}', ['bisou', 'embrasse']],
  pat:       ['duo', '🫶', '{a} caresse la tête de {b}', ['caresse']],
  cuddle:    ['duo', '🥰', '{a} se blottit contre {b}', ['blottir']],
  slap:      ['duo', '✋', '{a} met une gifle à {b}', ['gifle']],
  punch:     ['duo', '👊', '{a} met un coup de poing à {b}', ['poing']],
  kick:      ['duo', '🦶', '{a} met un coup de pied à {b}', ['coup']],
  bite:      ['duo', '😬', '{a} mord {b}', ['mord']],
  poke:      ['duo', '👉', '{a} titille {b}', ['titille']],
  tickle:    ['duo', '🤭', '{a} chatouille {b}', ['chatouille']],
  feed:      ['duo', '🍙', '{a} donne à manger à {b}', ['nourrir']],
  handhold:  ['duo', '🤝', '{a} prend la main de {b}', ['main']],
  handshake: ['duo', '🤝', '{a} serre la main de {b}', ['serrer']],
  highfive:  ['duo', '🙏', '{a} tape dans la main de {b}', ['checkin']],
  peck:      ['duo', '😘', '{a} fait un petit bisou à {b}', ['smack']],
  shoot:     ['duo', '🔫', '{a} tire sur {b} (c’est pour rire !)', ['pan']],
  yeet:      ['duo', '🚀', '{a} envoie {b} dans les airs', ['jeter']],
  baka:      ['duo', '💢', '{a} traite {b} de baka !', []],
  wave:      ['duo', '👋', '{a} fait coucou à {b}', ['coucou']],
  wink:      ['duo', '😉', '{a} fait un clin d’œil à {b}', ['clin']],
  nom:       ['duo', '😋', '{a} grignote {b}', ['grignote']],
  stare:     ['duo', '👀', '{a} fixe {b}', ['fixe']],
  thumbsup:  ['duo', '👍', '{a} approuve {b}', ['pouce']],
  nod:       ['duo', '🙂', '{a} acquiesce devant {b}', ['hocher']],
  blush:     ['solo', '😊', '{a} rougit', ['rougir']],
  cry:       ['solo', '😭', '{a} pleure', ['pleurer']],
  dance:     ['solo', '💃', '{a} danse', ['danser']],
  laugh:     ['solo', '😂', '{a} éclate de rire', ['rire']],
  smile:     ['solo', '😄', '{a} sourit', ['sourire']],
  smug:      ['solo', '😏', '{a} fait son malin', []],
  happy:     ['solo', '🥳', '{a} est super content(e)', ['content']],
  pout:      ['solo', '😤', '{a} fait la moue', ['moue']],
  sleep:     ['solo', '😴', '{a} s’endort', ['dormir']],
  yawn:      ['solo', '🥱', '{a} bâille', ['bailler']],
  bored:     ['solo', '😑', '{a} s’ennuie', ['ennui']],
  facepalm:  ['solo', '🤦', '{a} se prend la tête dans les mains', []],
  think:     ['solo', '🤔', '{a} réfléchit', ['penser']],
  nope:      ['solo', '🙅', '{a} dit non', ['non']],
  shrug:     ['solo', '🤷', '{a} hausse les épaules', ['hausser']],
  lurk:      ['solo', '🕵️', '{a} observe en silence', ['observer']],
};

const IMAGES = {
  neko: ['🐱', 'Une neko pour toi !', ['chatte']],
  waifu: ['💖', 'Ta waifu du jour !', []],
  kitsune: ['🦊', 'Une kitsune pour toi !', ['renardanime']],
  husbando: ['💙', 'Ton husbando du jour !', []],
};

function targetOf(ctx) {
  if (ctx.target) return mentionHtml(ctx.target);
  const mentionEntity = (ctx.msg.entities || []).find((e) => e.type === 'text_mention' && e.user);
  if (mentionEntity) return mentionHtml(mentionEntity.user);
  const first = ctx.args.split(/\s+/)[0];
  if (first && first.startsWith('@')) return esc(first);
  if (ctx.args) return esc(ctx.args.slice(0, 40));
  return null;
}

async function fetchNeko(category) {
  const data = await getJson(`${NEKOS_API}/${category}`, { timeout: 8000, retries: 1 });
  const r = data?.results?.[0];
  if (!r?.url) throw new Error('réponse nekos.best vide');
  return r;
}

function sourceLine(r) {
  if (r.anime_name) return `\n<i>🎬 ${esc(r.anime_name)}</i>`;
  if (r.artist_name) return `\n<i>🎨 ${esc(r.artist_name)}</i>`;
  return '';
}

export const defs = [];

for (const [name, [type, emoji, tpl, aliases]] of Object.entries(R)) {
  defs.push({
    name: name === 'kick' ? 'pied' : name, // /kick est réservé à la modération
    aliases, cat: '🎭 Réactions', cooldown: 2500,
    desc: type === 'duo' ? `${emoji} ${name === 'kick' ? 'pied' : name} (réponds à quelqu’un)` : `${emoji} ${name}`,
    async run(ctx) {
      const a = `<b>${esc(userName(ctx.from))}</b>`;
      const t = targetOf(ctx);
      const b = t ? `<b>${t}</b>` : `<b>${esc(BOT_NAME)}</b>`;
      const caption = `${emoji} ${tpl.replace('{a}', a).replace('{b}', b)}`;
      let r = null;
      try { r = await fetchNeko(name); } catch (e) { console.warn(`[nekos] ${name}: ${e.message}`); }
      if (!r) return ctx.say(`${caption}\n<i>(l’animation n’a pas pu se charger, mais l’intention y est 😉)</i>`);
      const full = caption + sourceLine(r);
      try {
        await ctx.media('animation', r.url, { caption: full });
      } catch (e) {
        console.warn(`[nekos] envoi ${name}: ${e.message}`);
        await ctx.say(`${full}\n${esc(r.url)}`, { link_preview_options: { is_disabled: false } });
      }
    },
  });
}

for (const [name, [emoji, label, aliases]] of Object.entries(IMAGES)) {
  defs.push({
    name, aliases, cat: '🎭 Réactions', desc: `${emoji} image anime « ${name} »`, cooldown: 3000,
    async run(ctx) {
      let r = null;
      try { r = await fetchNeko(name); } catch (e) { console.warn(`[nekos] ${name}: ${e.message}`); }
      if (!r) return ctx.reply('Le site d’images ne répond pas pour le moment, réessaie dans un instant 🙏');
      const caption = `${emoji} ${label}${sourceLine(r)}`;
      try {
        await ctx.media('photo', r.url, { caption });
      } catch {
        try { await ctx.media('document', r.url, { caption }); } catch { await ctx.say(`${caption}\n${esc(r.url)}`); }
      }
    },
  });
}

defs.push({
  name: 'reactions', aliases: ['rea'], cat: '🎭 Réactions', desc: 'liste de toutes les réactions',
  run(ctx) {
    const duo = Object.entries(R).filter(([, v]) => v[0] === 'duo').map(([k]) => `.${k === 'kick' ? 'pied' : k}`).join(' ');
    const solo = Object.entries(R).filter(([, v]) => v[0] === 'solo').map(([k]) => `.${k}`).join(' ');
    return ctx.reply(`🎭 <b>Réactions</b> (préfixes <code>/</code> <code>.</code> <code>!</code>)\n\n<b>Sur quelqu’un</b> (réponds à son message) :\n${duo}\n\n<b>Seul(e)</b> :\n${solo}\n\n<b>Images</b> : ${Object.keys(IMAGES).map((k) => `.${k}`).join(' ')}`);
  },
});
export default defs;
