// Données et règles communes de l'économie avancée : objets, XP/niveaux, banque.
// Tout est stocké dans db.econ[userId] (champs ajoutés à la demande, donc compatible avec les anciennes données).
import * as store from './store.js';

export const ITEMS = {
  bouclier: { emoji: '🛡️', name: 'Bouclier', price: 300, use: true, desc: 'te protège des vols pendant 24 h' },
  trefle: { emoji: '🍀', name: 'Trèfle', price: 150, use: true, desc: 'ton prochain /pari a 65 % de chances (au lieu de 45 %)' },
  pioche: { emoji: '⛏️', name: 'Pioche', price: 500, use: true, desc: '/work rapporte ×2 pendant 5 utilisations' },
  crochet: { emoji: '🗝️', name: 'Crochet', price: 200, use: true, desc: 'ton prochain /voler réussit à 75 % (au lieu de 50 %)' },
  potion: { emoji: '🧪', name: 'Potion d’XP', price: 400, use: true, desc: 'donne +100 XP tout de suite' },
  ticket: { emoji: '🎟️', name: 'Ticket à gratter', price: 100, use: true, desc: 'peut rapporter de 100 à 1 000 🪙' },
  bague: { emoji: '💍', name: 'Bague', price: 2000, use: false, desc: 'badge affiché sur ton niveau' },
  couronne: { emoji: '👑', name: 'Couronne', price: 5000, use: false, desc: 'badge affiché sur ton niveau' },
  diamant: { emoji: '💎', name: 'Diamant', price: 10000, use: false, desc: 'le badge ultime' },
};
export const BADGES = ['bague', 'couronne', 'diamant'];
export const itemKey = (txt) => {
  const t = String(txt || '').toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '').replace(/[^a-z]/g, '');
  if (ITEMS[t]) return t;
  return Object.keys(ITEMS).find((k) => t && (k.startsWith(t) || ITEMS[k].name.toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '').replace(/[^a-z]/g, '').startsWith(t))) || null;
};

/** Compte économique complet (valeurs par défaut ajoutées si besoin). */
export function eco(userId) {
  const e = store.econ(userId);
  e.bank ??= 0; e.xp ??= 0; e.inv ??= {}; e.buffs ??= {}; e.lastSteal ??= 0; e.lastInterest ??= 0;
  return e;
}

// ---------- XP / niveaux ----------
export const xpFor = (level) => level * level * 25;                 // XP total nécessaire pour atteindre ce niveau
export const levelOf = (xp) => Math.floor(Math.sqrt(Math.max(0, xp) / 25));
export function addXp(userId, n) {
  const e = eco(userId);
  const before = levelOf(e.xp);
  e.xp += Math.max(0, Math.round(n));
  const level = levelOf(e.xp);
  let bonus = 0;
  if (level > before) { bonus = level * 50; e.coins += bonus; }
  store.save();
  return { level, up: level > before, bonus };
}
export const badgeOf = (e) => BADGES.filter((k) => e.inv?.[k] > 0).map((k) => ITEMS[k].emoji).join('');

// ---------- Banque ----------
export const bankCap = (e) => 5000 + 1000 * levelOf(e.xp || 0);
/** Intérêts : 2 % par jour entier écoulé (max 500 🪙/jour, 7 jours rattrapables). Renvoie le gain. */
export function accrue(userId) {
  const e = eco(userId);
  const now = Date.now();
  if (!e.lastInterest) { e.lastInterest = now; return 0; }
  const days = Math.min(7, Math.floor((now - e.lastInterest) / 86400000));
  if (days < 1) return 0;
  e.lastInterest += days * 86400000;
  if (e.bank <= 0) return 0;
  const gain = Math.min(500, Math.floor(e.bank * 0.02)) * days;
  e.bank = Math.min(bankCap(e), e.bank + gain);
  store.save();
  return gain;
}
