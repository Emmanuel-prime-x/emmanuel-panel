// Client Telegram Bot API sans dépendance : timeouts, retries, 429, envoi sécurisé (HTML -> texte brut), polling robuste.
import fs from 'node:fs';
import path from 'node:path';
import { sleep, chunkText, stripTags } from './util.js';

export class TgError extends Error {
  constructor(method, code, description, retryAfter) {
    super(`${method}: ${description}`);
    this.method = method;
    this.code = code;
    this.description = description;
    this.retryAfter = retryAfter;
  }
}

const MIME = {
  '.mp3': 'audio/mpeg', '.m4a': 'audio/mp4', '.ogg': 'audio/ogg', '.oga': 'audio/ogg', '.wav': 'audio/wav',
  '.flac': 'audio/flac', '.mp4': 'video/mp4', '.mov': 'video/quicktime', '.jpg': 'image/jpeg', '.jpeg': 'image/jpeg',
  '.png': 'image/png', '.gif': 'image/gif', '.webp': 'image/webp',
};

export class Telegram {
  constructor({ token, base, log = console }) {
    this.api = `${base}/bot${token}`;
    this.log = log;
    this.stopped = false;
    this.pollAbort = null;
    this.me = null;
  }

  async call(method, params = {}, { timeout = 20000, retries = 3 } = {}) {
    for (let attempt = 0; ; attempt += 1) {
      let res;
      try {
        res = await fetch(`${this.api}/${method}`, {
          method: 'POST',
          headers: { 'content-type': 'application/json' },
          body: JSON.stringify(params),
          signal: AbortSignal.timeout(timeout),
        });
      } catch (e) {
        if (attempt < retries && !this.stopped) {
          await sleep(500 * 2 ** attempt);
          continue;
        }
        throw new TgError(method, 0, `réseau : ${e?.message || e}`);
      }
      let data = null;
      try {
        data = await res.json();
      } catch { /* corps non JSON */ }
      if (data?.ok) return data.result;
      const code = data?.error_code ?? res.status;
      const desc = data?.description ?? res.statusText ?? 'erreur inconnue';
      const retryAfter = data?.parameters?.retry_after;
      if (code === 429 && attempt < retries) {
        await sleep(Math.min(retryAfter ?? 1, 30) * 1000 + 250);
        continue;
      }
      if (code >= 500 && attempt < retries) {
        await sleep(500 * 2 ** attempt);
        continue;
      }
      throw new TgError(method, code, desc, retryAfter);
    }
  }

  // Envoi multipart (fichier local ou buffer)
  async upload(method, fields, fileField, file, { timeout = 180000 } = {}) {
    for (let attempt = 0; attempt < 2; attempt += 1) {
      const form = new FormData();
      for (const [k, v] of Object.entries(fields)) {
        if (v === undefined || v === null) continue;
        form.append(k, typeof v === 'object' ? JSON.stringify(v) : String(v));
      }
      let buf = file.buffer;
      if (!buf) buf = await fs.promises.readFile(file.path);
      const filename = file.filename || path.basename(file.path || 'file');
      const type = file.contentType || MIME[path.extname(filename).toLowerCase()] || 'application/octet-stream';
      form.append(fileField, new Blob([buf], { type }), filename);
      let res;
      try {
        res = await fetch(`${this.api}/${method}`, { method: 'POST', body: form, signal: AbortSignal.timeout(timeout) });
      } catch (e) {
        if (attempt === 0) { await sleep(1000); continue; }
        throw new TgError(method, 0, `réseau : ${e?.message || e}`);
      }
      let data = null;
      try { data = await res.json(); } catch { /* ignore */ }
      if (data?.ok) return data.result;
      const code = data?.error_code ?? res.status;
      if (code === 429 && attempt === 0) { await sleep(Math.min(data?.parameters?.retry_after ?? 2, 30) * 1000); continue; }
      if (code >= 500 && attempt === 0) { await sleep(1000); continue; }
      throw new TgError(method, code, data?.description ?? res.statusText, data?.parameters?.retry_after);
    }
    throw new TgError(method, 0, 'échec de l’envoi');
  }

  static buildExtra(extra = {}) {
    const { reply_to, thread, ...rest } = extra;
    const p = { ...rest };
    if (reply_to) p.reply_parameters = { message_id: reply_to, allow_sending_without_reply: true };
    if (thread) p.message_thread_id = thread;
    return p;
  }

  // Corrige automatiquement les erreurs d'envoi les plus courantes (HTML invalide, réponse à un message supprimé...)
  async _safe(method, params, textKey, fileSender) {
    const p = { ...params };
    for (let fix = 0; fix < 4; fix += 1) {
      try {
        return fileSender ? await fileSender(p) : await this.call(method, p);
      } catch (e) {
        if (!(e instanceof TgError)) throw e;
        const d = e.description || '';
        if (/can't parse entities|unsupported start tag|can't find end tag|entity/i.test(d) && p.parse_mode) {
          delete p.parse_mode;
          if (p[textKey]) p[textKey] = stripTags(p[textKey]);
          continue;
        }
        if (/reply message not found|message to be replied not found|REPLY_MESSAGE/i.test(d) && p.reply_parameters) {
          delete p.reply_parameters;
          continue;
        }
        if (/message thread not found/i.test(d) && p.message_thread_id) {
          delete p.message_thread_id;
          continue;
        }
        throw e;
      }
    }
    throw new TgError(method, 400, 'échec après corrections automatiques');
  }

  async sendMessage(chatId, text, extra = {}) {
    const parts = chunkText(String(text ?? '').trim() || '…', 4000);
    let last = null;
    for (let i = 0; i < parts.length; i += 1) {
      const e = i === 0 ? extra : { ...extra, reply_to: undefined, reply_markup: i === parts.length - 1 ? extra.reply_markup : undefined };
      const params = {
        chat_id: chatId,
        text: parts[i],
        parse_mode: 'HTML',
        link_preview_options: { is_disabled: true },
        ...Telegram.buildExtra(e),
      };
      last = await this._safe('sendMessage', params, 'text');
    }
    return last;
  }

  // kind: photo | animation | video | audio | document | voice | sticker
  async sendMedia(kind, chatId, source, extra = {}) {
    const method = `send${kind[0].toUpperCase()}${kind.slice(1)}`;
    const params = { chat_id: chatId, parse_mode: 'HTML', ...Telegram.buildExtra(extra) };
    if (!params.caption) delete params.parse_mode;
    if (typeof source === 'string') {
      params[kind] = source;
      return this._safe(method, params, 'caption');
    }
    return this._safe(method, params, 'caption', (p) => this.upload(method, p, kind, source));
  }

  async editText(chatId, messageId, text, extra = {}) {
    const params = { chat_id: chatId, message_id: messageId, text, parse_mode: 'HTML', link_preview_options: { is_disabled: true }, ...extra };
    try {
      return await this._safe('editMessageText', params, 'text');
    } catch (e) {
      if (e instanceof TgError && /not modified/i.test(e.description)) return null;
      throw e;
    }
  }

  typing(chatId, action = 'typing', thread) {
    return this.call('sendChatAction', { chat_id: chatId, action, ...(thread ? { message_thread_id: thread } : {}) }, { retries: 0, timeout: 8000 }).catch(() => {});
  }

  async init() {
    this.me = await this.call('getMe', {}, { retries: 5 });
    return this.me;
  }

  async poll(onUpdate, allowed = ['message', 'callback_query']) {
    try {
      await this.call('deleteWebhook', { drop_pending_updates: false }, { retries: 2 });
    } catch (e) {
      this.log.warn(`[poll] deleteWebhook : ${e.message}`);
    }
    let offset = 0;
    let backoff = 1000;
    let conflicts = 0;
    while (!this.stopped) {
      try {
        const updates = await this.call('getUpdates', { offset, timeout: 30, allowed_updates: allowed }, { timeout: 45000, retries: 0 });
        backoff = 1000;
        conflicts = 0;
        for (const u of updates) {
          offset = u.update_id + 1;
          try {
            onUpdate(u);
          } catch (e) {
            this.log.error('[poll] update ignoré :', e);
          }
        }
      } catch (e) {
        if (this.stopped) break;
        if (e instanceof TgError && e.code === 401) {
          this.log.error('[poll] TOKEN INVALIDE (401). Vérifie TELEGRAM_TOKEN (ou génère-en un nouveau avec @BotFather). Nouvelle tentative dans 60 s.');
          await sleep(60000);
          continue;
        }
        if (e instanceof TgError && e.code === 409) {
          conflicts += 1;
          this.log.warn(`[poll] 409 : une autre instance utilise ce token (panel ouvert deux fois ? ancien bot lancé ailleurs ?). Attente ${Math.min(5 * conflicts, 30)} s.`);
          await sleep(Math.min(5 * conflicts, 30) * 1000);
          continue;
        }
        if (e instanceof TgError && e.code === 429) {
          await sleep(Math.min(e.retryAfter ?? 5, 60) * 1000);
          continue;
        }
        this.log.warn(`[poll] erreur : ${e.message} (nouvel essai dans ${Math.round(backoff / 1000)} s)`);
        await sleep(backoff);
        backoff = Math.min(backoff * 2, 30000);
      }
    }
  }

  stop() {
    this.stopped = true;
  }
}

// Message d'erreur lisible pour l'utilisateur
export function friendlyTgError(e) {
  const d = (e && (e.description || e.message)) || '';
  if (/not enough rights|CHAT_ADMIN_REQUIRED|have no rights|need to be an administrator|can't remove chat owner|rights to/i.test(d)) return 'Je n’ai pas les droits nécessaires : mets-moi administratrice du groupe avec les permissions voulues 🙏';
  if (/can't (?:be )?(?:restrict|ban|kick|promote|demote)|user is an administrator|USER_ADMIN_INVALID|can't remove|PARTICIPANT_ID_INVALID/i.test(d)) return 'Je ne peux pas faire ça sur un administrateur (ou sur le propriétaire du groupe).';
  if (/user not found|USER_ID_INVALID|participant/i.test(d)) return 'Je ne trouve pas cette personne.';
  if (/message to delete not found|message can't be deleted/i.test(d)) return 'Je ne peux pas supprimer ce message.';
  if (/chat not found|bot was kicked|bot is not a member/i.test(d)) return 'Je n’ai plus accès à ce groupe.';
  if (/blocked by the user|user is deactivated|chat not found/i.test(d)) return 'Cet utilisateur ne peut pas être contacté.';
  if (/file is too big|too large|Request Entity Too Large/i.test(d)) return 'Ce fichier est trop gros pour Telegram (50 Mo maximum pour un bot).';
  return 'Telegram a refusé cette action.';
}
