# EMMANUEL BUG BOT

Bot Telegram multi-sessions WhatsApp avec contrôle d'accès par rôles, appairage de numéros, déploiement de sous-bots et stockage persistant au format JSON.

Créé par **𝐏𝐑𝐎𝐅𝐄𝐒𝐒𝐎𝐑 𝐄𝐌𝐌𝐀𝐍𝐔𝐄𝐋 𝐗**.

## Aperçu

Ce projet est développé en Node.js et s'appuie sur :

- **Grammy** pour la gestion du bot Telegram
- **Baileys** pour la gestion des sessions WhatsApp
- des fichiers **JSON** comme couche de stockage
- un runtime de bot **modularisé** pour une maintenance plus propre
- des **sous-bots déployables** avec leur propre contexte d'exécution

Il est conçu pour gérer les accès utilisateurs, les rôles Premium/VVIP, l'appairage de sessions WhatsApp et des actions pilotées par menu.

## Personnalisation (rebranding)

La plupart des réglages d'identité sont centralisés dans `src/config/config.js`. Pour rebrander le bot, modifie :

- `BRANDING.name` — nom complet utilisé dans les menus, notes et logs
- `BRANDING.shortName` — nom compact affiché dans les en-têtes de menu
- `BRANDING.tagline` — slogan du projet
- `BRANDING.version` — version affichée
- `BRANDING.creator` — libellé du créateur/propriétaire
- `BRANDING.emoji` — emoji d'identité d'en-tête
- `BRANDING.footer` — texte de pied de page affiché sous les menus
- `CUSTOM_EMOJI` — IDs d'emojis Telegram personnalisés groupés par zone de menu

Le code d'exécution utilise ces valeurs de configuration au lieu d'inscrire les noms de marque directement dans les fichiers source.

## Configuration (.env)

Toutes les valeurs sensibles et propres au déploiement se trouvent dans le fichier `.env` à la racine. **Ces valeurs n'ont pas été modifiées** et restent à personnaliser par tes soins :

- `BOT_TOKEN` — token du bot fourni par @BotFather
- `OWNER_ID` — ID Telegram numérique du propriétaire
- `OWNER_USERNAME` — nom d'utilisateur du propriétaire (sans @)
- `FORCE_JOIN_CHANNEL` — channel d'adhésion obligatoire
- `MENU_VIDEO_URL` / `MENU_PHOTO_URL` — médias du menu `/start`
- `MENU_MEDIA_TYPE` — `video` ou `photo`

## Structure du projet

```text
emmanuel-bug-bot/
├── .env
├── database/
│   ├── admin.json
│   ├── bots.json
│   ├── mode.json
│   ├── premium.json
│   ├── users.json
│   ├── vvip.json
│   └── maintenance.json
├── sessions/
├── src/
│   ├── bootstrap.js
│   ├── config/
│   │   └── config.js
│   ├── data/
│   │   └── database.js
│   └── bot/
│       ├── deploy.js
│       ├── logger.js
│       ├── menu.js
│       ├── travas.js
│       ├── vvipCooldown.js
│       ├── whatsapp.js
│       └── handlers/
│           ├── callbacks.js
│           ├── commands.js
│           ├── index.js
│           └── runtime.js
├── package.json
└── README.md
```

## Installation

```bash
npm install
npm start
```

Le point d'entrée est `src/bootstrap.js`.

## Rôles et hiérarchie

Le bot applique la hiérarchie suivante (du plus élevé au plus bas) :

1. **Propriétaire** — contrôle total (admins, mode, maintenance, backup, redémarrage…)
2. **Administrateur** — gestion Premium/VVIP, diffusion, statistiques
3. **VVIP** — accès étendu et émetteur VVIP
4. **Premium** — accès aux actions et au déploiement de sous-bots
5. **Gratuit** — accès limité selon le mode du bot

Le bot fonctionne en mode **privé** ou **public** (`/mode`).

## Commandes

### Menu et démarrage
- `/start` — menu de démarrage
- `/menu` — menu complet
- `/action` — menu des actions
- `/myinfo` — tes informations

### Utilitaires
- `/help` — aide complète
- `/ping` — latence du bot
- `/id` — tes identifiants Telegram
- `/stats` — statistiques globales
- `/health` — état du système (RAM, CPU, uptime, sessions)
- `/sessions` — sessions WhatsApp actives

### Profil utilisateur
- `/userinfo <id>` — détails d'un utilisateur
- `/listusers` — liste des utilisateurs
- `/deluser <id>` — supprime un utilisateur
- `/exportusers` — exporte les utilisateurs en JSON

### Premium
- `/addprem <id>[,<durée>]`
- `/extendprem <id> <durée>`
- `/delprem <id>`
- `/listprem`

### VVIP
- `/addvvip <id>[,<durée>]`
- `/delvvip <id>`
- `/listvvip`
- `/resetvvipcooldown [id]`

### Administration
- `/addadmin <id>` / `/deladmin <id>` / `/listadmin`
- `/mode <private/public>`
- `/bc <texte>` — diffusion
- `/maintenance <on|off|status> [message]`
- `/restart` — redémarre le bot

### Sessions WhatsApp
- `/pair <numéro>`
- `/delpair <numéro>`
- `/listpair`
- `/clearpair`

### Sous-bots
- `/addbot <token>,<owner_id>`
- `/delbot <token>`
- `/listbot`

### Sauvegarde / restauration
- `/backup` — sauvegarde la base (propriétaire, en privé)
- `/restore` — restaure la base (propriétaire, en privé)

### Actions
Les actions disponibles sont listées dans `/action` et exécutées via les commandes du registre `TRAVAS_REGISTRY` (cibles : numéro, groupe ou channel).

## Durées acceptées

Les commandes de rôle acceptent les unités suivantes :

- `m` — minutes
- `h` — heures
- `d` — jours
- `w` — semaines
- `mo` — mois
- `y` — années
- `0` ou vide — accès permanent

Exemple : `/addprem 123456789 7d`.

## Stockage

Les données sont stockées dans `database/` (JSON) et les sessions WhatsApp dans `sessions/`. Les sauvegardes manuelles et automatiques sont conservées dans `database/backups/`.

## Sécurité

Un bloc de télémétrie non sollicité (exfiltration de token) présent dans la version d'origine a été **entièrement supprimé**. Vérifie toujours le code avant d'exécuter un bot tiers, et ne partage jamais ton `.env`.
