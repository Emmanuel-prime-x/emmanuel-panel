import crypto from 'node:crypto';
import { esc, normalize, truncate } from '../util.js';

const MORSE = { A: '.-', B: '-...', C: '-.-.', D: '-..', E: '.', F: '..-.', G: '--.', H: '....', I: '..', J: '.---', K: '-.-', L: '.-..', M: '--', N: '-.', O: '---', P: '.--.', Q: '--.-', R: '.-.', S: '...', T: '-', U: '..-', V: '...-', W: '.--', X: '-..-', Y: '-.--', Z: '--..', 0: '-----', 1: '.----', 2: '..---', 3: '...--', 4: '....-', 5: '.....', 6: '-....', 7: '--...', 8: '---..', 9: '----.' };
const MORSE_R = Object.fromEntries(Object.entries(MORSE).map(([k, v]) => [v, k]));
const FLIP = { a: 'ɐ', b: 'q', c: 'ɔ', d: 'p', e: 'ǝ', f: 'ɟ', g: 'ƃ', h: 'ɥ', i: 'ᴉ', j: 'ɾ', k: 'ʞ', m: 'ɯ', n: 'u', p: 'd', q: 'b', r: 'ɹ', t: 'ʇ', u: 'n', v: 'ʌ', w: 'ʍ', y: 'ʎ', '?': '¿', '!': '¡' };
const LEET = { a: '4', e: '3', i: '1', o: '0', s: '5', t: '7', l: '1', b: '8' };
const LOREM = 'lorem ipsum dolor sit amet consectetur adipiscing elit sed do eiusmod tempor incididunt ut labore et dolore magna aliqua ut enim ad minim veniam quis nostrud exercitation ullamco laboris'.split(' ');

const src = (ctx) => ctx.args || ctx.msg.reply_to_message?.text || ctx.msg.reply_to_message?.caption || '';
const T = (name, desc, fn, extra = {}) => ({
  name, desc, cat: '🔤 Texte', ...extra,
  run(ctx) {
    const t = src(ctx);
    if (!t) return ctx.reply(`Usage : /${name} &lt;texte&gt; (ou réponds à un message)`);
    return ctx.reply(esc(truncate(fn(t, ctx), 3900)));
  },
});

export const defs = [
  T('majuscule', 'EN MAJUSCULES', (t) => t.toUpperCase(), { aliases: ['upper'] }),
  T('minuscule', 'en minuscules', (t) => t.toLowerCase(), { aliases: ['lower'] }),
  T('inverse', 'inverse le texte', (t) => [...t].reverse().join(''), { aliases: ['reverse'] }),
  T('retourne', 'texte à l’envers (¡)', (t) => `(╯°□°)╯︵ ${[...t.toLowerCase()].reverse().map((c) => FLIP[c] || c).join('')}`, { aliases: ['upsidedown'] }),
  T('compter', 'compte mots et caractères', (t) => `${t.trim().split(/\s+/).filter(Boolean).length} mot(s), ${[...t].length} caractère(s)`, { aliases: ['count', 'wc'] }),
  T('rot13', 'chiffre ROT13', (t) => t.replace(/[a-z]/gi, (c) => { const b = c <= 'Z' ? 65 : 97; return String.fromCharCode(((c.charCodeAt(0) - b + 13) % 26) + b); })),
  T('base64', 'encode en base64', (t) => Buffer.from(t, 'utf8').toString('base64'), { aliases: ['b64'] }),
  T('unbase64', 'décode du base64', (t) => { const s = Buffer.from(t.trim(), 'base64').toString('utf8'); return s || 'Base64 invalide'; }, { aliases: ['d64'] }),
  T('hex', 'texte en hexadécimal', (t) => Buffer.from(t, 'utf8').toString('hex')),
  T('unhex', 'hexadécimal en texte', (t) => (/^[0-9a-f\s]+$/i.test(t) ? Buffer.from(t.replace(/\s/g, ''), 'hex').toString('utf8') : 'Hexadécimal invalide')),
  T('urlenc', 'encode pour une URL', (t) => encodeURIComponent(t)),
  T('urldec', 'décode une URL', (t) => { try { return decodeURIComponent(t); } catch { return 'Texte invalide'; } }),
  T('sha256', 'empreinte SHA-256', (t) => crypto.createHash('sha256').update(t).digest('hex'), { aliases: ['hash'] }),
  T('md5', 'empreinte MD5', (t) => crypto.createHash('md5').update(t).digest('hex')),
  T('binaire', 'texte ↔ binaire', (t) => (/^[01\s]+$/.test(t) ? t.trim().split(/\s+/).map((b) => String.fromCharCode(parseInt(b, 2))).join('') : [...t].map((c) => c.charCodeAt(0).toString(2).padStart(8, '0')).join(' ')), { aliases: ['binary'] }),
  T('morse', 'texte ↔ morse', (t) => (/^[.\-/\s]+$/.test(t)
    ? t.trim().split(/\s*\/\s*/).map((w) => w.trim().split(/\s+/).map((c) => MORSE_R[c] || '').join('')).join(' ')
    : t.toUpperCase().split(/\s+/).map((w) => [...w].map((c) => MORSE[c] || '').filter(Boolean).join(' ')).join(' / '))),
  T('palindrome', 'est-ce un palindrome ?', (t) => { const n = normalize(t); return n && n === [...n].reverse().join('') ? 'Oui, c’est un palindrome ! 🔁' : 'Non, pas un palindrome.'; }),
  T('anagramme', 'deux mots sont-ils des anagrammes ? (a ; b)', (t) => {
    const p = t.split(';').map((s) => normalize(s.trim())); if (p.length !== 2 || !p[0]) return 'Usage : /anagramme mot1 ; mot2';
    return [...p[0]].sort().join('') === [...p[1]].sort().join('') ? 'Oui, anagrammes ! 🔀' : 'Non, pas des anagrammes.';
  }),
  T('clap', 'ajoute des 👏', (t) => t.trim().split(/\s+/).join(' 👏 ')),
  T('mock', 'sPoNgEbOb', (t) => [...t.toLowerCase()].map((c, i) => (i % 2 ? c.toUpperCase() : c)).join('')),
  T('leet', 'écriture l33t', (t) => [...t.toLowerCase()].map((c) => LEET[c] || c).join('')),
  T('large', 'ｔｅｘｔｅ　ｌａｒｇｅ', (t) => [...t].map((c) => { const n = c.charCodeAt(0); return n >= 33 && n <= 126 ? String.fromCharCode(n + 0xfee0) : c === ' ' ? '　' : c; }).join(''), { aliases: ['vaporwave'] }),
  T('gras', '𝗧𝗲𝘅𝘁𝗲 𝗲𝗻 𝗴𝗿𝗮𝘀 unicode', (t) => [...t].map((c) => { const n = c.charCodeAt(0); if (n >= 65 && n <= 90) return String.fromCodePoint(0x1d5d4 + n - 65); if (n >= 97 && n <= 122) return String.fromCodePoint(0x1d5ee + n - 97); if (n >= 48 && n <= 57) return String.fromCodePoint(0x1d7ec + n - 48); return c; }).join(''), { aliases: ['bold'] }),
  T('espace', 'e s p a c e', (t) => [...t].join(' ')),
  T('trier', 'trie les mots', (t) => t.trim().split(/\s+/).sort((a, b) => a.localeCompare(b, 'fr')).join(' '), { aliases: ['sort'] }),
  T('unique', 'supprime les mots en double', (t) => [...new Set(t.trim().split(/\s+/))].join(' ')),
  T('initiales', 'initiales des mots', (t) => t.trim().split(/\s+/).map((w) => w[0]?.toUpperCase() || '').join('')),
  T('capitaliser', 'Première Lettre En Majuscule', (t) => t.toLowerCase().replace(/(^|\s)\p{L}/gu, (m) => m.toUpperCase())),
  {
    name: 'repeter', aliases: ['repeat'], cat: '🔤 Texte', desc: 'répète un texte (/repeter 3 hello)',
    run(ctx) {
      const m = ctx.args.match(/^(\d{1,2})\s+([\s\S]+)$/);
      if (!m) return ctx.reply('Usage : /repeter 3 texte (max 50)');
      return ctx.reply(esc(truncate(Array(Math.min(parseInt(m[1], 10), 50)).fill(m[2]).join(' '), 3900)));
    },
  },
  {
    name: 'lorem', cat: '🔤 Texte', desc: 'faux texte (/lorem 30)',
    run(ctx) {
      const n = Math.min(Math.max(parseInt(ctx.args, 10) || 25, 3), 200);
      const w = Array.from({ length: n }, (_, i) => LOREM[(i * 7 + n) % LOREM.length]);
      return ctx.reply(`${w.join(' ').replace(/^./, (c) => c.toUpperCase())}.`);
    },
  },
  { name: 'tableflip', cat: '🔤 Texte', desc: '(╯°□°)╯︵ ┻━┻', run: (ctx) => ctx.say('(╯°□°)╯︵ ┻━┻') },
  { name: 'unflip', cat: '🔤 Texte', desc: '┬─┬ ノ( ゜-゜ノ)', run: (ctx) => ctx.say('┬─┬ ノ( ゜-゜ノ)') },
  { name: 'lenny', cat: '🔤 Texte', desc: '( ͡° ͜ʖ ͡°)', run: (ctx) => ctx.say('( ͡° ͜ʖ ͡°)') },
];
export default defs;
