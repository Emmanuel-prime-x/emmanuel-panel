const Y = require('../lib/ytdl')
const U = require('../lib/utils')

const URL_RE = /https?:\/\/[^\s]+/i
const YT_RE = /(youtube\.com|youtu\.be)/i
const use = (c, s) => c.reply(`ℹ️ Usage : ${c.prefix}${s}`)
const caption = (v, icon) => `${icon} *${v.title}*\n👤 ${v.author}\n⏱️ ${v.duration}  •  👁️ ${v.views}\n🔗 ${v.url}`

// Envoi générique d'un fichier téléchargé (le type réel est détecté dans le fichier lui-même)
async function sendResult(c, r, label) {
  const ext = Y.sniff(r.buffer) || (r.ext || '').toLowerCase()
  const kind = Y.kindOf(ext)
  if (kind === 'image') return ext === 'webp' ? c.sticker(r.buffer) : c.image(r.buffer, label)
  if (kind === 'audio') return c.audio(r.buffer, ext === 'mp3' ? 'audio/mpeg' : ext === 'ogg' ? 'audio/ogg; codecs=opus' : 'audio/mp4', 'audio')
  if (r.buffer.length > 90 * 1024 * 1024) throw new Error('Fichier trop lourd pour WhatsApp.')
  return c.video(r.buffer, label)
}

function socialCmd(name, aliases, icon, re, example) {
  return {
    name, aliases, cat: 'download', desc: `Télécharge une vidéo ${name}`, usage: `${name} ${example}`,
    run: async (c) => {
      const url = (c.input.match(URL_RE) || [])[0]
      if (!url) return use(c, `${name} <lien>`)
      if (!re.test(url)) return c.reply(`❌ Ce lien ne semble pas venir de ${name}.`)
      await c.react('⏳')
      const r = await Y.downloadAny(url)
      await sendResult(c, r, `${icon} Téléchargé avec succès`)
      await c.react('✅')
    }
  }
}

module.exports = [
  {
    name: 'song', aliases: ['play', 'music', 'mp3'], cat: 'download', desc: 'Télécharge une chanson depuis YouTube (titre ou lien)', usage: 'song Burna Boy Last Last',
    run: async (c) => {
      if (!c.input) return use(c, 'song <titre ou lien YouTube>')
      await c.react('🔎')
      const v = await Y.findVideo(c.input)
      if (v.seconds > 1800) return c.reply('⏱️ Cette vidéo dépasse 30 minutes, choisis un morceau plus court.')
      await c.image(v.thumbnail, caption(v, '🎧') + '\n\n⏳ Téléchargement de l\'audio...').catch(() => c.reply(caption(v, '🎧')))
      const a = await Y.getAudio(v.url)
      await c.audio(a.buffer, a.mime, v.title.replace(/[\\/:*?"<>|]/g, ''))
      await c.react('✅')
    }
  },
  {
    name: 'video', aliases: ['ytvideo', 'playvideo'], cat: 'download', desc: 'Télécharge une vidéo YouTube (titre ou lien)', usage: 'video son de la nature',
    run: async (c) => {
      if (!c.input) return use(c, 'video <titre ou lien YouTube>')
      await c.react('🔎')
      const v = await Y.findVideo(c.input)
      if (v.seconds > 1200) return c.reply('⏱️ Cette vidéo dépasse 20 minutes, c\'est trop lourd pour WhatsApp.')
      await c.react('⏳')
      const r = await Y.getVideo(v.url)
      await c.video(r.buffer, caption(v, '🎬'))
      await c.react('✅')
    }
  },
  {
    name: 'ytmp3', cat: 'download', desc: 'YouTube (lien) → audio MP3', usage: 'ytmp3 https://youtu.be/...',
    run: async (c) => {
      const url = (c.input.match(URL_RE) || [])[0]
      if (!url || !YT_RE.test(url)) return use(c, 'ytmp3 <lien YouTube>')
      await c.react('⏳')
      const v = await Y.findVideo(url)
      const a = await Y.getAudio(v.url)
      await c.audio(a.buffer, a.mime, v.title.replace(/[\\/:*?"<>|]/g, ''))
      await c.react('✅')
    }
  },
  {
    name: 'ytmp4', cat: 'download', desc: 'YouTube (lien) → vidéo MP4', usage: 'ytmp4 https://youtu.be/...',
    run: async (c) => {
      const url = (c.input.match(URL_RE) || [])[0]
      if (!url || !YT_RE.test(url)) return use(c, 'ytmp4 <lien YouTube>')
      await c.react('⏳')
      const v = await Y.findVideo(url)
      const r = await Y.getVideo(v.url)
      await c.video(r.buffer, caption(v, '🎬'))
      await c.react('✅')
    }
  },
  {
    name: 'yts', aliases: ['ytsearch'], cat: 'download', desc: 'Recherche sur YouTube', usage: 'yts afrobeat 2025',
    run: async (c) => {
      if (!c.text) return use(c, 'yts <recherche>')
      const vids = await Y.searchVideos(c.text, 8)
      if (!vids.length) return c.reply('❌ Aucun résultat.')
      await c.reply(`🔎 *Résultats pour :* ${c.text}\n\n` + vids.map((v, i) => `*${i + 1}.* ${v.title}\n   ⏱️ ${v.timestamp} • 👤 ${v.author?.name}\n   ${v.url}`).join('\n\n') + `\n\n💡 Télécharge avec ${c.prefix}song <titre>`)
    }
  },
  socialCmd('tiktok', ['tt'], '🎵', /tiktok\.com/i, 'https://vm.tiktok.com/...'),
  socialCmd('facebook', ['fb'], '📘', /(facebook\.com|fb\.watch)/i, 'https://fb.watch/...'),
  socialCmd('instagram', ['ig', 'insta'], '📸', /instagram\.com/i, 'https://instagram.com/reel/...'),
  socialCmd('twitter', ['x', 'tw'], '🐦', /(twitter\.com|x\.com)/i, 'https://x.com/.../status/...'),
  {
    name: 'dl', aliases: ['download'], cat: 'download', desc: 'Télécharge une vidéo depuis un lien (1000+ sites)', usage: 'dl https://...',
    run: async (c) => {
      const url = (c.input.match(URL_RE) || [])[0]
      if (!url) return use(c, 'dl <lien>')
      await c.react('⏳')
      const r = await Y.downloadAny(url)
      await sendResult(c, r, '📥 Téléchargé avec succès')
      await c.react('✅')
    }
  }
]
