// Queen Hina — point d'entrée. Zéro dépendance : Node.js 18+ uniquement.
import { TOKEN, TELEGRAM_API, BOT_NAME, BOT_TRIGGER, OWNER_IDS, GROUP_MENTION_ONLY, isOwner } from './config.js';
import * as store from './store.js';
import { Telegram } from './telegram.js';
import * as ai from './ai.js';
import { registerAll, commands, defs, hooks, parseCommand, makeCtx, runCommand, logError } from './router.js';
import { handleCallback } from './handlers/core.js';
import { onJoin } from './handlers/group.js';
import { handleGameCallback } from './handlers/multi.js';
import { handleBjCallback, handleP4Callback } from './handlers/games2.js';
import { systemExtra } from './handlers/persona.js';
import { handleAccessCallback, chatLocked, lockedReply } from './handlers/access.js';
import { handleOwnerCallback } from './handlers/manage.js';
import { handleSupportCallback, onPreCheckout, onPayment } from './handlers/support.js';
import { sleep, esc } from './util.js';

import core from './handlers/core.js';
import reactions from './handlers/reactions.js';
import songs from './handlers/songs.js';
import fun from './handlers/fun.js';
import games from './handlers/games.js';
import economy from './handlers/economy.js';
import group from './handlers/group.js';
import text from './handlers/text.js';
import utils from './handlers/utils.js';
import tools from './handlers/tools.js';
import aicmds from './handlers/aicmds.js';
import admin from './handlers/admin.js';
import support from './handlers/support.js';
import multi from './handlers/multi.js';
import games2 from './handlers/games2.js';
import shop from './handlers/shop.js';
import persona from './handlers/persona.js';
import access from './handlers/access.js';
import manage from './handlers/manage.js';

if (process.versions.node.split('.')[0] < 18) {
  console.error(`Node.js ${process.versions.node} est trop ancien : il faut Node 18 ou plus.`);
  process.exit(1);
}
if (!TOKEN) {
  console.error('❌ TELEGRAM_TOKEN manquant. Renseigne-le dans le fichier .env (ou dans l’onglet Startup du panel).');
  // On reste en vie pour éviter la boucle de redémarrage du panel, avec un rappel régulier.
  setInterval(() => console.error('❌ TELEGRAM_TOKEN manquant — le bot ne peut pas démarrer.'), 60000);
} else {
  main().catch((e) => {
    console.error('[fatal]', e);
  });
}

async function main() {
  store.load();
  registerAll([...core, ...reactions, ...songs, ...fun, ...games, ...multi, ...games2, ...economy, ...shop, ...persona, ...access, ...manage, ...group, ...text, ...utils, ...tools, ...aicmds, ...support, ...admin]);
  console.log(`[boot] ${defs.length} commandes, ${commands.size} noms (avec alias)`);

  const tg = new Telegram({ token: TOKEN, base: TELEGRAM_API });
  // getMe : on réessaie sans jamais planter (réseau du panel pas encore prêt, etc.)
  for (let i = 1; ; i += 1) {
    try { await tg.init(); break; } catch (e) {
      console.error(`[boot] getMe a échoué (${e.message}), essai ${i}`);
      await sleep(Math.min(2000 * i, 30000));
    }
  }
  console.log(`[boot] Connecté : @${tg.me.username} | Propriétaire(s) : ${OWNER_IDS.join(', ') || 'AUCUN (renseigne OWNER_ID)'} | IA : ${ai.hasProvider() ? 'oui' : 'non'}`);
  if (!OWNER_IDS.length) console.warn('[boot] OWNER_ID non défini : envoie /id au bot et mets le nombre dans .env');

  const menuCmds = defs.filter((d) => !d.owner && !d.hidden && d.cat !== '🎭 Réactions').slice(0, 100).map((d) => ({ command: d.name, description: (d.desc || d.name).replace(/\s+/g, ' ').slice(0, 250) }));
  tg.call('setMyCommands', { commands: menuCmds }).catch((e) => console.warn('[boot] setMyCommands :', e.message));

  // ---- file d'attente par chat : un chat lent ne bloque jamais les autres ----
  // Seules les discussions IA d'un même chat sont mises en file ; les commandes passent tout de suite.
  const queues = new Map();
  const serial = (chatId, fn) => {
    const prev = queues.get(chatId) || Promise.resolve();
    const next = prev.catch(() => {}).then(() => Promise.race([fn(), sleep(120000)]));
    queues.set(chatId, next);
    next.catch(() => {}).finally(() => { if (queues.get(chatId) === next) queues.delete(chatId); });
    return next;
  };

  const cooldowns = new Map();
  const floods = new Map();
  setInterval(() => {
    const now = Date.now();
    for (const [k, t] of cooldowns) if (now - t > 60000) cooldowns.delete(k);
    for (const [k, v] of floods) if (now - v.last > 60000) floods.delete(k);
    for (const [k, t] of warned) if (now - t > 60000) warned.delete(k);
  }, 60000).unref();

  const warned = new Map();
  // Retourne true si la commande est ignorée. Au lieu de rester muet, on prévient (au plus une fois / 8 s).
  function limited(ctx, def) {
    if (ctx.isOwner) return false;
    const now = Date.now();
    const f = floods.get(ctx.from.id) || { n: 0, start: now, last: now, until: 0 };
    if (now < f.until) return true;
    if (now - f.start > 10000) { f.n = 0; f.start = now; }
    f.n += 1; f.last = now;
    floods.set(ctx.from.id, f);
    if (f.n > 12) { f.until = now + 15000; ctx.reply('Doucement, tu vas trop vite 😅 Je reprends dans quelques secondes.').catch(() => {}); return true; }
    const key = `${ctx.from.id}:${def.name}`;
    const wait = (def.cooldown || 1200) - (now - (cooldowns.get(key) || 0));
    if (wait > 0) {
      if (wait > 1200 && now - (warned.get(key) || 0) > 8000) {
        warned.set(key, now);
        ctx.reply(`⏳ Attends encore ${Math.ceil(wait / 1000)} s avant de relancer /${def.name}`).catch(() => {});
      }
      return true;
    }
    cooldowns.set(key, now);
    return false;
  }

  async function freeChat(ctx) {
    const raw = ctx.text.trim();
    if (!raw) return;
    let addressed = ctx.isPrivate;
    let content = raw;
    if (!addressed) {
      if (store.chatSettings(ctx.chat.id).muted) return;
      const uname = tg.me.username.toLowerCase();
      const mention = new RegExp(`@${uname}\\b`, 'i');
      const byReply = ctx.msg.reply_to_message?.from?.id === tg.me.id;
      const byName = new RegExp(`(^|[^\\p{L}])${BOT_TRIGGER}([^\\p{L}]|$)`, 'iu').test(raw);
      addressed = mention.test(raw) || byReply || byName || !GROUP_MENTION_ONLY;
      content = raw.replace(mention, '').trim() || 'Coucou !';
    }
    if (!addressed) return;
    if (chatLocked(ctx.from.id)) return lockedReply(ctx); // chat payant : il faut avoir payé en étoiles
    if (!ai.hasProvider()) return ctx.reply('Je n’ai pas encore de cerveau IA configuré 🙈 Mon créateur doit ajouter une clé dans le fichier .env. En attendant, tape /menu !');
    const typing = setInterval(() => tg.typing(ctx.chat.id, 'typing', ctx.thread), 4000);
    tg.typing(ctx.chat.id, 'typing', ctx.thread);
    try {
      const r = await ai.converse(ctx.chat.id, content, { userName: ctx.name, group: ctx.isGroup, extraSystem: systemExtra(ctx) });
      await ctx.reply(r.text ? esc(r.text) : esc(ai.fallbackReply(r.error === 'quota')));
    } finally { clearInterval(typing); }
  }

  async function handleMessage(msg) {
    if (!msg?.chat || msg.from?.is_bot) return;
    store.db.stats.messages += 1;
    store.touchUser(msg.from);
    store.touchChat(msg.chat, msg.from);
    if (msg.successful_payment) { await onPayment(tg, msg).catch((e) => { console.warn('[stars]', e.message); logError('paiement', e); }); return; }
    if (msg.new_chat_members?.length) { await onJoin(tg, msg).catch((e) => console.warn('[join]', e.message)); return; }
    if (msg.from && store.isBlacklisted(msg.from.id) && !isOwner(msg.from.id)) return;

    const text = msg.text ?? msg.caption ?? '';
    const parsed = text ? parseCommand(text, tg.me.username) : null;
    const def = parsed ? commands.get(parsed.name) : null;
    if (def) {
      const ctx = makeCtx(tg, msg, { args: parsed.args, command: parsed.name });
      if (limited(ctx, def)) return;
      store.db.stats.commands += 1;
      await runCommand(def, ctx);
      return;
    }
    const ctx = makeCtx(tg, msg);
    if (parsed && parsed.prefix === '/' && ctx.isPrivate) {
      await ctx.reply('Je ne connais pas cette commande 🤔 Tape /menu pour voir tout ce que je sais faire !');
      return;
    }
    if (parsed && parsed.prefix === '/') return;
    for (const h of hooks) {
      try { if (await h(ctx)) return; } catch (e) { console.warn('[hook]', e.message); }
    }
    if (!msg.text) return;
    if (/^[.!]/.test(msg.text.trim()) && parsed) return; // ".qqch" inconnu : on ne le prend pas pour une discussion
    try { await serial(ctx.chat.id, () => freeChat(ctx)); } catch (e) {
      console.warn('[chat]', e.message); logError('discussion', e);
      try { await ctx.reply(esc(ai.fallbackReply())); } catch { /* ignore */ }
    }
  }

  function onUpdate(u) {
    if (u.pre_checkout_query) { onPreCheckout(tg, u.pre_checkout_query); return; } // 10 s max pour répondre : jamais en file d'attente
    if (u.callback_query) {
      const d = String(u.callback_query.data || '');
      if (store.isBlacklisted(u.callback_query.from?.id) && !isOwner(u.callback_query.from.id)) { tg.call('answerCallbackQuery', { callback_query_id: u.callback_query.id }, { retries: 0, timeout: 5000 }).catch(() => {}); return; }
      const fn = d.startsWith('s:') ? handleSupportCallback : d.startsWith('g:') ? handleGameCallback : d.startsWith('b:') ? handleBjCallback : d.startsWith('p:') ? handleP4Callback : d.startsWith('a:') ? handleAccessCallback : d.startsWith('o:') ? handleOwnerCallback : handleCallback;
      fn(tg, u.callback_query).catch((e) => console.warn('[callback]', e.message));
      return;
    }
    const msg = u.message;
    if (msg?.chat) handleMessage(msg).catch((e) => { console.error('[msg]', e); logError('message', e); });
  }

  // ---- rappels ----
  setInterval(async () => {
    const now = Date.now();
    const due = store.db.reminders.filter((r) => r.at <= now);
    if (!due.length) return;
    store.db.reminders = store.db.reminders.filter((r) => r.at > now);
    store.save();
    for (const r of due) {
      try { await tg.sendMessage(r.chatId, `⏰ <b>Rappel</b> : ${esc(r.text)}`); } catch (e) { console.warn('[rappel]', e.message); }
    }
  }, 5000).unref();

  // ---- arrêt propre + protection anti-boucle de crash ----
  let stopping = false;
  const shutdown = (sig) => {
    if (stopping) return;
    stopping = true;
    console.log(`[exit] ${sig}, sauvegarde...`);
    tg.stop();
    store.flush();
    setTimeout(() => process.exit(0), 300).unref();
  };
  process.on('SIGINT', () => shutdown('SIGINT'));
  process.on('SIGTERM', () => shutdown('SIGTERM'));
  const crashes = [];
  const onCrash = (kind) => (e) => {
    console.error(`[${kind}]`, e);
    logError(kind, e);
    const now = Date.now();
    crashes.push(now);
    while (crashes.length && now - crashes[0] > 60000) crashes.shift();
    if (crashes.length > 8) { console.error('Trop d’erreurs en 60 s : arrêt pour repartir propre.'); store.flush(); process.exit(1); }
  };
  process.on('uncaughtException', onCrash('uncaughtException'));
  process.on('unhandledRejection', onCrash('unhandledRejection'));

  console.log(`✅ ${BOT_NAME} est prête !`);
  await tg.poll(onUpdate, ['message', 'callback_query', 'pre_checkout_query']);
}
