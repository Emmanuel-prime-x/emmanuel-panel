import { registerAll, defs } from '../router.js';
const mods = ['core','reactions','songs','fun','games','multi','games2','economy','shop','persona','access','manage','group','text','utils','tools','aicmds','support','admin'];
for (const m of mods) registerAll((await import(`../handlers/${m}.js`)).default);
const by = {};
for (const d of defs) if (!d.hidden) (by[d.cat] ||= []).push(d);
for (const [c, l] of Object.entries(by)) { const t = `<b>${c}</b>\n\n` + l.map((d) => `/${d.name} — ${d.desc}`).join('\n'); console.log(c.padEnd(22), l.length, t.length, t.length > 4000 ? 'TROP LONG' : 'ok'); }
console.log('menu telegram:', defs.filter((d) => !d.owner && !d.hidden).length, '(max 100 envoyées)');
