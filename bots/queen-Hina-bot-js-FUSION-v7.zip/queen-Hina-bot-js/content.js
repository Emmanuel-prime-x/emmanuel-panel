export const JOKES = [
  'Pourquoi les plongeurs plongent-ils toujours en arrière ? Parce que sinon ils tombent dans le bateau ! 🤿',
  'Que dit un escargot quand il croise une limace ? « Tiens, un nudiste ! » 🐌',
  'Quel est le comble pour un électricien ? De ne pas être au courant. ⚡',
  'Pourquoi les poissons détestent l’ordinateur ? Ils ont peur du net ! 🐟',
  'Qu’est-ce qui est jaune et qui attend ? Jonathan. 😄',
  'Un croissant rencontre une baguette : « Ça va, t’as pas trop la croûte ? » 🥐',
  'Pourquoi les maths sont tristes ? Parce qu’elles ont trop de problèmes. ➗',
  'Quel est le sport préféré des insectes ? Le cricket ! 🦗',
  'Que fait un geek quand il a froid ? Il ferme Windows. 🪟',
  'Comment appelle-t-on un chat tombé dans un pot de peinture le jour de Noël ? Un chat-peint de Noël. 🎄',
  'Pourquoi le livre de maths est-il stressé ? Il a trop d’exercices à résoudre. 📘',
  'Que dit une imprimante dans l’eau ? « J’ai papier ! » 🖨️',
  'Qu’est-ce qu’un crocodile qui surveille la pharmacie ? Un lacoste garde. 🐊',
  'Pourquoi les oiseaux volent vers le sud ? Parce que c’est trop loin à pied ! 🐦',
  'Je voulais acheter un hamac, mais j’ai pas trouvé de bon plan pour le suspendre… alors j’ai laissé tomber. 😴',
];
export const QUOTES = [
  '« Le succès, c’est d’aller d’échec en échec sans perdre son enthousiasme. » — Winston Churchill',
  '« La vie, c’est comme une bicyclette : il faut avancer pour ne pas perdre l’équilibre. » — Albert Einstein',
  '« Tout est possible à qui rêve, ose, travaille et n’abandonne jamais. » — Xavier Dolan',
  '« Ce qui ne me tue pas me rend plus fort. » — Friedrich Nietzsche',
  '« Sois le changement que tu veux voir dans le monde. » — Gandhi',
  '« Le meilleur moment pour planter un arbre était il y a 20 ans. Le deuxième meilleur moment, c’est maintenant. » — Proverbe chinois',
  '« Rien ne sert de courir ; il faut partir à point. » — Jean de La Fontaine',
  '« On ne voit bien qu’avec le cœur. L’essentiel est invisible pour les yeux. » — Antoine de Saint-Exupéry',
  '« Un voyage de mille lieues commence toujours par un premier pas. » — Lao Tseu',
  '« N’attends pas l’occasion, crée-la. » — George Bernard Shaw',
  '« Fais de ta vie un rêve, et d’un rêve une réalité. » — Antoine de Saint-Exupéry',
  '« Le courage n’est pas l’absence de peur, mais la capacité de la vaincre. » — Nelson Mandela',
];
export const FACTS = [
  'Les poulpes ont trois cœurs et du sang bleu. 🐙',
  'Le miel ne périme jamais : on en a retrouvé de comestible dans des tombes égyptiennes. 🍯',
  'Les bananes sont légèrement radioactives (à cause du potassium), mais totalement inoffensives. 🍌',
  'Un jour sur Vénus dure plus longtemps qu’une année vénusienne. 🪐',
  'Les loutres se tiennent la main en dormant pour ne pas se perdre. 🦦',
  'La tour Eiffel grandit d’environ 15 cm en été à cause de la dilatation du métal. 🗼',
  'Les chats ne peuvent pas goûter le sucré. 🐱',
  'Le cœur d’une crevette est situé dans sa tête. 🦐',
  'Il y a plus d’étoiles dans l’univers que de grains de sable sur Terre. ✨',
  'Un flamant rose est rose grâce à son alimentation riche en caroténoïdes. 🦩',
  'L’eau chaude peut geler plus vite que l’eau froide : c’est l’effet Mpemba. 🧊',
  'Les koalas ont des empreintes digitales presque identiques à celles des humains. 🐨',
];
export const TRUTHS = [
  'Quelle est la chose la plus gênante qui te soit arrivée en public ?',
  'Quel est ton plus grand rêve secret ?',
  'Quelle est la dernière chose que tu as cherchée sur Google ?',
  'Quel est le dernier mensonge que tu as dit ?',
  'Quel talent caché aimerais-tu avoir ?',
  'Quelle est ta plus grande peur ?',
  'Quelle chanson écoutes-tu en cachette en ayant un peu honte ?',
  'Quel est ton plus vieux souvenir ?',
  'Qui est la dernière personne à qui tu as pensé avant de dormir ?',
  'Quelle est la pire idée que tu aies jamais eue ?',
  'Quel est le cadeau le plus nul que tu aies reçu ?',
  'Si tu pouvais changer une chose chez toi, ce serait quoi ?',
];
export const DARES = [
  'Envoie un vocal où tu chantes le refrain de ta chanson préférée. 🎤',
  'Change ta photo de profil pour une photo de chat pendant 1 heure. 🐱',
  'Écris un poème de 4 lignes sur la dernière personne qui t’a écrit.',
  'Imite un animal pendant 10 secondes en vocal. 🐸',
  'Raconte une blague nulle et assume-la.',
  'Envoie le dernier emoji que tu as utilisé, et invente une histoire avec.',
  'Parle avec une voix de robot pendant les 3 prochains messages. 🤖',
  'Écris ton prénom avec le coude. 😂',
  'Donne un compliment sincère à la dernière personne qui a parlé.',
  'Fais 10 squats et envoie « fait ! » 💪',
  'Mets ton statut en « Je suis une licorne » pendant 1 heure. 🦄',
  'Décris ta journée uniquement avec des emojis.',
];
export const EIGHTBALL = [
  'Oui, absolument ! ✨', 'C’est certain.', 'Sans aucun doute !', 'Tout me porte à croire que oui.',
  'Les signes sont favorables 🌟', 'Mmh, peut-être…', 'Redemande-moi plus tard 🔮', 'Je ne peux pas te le dire maintenant.',
  'Je ne parierais pas dessus.', 'Franchement, non.', 'Mes sources disent non.', 'Très improbable 😬',
];
export const COMPLIMENTS = [
  'Ton sourire illumine toutes les conversations ✨', 'Tu as une énergie vraiment contagieuse 😄',
  'Tu es plus intelligent(e) que tu ne le crois 🧠', 'Franchement, tu es quelqu’un de précieux 💫',
  'On a de la chance de t’avoir dans le coin 🌟', 'Ta bonne humeur est un super-pouvoir ⚡',
  'Tu as un style de dingue 😎', 'Tu rends la vie des autres plus douce 🤗',
];
export const ROASTS = [
  'Tu es la preuve que même le Wi-Fi peut être lent à comprendre. 🐌',
  'Si la lenteur était un sport, tu serais déjà en retard à la finale. 🏁',
  'Ton sens de l’orientation est tellement bon que Google Maps a démissionné. 🗺️',
  'Tu as le charisme d’une notification « batterie faible ». 🔋',
  'Tu es comme un lundi : personne ne t’attend, mais tu arrives quand même. 😅',
  'Même ton ombre te demande de marcher plus vite. 🌚',
  '(Tout ça c’est pour rire, hein, je t’adore 😘)',
];
export const RIDDLES = [
  { q: 'Plus je sèche, plus je suis mouillée. Qui suis-je ?', a: 'une serviette' },
  { q: 'Je commence la nuit et je finis le matin, mais je ne suis pas dans le jour. Qui suis-je ?', a: 'la lettre n' },
  { q: 'Qu’est-ce qui a des dents mais ne mord jamais ?', a: 'un peigne' },
  { q: 'Qu’est-ce qui monte et ne redescend jamais ?', a: 'l’âge' },
  { q: 'J’ai des villes mais pas de maisons, des forêts mais pas d’arbres, de l’eau mais pas de poissons. Qui suis-je ?', a: 'une carte' },
  { q: 'Plus on en prend, plus on en laisse derrière soi. Qu’est-ce que c’est ?', a: 'des pas' },
  { q: 'Qu’est-ce qui peut voyager autour du monde en restant dans un coin ?', a: 'un timbre' },
  { q: 'Je parle sans bouche et j’entends sans oreilles. Qui suis-je ?', a: 'un écho' },
];
export const ACTIVITIES = [
  'Fais une liste de 5 choses qui te rendent heureux(se) 📝', 'Appelle quelqu’un que tu n’as pas vu depuis longtemps 📞',
  'Apprends un nouveau mot dans une autre langue 🌍', 'Fais une mini-séance d’étirements de 5 minutes 🧘',
  'Dessine quelque chose, même n’importe quoi 🎨', 'Mets ta chanson préférée et danse comme si personne ne regardait 💃',
  'Prépare-toi un chocolat chaud ☕', 'Range un tiroir (juste un !) 🗂️', 'Écris une lettre à toi-même dans 1 an ✉️',
  'Regarde un documentaire sur un sujet que tu ne connais pas 🎬', 'Joue à /pendu ou /quiz avec moi 🎮',
  'Fais une balade de 15 minutes 🚶', 'Cuisine une recette que tu n’as jamais essayée 🍳',
];
export const MOTIVATION = [
  'Tu n’as pas besoin d’être parfait(e), juste de continuer. 💪', 'Un petit pas aujourd’hui vaut mieux qu’un grand pas jamais. 🌱',
  'Tu es capable de bien plus que ce que tu crois. ✨', 'Les difficultés d’aujourd’hui sont la force de demain. 🔥',
  'Respire. Tu as déjà surmonté 100 % de tes pires journées. 🌈', 'Crois en toi, je crois en toi ! 💫',
];
export const WORDS = [
  'ordinateur', 'telegram', 'chocolat', 'montagne', 'bibliotheque', 'papillon', 'aventure', 'univers', 'guitare', 'elephant',
  'tournesol', 'parapluie', 'restaurant', 'lumiere', 'musique', 'voyage', 'tempete', 'forteresse', 'dragon', 'licorne',
  'fromage', 'baguette', 'ocean', 'plage', 'vacances', 'cinema', 'football', 'basketball', 'internet', 'programme',
  'clavier', 'bouteille', 'fenetre', 'nuage', 'oiseau', 'banane', 'fraise', 'pomme', 'cerise', 'soleil', 'planete',
];
export const QUIZ = [
  { q: 'Quelle est la capitale de l’Australie ?', o: ['Sydney', 'Canberra', 'Melbourne', 'Perth'], c: 1 },
  { q: 'Combien y a-t-il de continents ?', o: ['5', '6', '7', '8'], c: 2 },
  { q: 'Quel est le plus grand océan ?', o: ['Atlantique', 'Indien', 'Arctique', 'Pacifique'], c: 3 },
  { q: 'Qui a peint la Joconde ?', o: ['Michel-Ange', 'Léonard de Vinci', 'Raphaël', 'Picasso'], c: 1 },
  { q: 'Quel est le symbole chimique de l’or ?', o: ['Ag', 'Au', 'Or', 'Fe'], c: 1 },
  { q: 'Quelle planète est surnommée la planète rouge ?', o: ['Vénus', 'Jupiter', 'Mars', 'Saturne'], c: 2 },
  { q: 'Combien de côtés a un hexagone ?', o: ['5', '6', '7', '8'], c: 1 },
  { q: 'Quel pays a la forme d’une botte ?', o: ['Espagne', 'Grèce', 'Italie', 'Portugal'], c: 2 },
  { q: 'Quel est le plus long fleuve d’Afrique ?', o: ['Congo', 'Niger', 'Nil', 'Zambèze'], c: 2 },
  { q: 'Quelle est la capitale du Congo-Brazzaville ?', o: ['Kinshasa', 'Brazzaville', 'Pointe-Noire', 'Libreville'], c: 1 },
  { q: 'Qui a écrit « Les Misérables » ?', o: ['Zola', 'Balzac', 'Victor Hugo', 'Molière'], c: 2 },
  { q: 'Combien font 12 × 12 ?', o: ['124', '144', '122', '154'], c: 1 },
  { q: 'Quel animal est le plus rapide sur terre ?', o: ['Lion', 'Guépard', 'Cheval', 'Antilope'], c: 1 },
  { q: 'En quelle année l’homme a-t-il marché sur la Lune ?', o: ['1965', '1969', '1972', '1975'], c: 1 },
  { q: 'Quel est le plus petit nombre premier ?', o: ['0', '1', '2', '3'], c: 2 },
  { q: 'Quelle langue compte le plus de locuteurs natifs ?', o: ['Anglais', 'Espagnol', 'Mandarin', 'Hindi'], c: 2 },
];
export const SIGNS = {
  belier: '♈ Bélier', taureau: '♉ Taureau', gemeaux: '♊ Gémeaux', cancer: '♋ Cancer', lion: '♌ Lion', vierge: '♍ Vierge',
  balance: '♎ Balance', scorpion: '♏ Scorpion', sagittaire: '♐ Sagittaire', capricorne: '♑ Capricorne', verseau: '♒ Verseau', poissons: '♓ Poissons',
};
export const HORO_PARTS = {
  a: ['Aujourd’hui', 'Cette journée', 'Les astres annoncent que ta journée', 'L’énergie du moment'],
  b: ['sera pleine de surprises', 't’apportera de la douceur', 'te poussera à oser', 'favorisera tes rencontres', 'demandera un peu de patience', 'sera propice aux projets'],
  c: ['Fais confiance à ton intuition.', 'Un message inattendu pourrait arriver.', 'Prends du temps pour toi ce soir.', 'Souris, ça aide toujours.', 'Ne remets pas à demain ce qui te tient à cœur.', 'Une bonne nouvelle approche.'],
};
export const PICKUP = [
  'Tu crois au coup de foudre, ou je dois repasser devant toi ? ⚡', 'Il paraît que le soleil est loin… pourtant tu me réchauffes déjà ☀️',
  'Tu as un plan pour ce soir ? Parce que moi je cherche juste ton prochain message 😉', 'Si tu étais un fruit, tu serais une chaaaarmante pastèque 🍉 (oui je sais, c’était nul)',
  'On s’est déjà parlé ? Parce que j’ai l’impression de te connaître depuis toujours ✨',
];
