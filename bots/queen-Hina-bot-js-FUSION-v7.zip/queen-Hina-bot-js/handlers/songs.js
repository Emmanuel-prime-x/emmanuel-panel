// Ma chanson : envoie TES propres morceaux (fichiers dans media/songs/ ou audios enregistrés avec /addsong).
import fs from 'node:fs';
import path from 'node:path';
import { SONGS_DIR } from '../config.js';
import * as store from '../store.js';
import { listFiles, sendLocal, AUDIO_EXT, MAX_UPLOAD } from '../media.js';
import { esc, normalize, pick, truncate } from '../util.js';
import { hooks } from '../router.js';

function allSongs() {
  const disk = listFiles(SONGS_DIR, AUDIO_EXT).map((file) => ({
    kind: 'disk', file, title: path.basename(file, path.extname(file)).replace(/[_]+/g, ' '),
  }));
  const saved = store.db.songs.map((s, i) => ({ kind: 'saved', idx: i, ...s }));
  return [...disk, ...saved];
}

async function sendSong(ctx, s) {
  await ctx.tg.typing(ctx.chat.id, 'upload_voice', ctx.thread);
  const caption = `🎵 <b>${esc(s.title)}</b>`;
  if (s.kind === 'disk') {
    const kind = ['.ogg', '.oga', '.opus'].includes(path.extname(s.file).toLowerCase()) ? 'audio' : 'audio';
    return sendLocal(ctx, kind, s.file, { caption, title: s.title, performer: 'Professor Emmanuel X' });
  }
  const method = s.sendAs || (s.type === 'voice' ? 'voice' : s.type === 'document' ? 'document' : s.type === 'video' ? 'video' : 'audio');
  return ctx.media(method, s.file_id, { caption });
}

function findSong(list, query) {
  const q = query.trim();
  if (/^\d+$/.test(q)) return list[parseInt(q, 10) - 1] || null;
  const nq = normalize(q);
  return list.find((s) => normalize(s.title) === nq) || list.find((s) => normalize(s.title).includes(nq)) || null;
}

export const defs = [
  {
    name: 'chanson', aliases: ['song', 'ma_chanson', 'musique'], cat: '🎵 Musique', cooldown: 4000,
    desc: 'envoie ma chanson (/chanson 2 ou /chanson nom)',
    async run(ctx) {
      const list = allSongs();
      if (list.length === 0) {
        return ctx.reply(ctx.isOwner
          ? '🎵 Aucune chanson pour l’instant.\n\nDeux façons d’en ajouter :\n1) Envoie-moi un fichier audio puis réponds-y avec <code>/addsong Titre</code>\n2) Mets tes fichiers .mp3 dans le dossier <code>media/songs/</code> du bot'
          : '🎵 Mon créateur n’a pas encore ajouté de chanson.');
      }
      let s;
      if (ctx.args) {
        s = findSong(list, ctx.args);
        if (!s) return ctx.reply(`Je ne trouve pas « ${esc(truncate(ctx.args, 40))} ». Tape /chansons pour voir la liste.`);
      } else s = list.length === 1 ? list[0] : pick(list);
      try {
        await sendSong(ctx, s);
      } catch (e) {
        console.warn('[chanson]', e.message);
        if (/too big|too large/i.test(e.message)) return ctx.reply('Ce fichier dépasse 50 Mo, la limite de Telegram pour un bot. Compresse-le en mp3 😉');
        if (s.kind === 'saved' && /wrong file|file_id|wrong remote/i.test(e.message)) return ctx.reply('Ce morceau n’est plus disponible chez Telegram, ré-ajoute-le avec /addsong.');
        throw e;
      }
    },
  },
  {
    name: 'chansons', aliases: ['songs', 'playlist'], cat: '🎵 Musique', desc: 'liste de mes chansons',
    run(ctx) {
      const list = allSongs();
      if (!list.length) return ctx.reply('🎵 Aucune chanson ajoutée pour l’instant.');
      const lines = list.slice(0, 60).map((s, i) => `${i + 1}. ${esc(truncate(s.title, 50))}`);
      return ctx.reply(`🎶 <b>Playlist</b> (${list.length})\n${lines.join('\n')}\n\nEnvoie /chanson &lt;numéro ou nom&gt;`);
    },
  },
  {
    name: 'addsong', aliases: ['ajoutchanson'], cat: '🎵 Musique', owner: true, desc: '(owner) ajoute un audio : réponds à un fichier audio',
    async run(ctx) {
      const src = ctx.msg.reply_to_message || ctx.msg;
      const media = src.audio || src.voice || (src.document && /audio|ogg|mpeg/i.test(src.document.mime_type || '') ? src.document : null) || src.video;
      if (!media) return ctx.reply('Réponds à un message contenant un <b>fichier audio</b> avec <code>/addsong Titre</code> (ou envoie l’audio avec cette commande en légende).');
      if (media.file_size && media.file_size > MAX_UPLOAD) return ctx.reply('Fichier trop gros (50 Mo max pour un bot).');
      const type = src.audio ? 'audio' : src.voice ? 'voice' : src.video ? 'video' : 'document';
      const title = (ctx.args || media.title || (media.file_name || '').replace(/\.[^.]+$/, '') || `Chanson ${store.db.songs.length + 1}`).slice(0, 80);
      store.db.songs.push({ title, file_id: media.file_id, type, addedAt: Date.now() });
      store.save();
      return ctx.reply(`✅ « ${esc(title)} » ajoutée (n°${allSongs().length}). Teste avec /chanson`);
    },
  },
  {
    name: 'delsong', aliases: ['supprchanson'], cat: '🎵 Musique', owner: true, desc: '(owner) supprime une chanson ajoutée',
    run(ctx) {
      const list = allSongs();
      const s = ctx.args ? findSong(list, ctx.args) : null;
      if (!s) return ctx.reply('Usage : /delsong &lt;numéro ou nom&gt; (voir /chansons)');
      if (s.kind === 'disk') return ctx.reply('Ce morceau vient du dossier <code>media/songs/</code> : supprime le fichier directement sur le panel.');
      store.db.songs.splice(s.idx, 1);
      store.save();
      return ctx.reply(`🗑️ « ${esc(s.title)} » supprimée.`);
    },
  },
];

// Le propriétaire envoie un audio en privé sans commande : on lui explique comment l'enregistrer.
hooks.push(async (ctx) => {
  if (!ctx.isOwner || !ctx.isPrivate) return false;
  const m = ctx.msg;
  if (!(m.audio || m.voice)) return false;
  await ctx.reply('🎵 Joli ! Pour l’enregistrer comme chanson, réponds à ce message avec <code>/addsong Titre</code>.');
  return true;
});
export default defs;
