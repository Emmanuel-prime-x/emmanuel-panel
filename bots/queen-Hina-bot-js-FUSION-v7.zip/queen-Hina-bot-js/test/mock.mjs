// Faux serveur Telegram + nekos.best + IA pour tester le bot hors ligne.
import http from 'node:http';

export function startMock() {
  const state = {
    calls: [], queue: [], waiters: [], msgId: 100, updateId: 1,
    ai: 'ok', nekos: 'ok', failUpdates: 0, conflictUpdates: 0, fail429Once: new Set(), aiCalls: 0,
    admins: new Set([1, 10, 99]), // 1 = owner, 10 = admin, 99 = admin cible
  };
  const json = (res, code, obj) => { res.writeHead(code, { 'content-type': 'application/json' }); res.end(JSON.stringify(obj)); };
  const server = http.createServer((req, res) => {
    const chunks = [];
    req.on('data', (c) => chunks.push(c));
    req.on('end', async () => {
      const raw = Buffer.concat(chunks);
      const url = req.url;
      const port = server.address().port;
      try {
        if (url.startsWith('/nekos/')) {
          if (state.nekos === 'down') return json(res, 503, { error: 'down' });
          const cat = url.split('/')[2].split('?')[0];
          return json(res, 200, { results: [{ url: `http://127.0.0.1:${port}/img/${cat}.gif`, anime_name: 'Test Anime' }] });
        }
        if (url.startsWith('/ai/models')) {
          return json(res, 200, { data: [
            { id: 'bad/chat:free', name: 'Bad Chat', context_length: 128000, pricing: { prompt: '0', completion: '0' }, architecture: { output_modalities: ['text'] } },
            { id: 'meta-llama/llama-guard-4:free', name: 'Llama Guard', context_length: 200000, pricing: { prompt: '0', completion: '0' }, architecture: { output_modalities: ['text'] } },
            { id: 'down/chat:free', name: 'Down Chat', context_length: 100000, pricing: { prompt: '0', completion: '0' }, architecture: { output_modalities: ['text'] } },
            { id: 'paid/model', name: 'Paid', context_length: 100000, pricing: { prompt: '0.01', completion: '0.01' }, architecture: { output_modalities: ['text'] } },
            { id: 'good/chat:free', name: 'Good Chat', context_length: 32000, pricing: { prompt: '0', completion: '0' }, architecture: { output_modalities: ['text'] } },
          ] });
        }
        if (url.startsWith('/ai/chat/completions')) {
          state.aiCalls += 1;
          let reqModel = ''; try { const b = JSON.parse(raw.toString()); reqModel = b.model || ''; state.lastAiBody = b; } catch { /* ignore */ }
          state.modelCalls = state.modelCalls || {}; state.modelCalls[reqModel] = (state.modelCalls[reqModel] || 0) + 1;
          if (reqModel.startsWith('bad/')) return json(res, 200, { choices: [{ message: { content: 'User Safety: safe' } }] });
          if (reqModel.startsWith('down/')) return json(res, 500, { error: { message: 'upstream down' } });
          if (reqModel.startsWith('meta-llama/llama-guard') || reqModel.startsWith('paid/')) return json(res, 500, { error: { message: 'ne devrait pas être appelé' } });
          if (state.ai === '429day') return json(res, 429, { error: { message: 'Rate limit exceeded: free-models-per-day' } });
          if (state.ai === '500') return json(res, 500, { error: { message: 'boom' } });
          if (state.ai === 'empty') return json(res, 200, { choices: [{ message: { content: '' } }] });
          if (state.ai === 'hang') return; // ne répond jamais
          return json(res, 200, { choices: [{ message: { content: 'Salut mon cœur ✨ **test**' } }] });
        }
        const m = url.match(/^\/tg\/bot[^/]+\/(\w+)/);
        if (!m) return json(res, 404, { ok: false });
        const method = m[1];
        let params = {};
        const ct = req.headers['content-type'] || '';
        let upload = null;
        if (ct.includes('multipart')) {
          const s = raw.toString('latin1');
          const re = /name="([^"]+)"(?:; filename="([^"]+)")?\r\n(?:Content-Type: [^\r\n]+\r\n)?\r\n([\s\S]*?)\r\n--/g;
          let mm;
          while ((mm = re.exec(s))) { if (mm[2]) upload = { field: mm[1], filename: mm[2], size: mm[3].length }; else params[mm[1]] = mm[3]; }
          if (params.chat_id) params.chat_id = Number(params.chat_id);
        } else if (raw.length) params = JSON.parse(raw.toString());
        if (method !== 'getUpdates') state.calls.push({ method, params, upload, t: Date.now() });
        const ok = (result) => json(res, 200, { ok: true, result });
        switch (method) {
          case 'getMe': return ok({ id: 999, is_bot: true, first_name: 'Queen Hina', username: 'QueenHinaBot' });
          case 'getUpdates': {
            if (state.conflictUpdates > 0) { state.conflictUpdates -= 1; return json(res, 409, { ok: false, error_code: 409, description: 'Conflict: terminated by other getUpdates request' }); }
            if (state.failUpdates > 0) { state.failUpdates -= 1; return json(res, 502, { ok: false, error_code: 502, description: 'Bad Gateway' }); }
            const off = params.offset || 0;
            state.queue = state.queue.filter((u) => u.update_id >= off);
            if (state.queue.length) return ok(state.queue.splice(0, state.queue.length));
            const timer = setTimeout(() => { state.waiters = state.waiters.filter((w) => w !== done); ok([]); }, 1500);
            const done = () => { clearTimeout(timer); ok(state.queue.splice(0, state.queue.length)); };
            state.waiters.push(done);
            return null;
          }
          case 'sendMessage': {
            if (params.parse_mode === 'HTML' && /<b>unclosed/.test(params.text)) return json(res, 400, { ok: false, error_code: 400, description: "Bad Request: can't parse entities: Can't find end tag corresponding to start tag \"b\"" });
            if (state.fail429Once.has(params.chat_id)) { state.fail429Once.delete(params.chat_id); return json(res, 429, { ok: false, error_code: 429, description: 'Too Many Requests', parameters: { retry_after: 1 } }); }
            if (params.reply_parameters?.message_id === 424242) return json(res, 400, { ok: false, error_code: 400, description: 'Bad Request: message to be replied not found' });
            return ok({ message_id: ++state.msgId, chat: { id: params.chat_id }, text: params.text });
          }
          case 'sendDice': return ok({ message_id: ++state.msgId, chat: { id: params.chat_id }, dice: { emoji: params.emoji, value: 64 } });
          case 'getChatMember': return ok({ status: params.user_id === 999 ? 'administrator' : state.admins.has(params.user_id) ? 'administrator' : 'member', user: { id: params.user_id } });
          case 'banChatMember': if (params.user_id === 99) return json(res, 400, { ok: false, error_code: 400, description: "Bad Request: can't remove chat owner" }); return ok(true);
          case 'sendAudio': return ok({ message_id: ++state.msgId, chat: { id: params.chat_id }, audio: { file_id: `AUDIO_${state.msgId}` } });
          case 'sendPhoto': return ok({ message_id: ++state.msgId, chat: { id: params.chat_id }, photo: [{ file_id: `PHOTO_${state.msgId}` }] });
          case 'sendDocument': case 'sendAnimation': case 'sendVideo': case 'sendVoice': return ok({ message_id: ++state.msgId, chat: { id: params.chat_id }, document: { file_id: `DOC_${state.msgId}` } });
          default: return ok(method.startsWith('send') ? { message_id: ++state.msgId, chat: { id: params.chat_id } } : true);
        }
      } catch (e) { return json(res, 500, { ok: false, description: String(e) }); }
    });
  });
  const inject = (u) => { state.queue.push({ update_id: state.updateId++, ...u }); const w = state.waiters.shift(); if (w) w(); };
  return new Promise((resolve) => server.listen(0, '127.0.0.1', () => resolve({ server, state, port: server.address().port, inject })));
}
