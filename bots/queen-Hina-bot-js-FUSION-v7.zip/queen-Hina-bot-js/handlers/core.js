import path from 'node:path';
import { BOT_NAME, OWNER_NAME, OWNER_TELEGRAM, PHOTOS_DIR, TIMEZONE } from '../config.js';
import * as store from '../store.js';
import { defs as allDefs } from '../router.js';
import { listFiles, sendLocal, PHOTO_EXT } from '../media.js';
import { esc, fmtDuration, mentionHtml, userName } from '../util.js';
import { hasProvider } from '../ai.js';

const VERSION = '2.0';

function categories() {
  const map = new Map();
  for (const d of allDefs) {
    if (d.hidden) continue;
    if (!map.has(d.cat)) map.set(d.cat, []);
    map.get(d.cat).push(d);
  }
  return [...map.entries()];
}

function homeText() {
  const cats = categories();
  const total = cats.reduce((n, [, l]) => n + l.length, 0);
  return `👑 <b>${esc(BOT_NAME)}</b> — menu\n\n${total} commandes réparties en ${cats.length} catégories.\nUtilise <code>/</code> <code>.</code> ou <code>!</code> devant chaque commande (ex : <code>.kiss</code> <code>.hug</code>).\n\n💬 Parle-moi simplement en privé, ou mentionne-moi dans un groupe.\n\n👇 Choisis une catégorie :`;
}
function homeKeyboard() {
  const cats = categories();
  const rows = [];
  for (let i = 0; i < cats.length; i += 2) {
    rows.push(cats.slice(i, i + 2).map(([name, l], k) => ({ text: `${name} (${l.length})`, callback_data: `m:${i + k}` })));
  }
  return { inline_keyboard: rows };
}
function catText(i) {
  const cats = categories();
  const entry = cats[i];
  if (!entry) return null;
  const [name, list] = entry;
  const lines = list.map((d) => `/${d.name} — ${esc(d.desc || '')}`);
  return `<b>${esc(name)}</b>\n\n${lines.join('\n')}`;
}
const backKb = { inline_keyboard: [[{ text: '⬅️ Retour au menu', callback_data: 'm:home' }]] };

export async function handleCallback(tg, cq) {
  try { await tg.call('answerCallbackQuery', { callback_query_id: cq.id }, { retries: 1, timeout: 8000 }); } catch { /* ignore */ }
  const data = cq.data || '';
  const msg = cq.message;
  if (!msg || !data.startsWith('m:')) return;
  const key = data.slice(2);
  if (key === 'home') return tg.editText(msg.chat.id, msg.message_id, homeText(), { reply_markup: homeKeyboard() });
  const text = catText(parseInt(key, 10));
  if (text) await tg.editText(msg.chat.id, msg.message_id, text, { reply_markup: backKb });
}

async function sendMenu(ctx) {
  await ctx.reply(homeText(), { reply_markup: homeKeyboard() });
}

export const defs = [
  {
    name: 'start', cat: '🏠 Général', desc: 'démarrer', cooldown: 3000,
    async run(ctx) {
      const caption = `Coucou ${esc(ctx.name)} ✨\nJe suis <b>${esc(BOT_NAME)}</b>, ta compagne virtuelle : je discute, je te fais rire, je t’envoie des réactions animées, des jeux, de la musique et plein d’outils.\n\nTape /menu pour tout découvrir, ou parle-moi directement 💫`;
      const photo = listFiles(PHOTOS_DIR, PHOTO_EXT)[0];
      if (photo) {
        try { await sendLocal(ctx, 'photo', photo, { caption, reply_markup: { inline_keyboard: [[{ text: '📖 Menu', callback_data: 'm:home' }]] } }); return; } catch (e) { console.warn('[start] photo:', e.message); }
      }
      await ctx.reply(caption, { reply_markup: { inline_keyboard: [[{ text: '📖 Menu', callback_data: 'm:home' }]] } });
    },
  },
  { name: 'menu', aliases: ['help', 'aide', 'commandes', 'cmds'], cat: '🏠 Général', desc: 'afficher le menu des commandes', run: sendMenu },
  {
    name: 'ping', cat: '🏠 Général', desc: 'vitesse de réponse',
    async run(ctx) {
      const t0 = Date.now();
      const m = await ctx.reply('🏓 …');
      const ms = Date.now() - t0;
      if (m?.message_id) await ctx.tg.editText(ctx.chat.id, m.message_id, `🏓 Pong ! <b>${ms} ms</b>`).catch(() => {});
    },
  },
  {
    name: 'alive', aliases: ['bot', 'status'], cat: '🏠 Général', desc: 'état du bot', cooldown: 3000,
    async run(ctx) {
      const mem = Math.round(process.memoryUsage().rss / 1048576);
      const txt = `✅ <b>${esc(BOT_NAME)}</b> est en ligne !\n⏱️ En ligne depuis : ${fmtDuration(process.uptime())}\n🧠 IA : ${hasProvider() ? 'activée' : 'non configurée'}\n💾 Mémoire : ${mem} Mo\n🔖 Version : ${VERSION}`;
      const photo = listFiles(PHOTOS_DIR, PHOTO_EXT)[0];
      if (photo) { try { await sendLocal(ctx, 'photo', photo, { caption: txt }); return; } catch { /* texte */ } }
      await ctx.reply(txt);
    },
  },
  { name: 'runtime', aliases: ['uptime'], cat: '🏠 Général', desc: 'durée de fonctionnement', run: (ctx) => ctx.reply(`⏱️ En ligne depuis <b>${fmtDuration(process.uptime())}</b>`) },
  {
    name: 'owner', aliases: ['createur', 'creator'], cat: '🏠 Général', desc: 'mon créateur',
    run: (ctx) => ctx.reply(`👑 Mon créateur : <b>${esc(OWNER_NAME)}</b>\n${esc(OWNER_TELEGRAM)}`),
  },
  {
    name: 'about', aliases: ['apropos', 'info'], cat: '🏠 Général', desc: 'à propos de moi',
    run: (ctx) => ctx.reply(`💫 <b>${esc(BOT_NAME)}</b> v${VERSION}\nCompagne virtuelle IA, créée par ${esc(OWNER_NAME)}.\nFuseau : ${esc(TIMEZONE)}\n\nJe suis une IA : je discute, je joue, je t’aide au quotidien. Tape /menu !`),
  },
  {
    name: 'id', cat: '🏠 Général', desc: 'ton ID Telegram (et celui du chat)',
    run(ctx) {
      const lines = [`🆔 Ton ID : <code>${ctx.from.id}</code>`, `💬 ID du chat : <code>${ctx.chat.id}</code>`];
      if (ctx.target) lines.push(`👤 ID de ${esc(userName(ctx.target))} : <code>${ctx.target.id}</code>`);
      if (ctx.isOwner) lines.push('👑 Tu es reconnu(e) comme mon créateur.');
      return ctx.reply(lines.join('\n'));
    },
  },
  {
    name: 'profil', aliases: ['me', 'moi', 'whoami'], cat: '🏠 Général', desc: 'ton profil',
    run(ctx) {
      const u = store.db.users[String(ctx.from.id)] || {};
      const e = store.econ(ctx.from.id);
      return ctx.reply(`👤 <b>${mentionHtml(ctx.from)}</b>${ctx.isOwner ? ' 👑' : ''}\n🆔 <code>${ctx.from.id}</code>\n${ctx.from.username ? `🔗 @${esc(ctx.from.username)}\n` : ''}💬 Messages : ${u.msgs || 0}\n🪙 Pièces : ${store.coinsText(ctx.from.id)}`);
    },
  },
  {
    name: 'stats', cat: '🏠 Général', desc: 'statistiques du bot',
    run(ctx) {
      const s = store.db.stats;
      const groups = Object.values(store.db.chats).filter((c) => c.type !== 'private').length;
      return ctx.reply(`📊 <b>Statistiques</b>\n👥 Utilisateurs : ${Object.keys(store.db.users).length}\n🏘️ Groupes : ${groups}\n💬 Messages vus : ${s.messages}\n⌨️ Commandes lancées : ${s.commands}`);
    },
  },
  {
    name: 'reset', aliases: ['oublie', 'nouveau'], cat: '🏠 Général', desc: 'effacer ma mémoire de notre conversation',
    run(ctx) { store.clearHistory(ctx.chat.id); return ctx.reply('🧹 C’est oublié, on repart sur de nouvelles bases ✨'); },
  },
  {
    name: 'photo', aliases: ['selfie'], cat: '📸 Médias', desc: 'une photo de moi', cooldown: 3000,
    async run(ctx) {
      const files = listFiles(PHOTOS_DIR, PHOTO_EXT);
      if (!files.length) return ctx.reply('Je n’ai pas encore de photo à te montrer 🙈');
      await sendLocal(ctx, 'photo', files[Math.floor(Math.random() * files.length)], { caption: `📸 ${esc(BOT_NAME)} ✨` });
    },
  },
];
export default defs;
