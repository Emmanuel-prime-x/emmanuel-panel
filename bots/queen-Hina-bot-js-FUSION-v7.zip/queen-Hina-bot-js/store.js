// Stockage JSON : écriture atomique (fichier temporaire + rename), sauvegarde différée, copie .bak,
// récupération automatique si le fichier est corrompu. Ne lève jamais d'exception vers l'appelant.
import fs from 'node:fs';
import path from 'node:path';
import { DATA_FILE, MAX_HISTORY, isOwner } from './config.js';

const DEFAULTS = () => ({
  users: {},       // id -> {id,name,username,first,last,msgs,persona,mood}
  chats: {},       // id -> {id,type,title,settings:{},members:{uid:{name,username,count,last}}}
  history: {},     // chatId -> [{role,content}]
  reminders: [],   // {id,chatId,userId,at,text}
  notes: {},       // userId -> [{id,text,at}]
  songs: [],       // {id,title,file_id,kind,addedAt}
  songCache: {},   // "fichier|taille|mtime" -> file_id
  blacklist: [],
  econ: {},        // userId -> {coins,lastDaily,lastWork,streak}
  warns: {},       // "chat:user" -> n
  afk: {},         // userId -> {since,reason}
  stars: { total: 0, donors: {}, payments: [] },
  premium: {},     // chat payant : {enabled,price,days,users:{uid:expiration}}
  hina: {},        // état global de Hina : {mood}
  stats: { startedAt: Date.now(), messages: 0, commands: 0 },
});

export let db = DEFAULTS();
let timer = null;
let dirty = false;
let lastBak = 0;
let saving = false;

function mergeDefaults(obj) {
  const d = DEFAULTS();
  for (const k of Object.keys(d)) {
    if (obj[k] === undefined || obj[k] === null || typeof obj[k] !== typeof d[k] || Array.isArray(obj[k]) !== Array.isArray(d[k])) obj[k] = d[k];
  }
  return obj;
}

export function load() {
  fs.mkdirSync(path.dirname(DATA_FILE), { recursive: true });
  for (const file of [DATA_FILE, `${DATA_FILE}.bak`]) {
    try {
      if (!fs.existsSync(file)) continue;
      const parsed = JSON.parse(fs.readFileSync(file, 'utf8'));
      if (parsed && typeof parsed === 'object') {
        db = mergeDefaults(parsed);
        if (file !== DATA_FILE) console.warn('[store] Données restaurées depuis la sauvegarde .bak');
        return;
      }
    } catch (e) {
      console.warn(`[store] Fichier ${path.basename(file)} illisible (${e.message})`);
      try {
        fs.renameSync(file, `${file}.corrupt-${Date.now()}`);
      } catch { /* ignore */ }
    }
  }
  db = DEFAULTS();
}

export function flush() {
  if (!dirty || saving) return;
  saving = true;
  try {
    const tmp = `${DATA_FILE}.tmp`;
    fs.writeFileSync(tmp, JSON.stringify(db));
    if (Date.now() - lastBak > 10 * 60 * 1000 && fs.existsSync(DATA_FILE)) {
      try {
        fs.copyFileSync(DATA_FILE, `${DATA_FILE}.bak`);
        lastBak = Date.now();
      } catch { /* ignore */ }
    }
    fs.renameSync(tmp, DATA_FILE);
    dirty = false;
  } catch (e) {
    console.error('[store] Écriture impossible :', e.message);
  } finally {
    saving = false;
  }
}

export function save() {
  dirty = true;
  if (timer) return;
  timer = setTimeout(() => {
    timer = null;
    flush();
  }, 1500);
  timer.unref?.();
}

// ---------- helpers ----------
export function touchUser(from) {
  if (!from || from.is_bot) return null;
  const id = String(from.id);
  const u = db.users[id] || (db.users[id] = { id: from.id, first: Date.now(), msgs: 0 });
  u.name = from.first_name || from.username || u.name || 'toi';
  u.username = from.username || u.username || null;
  u.last = Date.now();
  u.msgs += 1;
  return u;
}

export function touchChat(chat, from) {
  if (!chat) return null;
  const id = String(chat.id);
  const c = db.chats[id] || (db.chats[id] = { id: chat.id, settings: {}, members: {} });
  c.type = chat.type;
  c.title = chat.title || c.title || null;
  if (from && !from.is_bot && chat.type !== 'private') {
    const keys = Object.keys(c.members);
    if (keys.length > 3000 && !c.members[from.id]) delete c.members[keys[0]];
    const m = c.members[from.id] || (c.members[from.id] = { count: 0 });
    m.name = from.first_name || from.username || 'membre';
    m.username = from.username || null;
    m.count += 1;
    m.last = Date.now();
  }
  return c;
}

export const chatSettings = (chatId) => {
  const c = db.chats[String(chatId)] || (db.chats[String(chatId)] = { id: chatId, settings: {}, members: {} });
  return c.settings;
};
export const setChatSetting = (chatId, patch) => {
  Object.assign(chatSettings(chatId), patch);
  save();
};

export const getHistory = (chatId) => db.history[String(chatId)] || [];
export function pushHistory(chatId, role, content) {
  const key = String(chatId);
  const h = db.history[key] || (db.history[key] = []);
  h.push({ role, content: String(content).slice(0, 1500) });
  while (h.length > MAX_HISTORY) h.shift();
  save();
}
export function clearHistory(chatId) {
  delete db.history[String(chatId)];
  save();
}

// Le propriétaire a des pièces illimitées : son solde est remis au maximum à chaque accès.
export const OWNER_COINS = 1e12;
export const econ = (userId) => {
  const e = db.econ[String(userId)] || (db.econ[String(userId)] = { coins: 100, lastDaily: 0, lastWork: 0, streak: 0 });
  if (isOwner(userId)) e.coins = OWNER_COINS;
  return e;
};
export const coinsText = (userId) => (isOwner(userId) ? '∞' : Number(econ(userId).coins).toLocaleString('fr-FR'));
// Retire n pièces si possible (toujours vrai pour le propriétaire).
export function spend(userId, n) {
  const e = econ(userId);
  if (e.coins < n) return false;
  e.coins -= n; save();
  return true;
}
export function earn(userId, n) { econ(userId).coins += n; save(); }
export const isBlacklisted = (id) => db.blacklist.includes(Number(id));
