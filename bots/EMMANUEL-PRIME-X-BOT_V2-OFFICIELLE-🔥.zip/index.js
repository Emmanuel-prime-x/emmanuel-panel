// libsignal écrit des « Closing session: SessionEntry {...} » énormes (avec les clés privées !) dans la console.
// On les remplace par une seule ligne courte : ça garde la console lisible et évite de fuiter des clés.
try { require('dns').setDefaultResultOrder('ipv4first') } catch {} // évite les « timeout » quand le panel n'a pas d'IPv6 fonctionnel
let sigCount = 0, lastSigErr = 0
for (const k of ['log', 'info', 'warn', 'error']) {
  const orig = console[k].bind(console)
  console[k] = (...a) => {
    const t = typeof a[0] === 'string' ? a[0] : ''
    if (/^(Session error|Failed to decrypt message with any known session|Bad MAC)/.test(t) || /Bad MAC|No matching sessions found/.test(String(a[1] && a[1].message || a[0] && a[0].message || ''))) {
      if (Date.now() - lastSigErr > 60000) { lastSigErr = Date.now(); orig('[signal] erreur de déchiffrement ignorée (Bad MAC / session) : normal juste après un re-pairing ; le message sera renvoyé par WhatsApp')}
      return
    }
    if (/^Closing stale open session/.test(t)) { sigCount++; return orig(`[signal] nouvelle session de chiffrement créée (#${sigCount})`) }
    if (/^(Closing session|Opening session|Removing old closed session|Closing open session|Migrating session|Session already)/.test(t)) return
    orig(...a)
  }
}

const major = Number(process.versions.node.split('.')[0])
if (major < 20) {
  console.error(`❌ Node.js ${process.versions.node} détecté. Il faut Node.js 20 ou plus (22 recommandé).`)
  process.exit(1)
}

process.on('uncaughtException', (e) => console.error('[uncaught]', e))
process.on('unhandledRejection', (e) => console.error('[unhandled]', e))

const fsSync = require('fs')
const pathSync = require('path')

// ---- Tue toute AUTRE copie du bot qui tournerait déjà (même si le panel l'a "supprimée" du disque) ----
// Sur certains panels, "Reinstall"/"Restart" efface les fichiers sans forcément arrêter le process Node déjà
// lancé : ce process zombie garde ses fichiers ouverts en mémoire et continue de répondre avec l'ancien code,
// pendant qu'une nouvelle copie tourne à côté avec le code à jour. Résultat : les correctifs semblent ne
// jamais s'appliquer. On cherche donc, au niveau du système (pas juste un fichier), tout AUTRE process
// "node .../index.js" et on le termine avant de continuer. Ne fonctionne que sur Linux (via /proc), ce que
// sont tous les panels d'hébergement Node (Pterodactyl, Katabump, etc.).
const lockFile = pathSync.join(__dirname, '.bot.lock')
function killOtherInstances() {
  let killed = 0
  try {
    for (const pidStr of fsSync.readdirSync('/proc')) {
      const pid = Number(pidStr)
      if (!pid || pid === process.pid) continue
      let cmdline = ''
      try { cmdline = fsSync.readFileSync(`/proc/${pid}/cmdline`, 'utf8').replace(/\0/g, ' ') } catch { continue }
      if (!/node/.test(cmdline) || !/index\.js/.test(cmdline)) continue
      let cwd = ''
      try { cwd = fsSync.readlinkSync(`/proc/${pid}/cwd`) } catch {}
      // On ne tue que si ça ressemble vraiment à une copie de CE bot (même dossier, ou index.js du même dossier dans la commande)
      if (cwd !== __dirname && !cmdline.includes(__dirname)) continue
      console.error(`⚠️  Ancienne copie du bot détectée et arrêtée automatiquement (PID ${pid}) — c'était probablement elle qui répondait avec l'ancien code.`)
      try { process.kill(pid, 'SIGTERM') } catch {}
      killed++
    }
  } catch {} // /proc absent (pas Linux) : on ne peut pas vérifier, on continue quand même
  return killed
}
const killedCount = killOtherInstances()

function checkLock() {
  fsSync.writeFileSync(lockFile, JSON.stringify({ pid: process.pid, since: Date.now() }))
  const release = () => { try { fsSync.unlinkSync(lockFile) } catch {} }
  process.on('exit', release)
  process.on('SIGINT', () => { release(); process.exit(0) })
  process.on('SIGTERM', () => { release(); process.exit(0) })
}
checkLock()
if (killedCount > 0) console.error(`   (${killedCount} ancienne(s) copie(s) arrêtée(s) — si les commandes ne répondaient pas, ça devrait maintenant marcher)`)

const cfg = require('./config')
const U = require('./lib/utils')
const Y = require('./lib/ytdl')
const telegram = require('./lib/telegram')
const sessions = require('./lib/session')
const registry = require('./lib/registry')

;(async () => {
  let baileysVersion = '?'
  try { baileysVersion = require('@whiskeysockets/baileys/package.json').version } catch {}
  console.log(U.box(U.mono('demarrage'), [
    `${U.mono('bot')} : ${cfg.botName} v${cfg.version}`,
    `${U.mono('node')} : ${process.versions.node}`,
    `${U.mono('baileys')} : ${baileysVersion}`,
    `${U.mono('commandes')} : ${registry.list.length}`,
    `${U.mono('pid')} : ${process.pid}`
  ]))
  console.log('') // si tu vois cette boîte, tu tournes bien avec la dernière version du code

  // yt-dlp : installation + mise à jour en arrière-plan (pour .song, .video, .tiktok ...)
  Y.ensureYtdlp().then(() => Y.updateYtdlp()).catch(() => {})
  setInterval(() => Y.updateYtdlp().catch(() => {}), 12 * 3600 * 1000)

  // Nettoyage du dossier temporaire
  const fs = require('fs')
  const clean = () => { for (const f of fs.readdirSync(cfg.tmpDir)) { try { if (Date.now() - fs.statSync(require('path').join(cfg.tmpDir, f)).mtimeMs > 3600000) fs.rmSync(require('path').join(cfg.tmpDir, f), { force: true }) } catch {} } }
  clean(); setInterval(clean, 1800000)

  // Telegram démarre en arrière-plan : s'il est lent / injoignable, les sessions WhatsApp ne sont PAS retardées
  telegram.start().catch((e) => console.error('[Telegram]', e.message))
  await sessions.restoreAll()
})()
