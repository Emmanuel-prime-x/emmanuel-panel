// Jeux à plusieurs (groupes) : morpion, duel pierre-feuille-ciseaux avec mise, quiz multijoueur,
// tournoi de rapidité, roulette russe. Les parties vivent en mémoire (elles expirent seules).
import { QUIZ, WORDS } from '../content.js';
import { hooks } from '../router.js';
import * as store from '../store.js';
import { esc, shuffle, randInt, normalize, userName, sleep, clamp } from '../util.js';

const G = new Map();
const TTL = 20 * 60 * 1000;
const gid = () => Math.random().toString(36).slice(2, 7);
const touch = (g) => { g.until = Date.now() + TTL; };
const nm = (u) => esc(userName(u));
const brief = (u) => ({ id: u.id, first_name: u.first_name || u.name || 'Joueur', username: u.username });
const active = (chatId, type) => [...G.values()].find((g) => g.chatId === chatId && g.type === type);
function stop(g) { for (const t of g.timers || []) clearTimeout(t); g.timers = []; g.dead = true; G.delete(g.id); }
function later(g, ms, fn) {
  const t = setTimeout(() => { if (!g.dead) fn().catch((e) => console.warn(`[multi:${g.type}]`, e.message)); }, ms);
  (g.timers ||= []).push(t);
}
setInterval(() => { for (const g of G.values()) if (g.until < Date.now()) stop(g); }, 60000).unref();

const edit = (g, text, markup) => g.tg.editText(g.chatId, g.msgId, text, { reply_markup: markup || { inline_keyboard: [] } }).catch((e) => console.warn('[multi] edit:', e.message));
const medal = (i) => ['🥇', '🥈', '🥉'][i] || `${i + 1}.`;
const rank = (scores) => Object.values(scores).sort((a, b) => b.pts - a.pts);

async function create(ctx, g, text, markup) {
  Object.assign(g, { id: gid(), chatId: ctx.chat.id, tg: ctx.tg, thread: ctx.thread, timers: [] });
  touch(g); G.set(g.id, g);
  const m = await ctx.say(text, markup ? { reply_markup: markup } : {});
  g.msgId = m?.message_id;
  return g;
}

// ============ MORPION ============
const LINES = [[0, 1, 2], [3, 4, 5], [6, 7, 8], [0, 3, 6], [1, 4, 7], [2, 5, 8], [0, 4, 8], [2, 4, 6]];
const tttWinner = (b) => { for (const [a, c, d] of LINES) if (b[a] && b[a] === b[c] && b[a] === b[d]) return b[a]; return null; };
function tttView(g, over) {
  const cur = g.turn === 'X' ? g.x : g.o;
  const status = over || (g.o ? `Au tour de ${g.turn === 'X' ? '❌' : '⭕'} <b>${nm(cur)}</b>` : 'Un adversaire ? Appuie sur une case pour rejoindre !');
  const rows = [0, 1, 2].map((r) => [0, 1, 2].map((c) => { const i = r * 3 + c; return { text: g.board[i] === 'X' ? '❌' : g.board[i] === 'O' ? '⭕' : '▫️', callback_data: over ? 'g:done' : `g:ttt:${g.id}:${i}` }; }));
  return { text: `⭕❌ <b>Morpion</b>\n❌ ${nm(g.x)}  vs  ⭕ ${g.o ? nm(g.o) : '<i>en attente…</i>'}\n\n${status}`, markup: { inline_keyboard: rows } };
}
async function tttPress(g, cq, arg) {
  const u = cq.from; const i = parseInt(arg, 10);
  if (!g.o) {
    if (u.id === g.x.id) return 'Attends qu\u2019un adversaire appuie sur une case 😉';
    if (g.want && g.want !== u.id) return 'Cette partie est réservée à quelqu\u2019un d\u2019autre.';
    g.o = brief(u); touch(g);
    const v = tttView(g); await edit(g, v.text, v.markup);
    return 'Tu joues les ⭕ ! ❌ commence.';
  }
  if (u.id !== g.x.id && u.id !== g.o.id) return 'Cette partie oppose deux autres joueurs 😉';
  const cur = g.turn === 'X' ? g.x : g.o;
  if (u.id !== cur.id) return 'Ce n\u2019est pas ton tour !';
  if (!(i >= 0 && i < 9) || g.board[i]) return 'Case déjà prise.';
  g.board[i] = g.turn;
  const w = tttWinner(g.board);
  if (w) {
    const win = w === 'X' ? g.x : g.o; store.earn(win.id, 30); stop(g);
    const v = tttView(g, `🏆 <b>${nm(win)}</b> gagne ! +30 🪙`); await edit(g, v.text, v.markup);
  } else if (g.board.every(Boolean)) {
    store.earn(g.x.id, 5); store.earn(g.o.id, 5); stop(g);
    const v = tttView(g, '🤝 Match nul ! +5 🪙 chacun'); await edit(g, v.text, v.markup);
  } else {
    g.turn = g.turn === 'X' ? 'O' : 'X'; touch(g);
    const v = tttView(g); await edit(g, v.text, v.markup);
  }
  return undefined;
}

// ============ DUEL PIERRE-FEUILLE-CISEAUX ============
const PFC = { p: '🪨', f: '📄', c: '✂️' };
const BEATS = { p: 'c', f: 'p', c: 'f' };
const duelKb = (g) => ({ inline_keyboard: [Object.keys(PFC).map((k) => ({ text: PFC[k], callback_data: `g:duel:${g.id}:${k}` }))] });
const betTxt = (g) => (g.bet ? ` · mise : <b>${g.bet} 🪙</b>` : '');
async function duelPress(g, cq, arg) {
  const u = cq.from;
  if (g.stage === 'invite') {
    if (arg === 'no') {
      if (u.id !== g.a.id && u.id !== g.b.id) return 'Ce défi ne te concerne pas.';
      stop(g); await edit(g, `❌ Défi annulé (${nm(u.id === g.a.id ? g.a : g.b)}).`); return undefined;
    }
    if (u.id !== g.b.id) return u.id === g.a.id ? 'Attends que ton adversaire réponde 😉' : 'Ce défi ne te concerne pas.';
    if (g.bet && store.econ(g.a.id).coins < g.bet) { stop(g); await edit(g, `❌ ${nm(g.a)} n\u2019a plus assez de pièces pour cette mise.`); return undefined; }
    if (g.bet && store.econ(g.b.id).coins < g.bet) return `Tu n\u2019as pas assez de pièces (${g.bet} 🪙 requis).`;
    g.stage = 'play'; touch(g);
    await edit(g, `⚔️ <b>${nm(g.a)}</b> vs <b>${nm(g.b)}</b>${betTxt(g)}\nChoisissez en secret ! ⏳ ⏳`, duelKb(g));
    return 'Défi accepté ! Choisis ton coup.';
  }
  if (u.id !== g.a.id && u.id !== g.b.id) return 'Ce duel ne te concerne pas.';
  if (!PFC[arg]) return undefined;
  g.picks[u.id] = arg; touch(g);
  if (Object.keys(g.picks).length < 2) {
    await edit(g, `⚔️ <b>${nm(g.a)}</b> vs <b>${nm(g.b)}</b>${betTxt(g)}\nChoisissez en secret !\n${nm(g.a)} ${g.picks[g.a.id] ? '✅' : '⏳'}  ·  ${nm(g.b)} ${g.picks[g.b.id] ? '✅' : '⏳'}`, duelKb(g));
    return `Tu as choisi ${PFC[arg]}`;
  }
  const pa = g.picks[g.a.id]; const pb = g.picks[g.b.id];
  stop(g);
  let res = '🤝 Égalité ! Personne ne paie.';
  if (pa !== pb) {
    const win = BEATS[pa] === pb ? g.a : g.b; const lose = win === g.a ? g.b : g.a;
    const amt = g.bet ? Math.min(g.bet, store.econ(lose.id).coins) : 0;
    if (amt > 0) { store.spend(lose.id, amt); store.earn(win.id, amt); }
    res = `🏆 <b>${nm(win)}</b> gagne !${amt ? ` +${amt} 🪙 (pris à ${nm(lose)})` : ''}`;
  }
  await edit(g, `⚔️ <b>Duel</b>\n${nm(g.a)} : ${PFC[pa]}   |   ${nm(g.b)} : ${PFC[pb]}\n\n${res}`);
  return `Tu as choisi ${PFC[arg]}`;
}

// ============ QUIZ MULTIJOUEUR ============
async function qzNext(g) {
  g.i += 1;
  if (g.i >= g.qs.length) return qzFinish(g);
  const q = g.qs[g.i];
  const opts = shuffle(q.o.map((t, k) => ({ t, k })));
  g.correct = opts.findIndex((o) => o.k === q.c); g.opts = opts; g.answered = new Set(); g.firstDone = false; g.open = true; touch(g);
  const kb = { inline_keyboard: [0, 2].map((r) => opts.slice(r, r + 2).map((o, j) => ({ text: o.t, callback_data: `g:qz:${g.id}:${r + j}` }))) };
  const m = await g.tg.sendMessage(g.chatId, `🧠 <b>Question ${g.i + 1}/${g.qs.length}</b>\n${esc(q.q)}\n\n⏱️ 15 secondes — 3 pts au plus rapide, 1 pt aux autres !`, { reply_markup: kb, thread: g.thread });
  g.msgId = m?.message_id;
  later(g, 15000, () => qzReveal(g));
}
async function qzReveal(g) {
  g.open = false;
  const q = g.qs[g.i];
  const top = rank(g.scores).slice(0, 5).map((r, i) => `${medal(i)} ${esc(r.name)} — ${r.pts}`).join('\n');
  await edit(g, `🧠 <b>Question ${g.i + 1}/${g.qs.length}</b>\n${esc(q.q)}\n\n✅ Réponse : <b>${esc(g.opts[g.correct].t)}</b>${top ? `\n\n<b>Classement</b>\n${top}` : ''}`);
  later(g, 3500, () => qzNext(g));
}
async function qzFinish(g) {
  const r = rank(g.scores); const prize = [50, 30, 15];
  const lines = r.slice(0, 10).map((p, i) => { if (i < 3) store.earn(p.id, prize[i]); return `${medal(i)} ${esc(p.name)} — ${p.pts} pts${i < 3 ? ` (+${prize[i]} 🪙)` : ''}`; });
  stop(g);
  await g.tg.sendMessage(g.chatId, `🏁 <b>Quiz terminé !</b>\n${lines.join('\n') || 'Personne n\u2019a marqué de point 😅'}`, { thread: g.thread });
}
async function qzPress(g, cq, arg) {
  if (!g.open) return 'Temps écoulé ⏱️';
  const u = cq.from;
  if (g.answered.has(u.id)) return 'Tu as déjà répondu à cette question.';
  g.answered.add(u.id);
  if (parseInt(arg, 10) !== g.correct) return '❌ Raté…';
  const pts = g.firstDone ? 1 : 3; g.firstDone = true;
  const s = g.scores[u.id] || (g.scores[u.id] = { id: u.id, name: userName(u), pts: 0 }); s.pts += pts;
  return `✅ Bonne réponse ! +${pts} pt${pts > 1 ? 's' : ''}`;
}

// ============ TOURNOI DE RAPIDITÉ ============
function trRound() {
  if (Math.random() < 0.5) {
    const a = randInt(3, 40); const b = randInt(2, 15); const op = ['+', '-', '×'][randInt(0, 2)];
    const ans = op === '+' ? a + b : op === '-' ? a - b : a * b;
    return { kind: 'math', text: `🧮 Combien font <b>${a} ${op} ${b}</b> ?`, ans: String(ans), reveal: String(ans) };
  }
  const w = WORDS.filter((x) => x.length > 4)[randInt(0, WORDS.filter((x) => x.length > 4).length - 1)];
  let s = w; for (let i = 0; i < 10 && s === w; i += 1) s = shuffle([...w]).join('');
  return { kind: 'word', text: `🔀 Remets les lettres dans l\u2019ordre : <b>${esc(s.toUpperCase())}</b>`, ans: normalize(w), reveal: w };
}
async function trNext(g) {
  g.i += 1;
  if (g.i >= g.rounds) return trFinish(g);
  g.cur = trRound(); touch(g);
  await g.tg.sendMessage(g.chatId, `⚡ <b>Manche ${g.i + 1}/${g.rounds}</b>\n${g.cur.text}\n<i>(20 s — écris ta réponse dans le chat)</i>`, { thread: g.thread });
  const round = g.i;
  later(g, 20000, async () => {
    if (g.i !== round || !g.cur) return;
    const c = g.cur; g.cur = null;
    await g.tg.sendMessage(g.chatId, `⏱️ Temps écoulé ! Réponse : <b>${esc(c.reveal)}</b>`, { thread: g.thread });
    later(g, 2000, () => trNext(g));
  });
}
async function trFinish(g) {
  const r = rank(g.scores); const prize = [40, 25, 10];
  const lines = r.slice(0, 10).map((p, i) => { if (i < 3) store.earn(p.id, prize[i]); return `${medal(i)} ${esc(p.name)} — ${p.pts} pt${p.pts > 1 ? 's' : ''}${i < 3 ? ` (+${prize[i]} 🪙)` : ''}`; });
  stop(g);
  await g.tg.sendMessage(g.chatId, `🏁 <b>Tournoi terminé !</b>\n${lines.join('\n') || 'Personne n\u2019a marqué 😅'}`, { thread: g.thread });
}
hooks.push(async (ctx) => {
  const g = ctx.isGroup ? active(ctx.chat.id, 'tr') : null;
  if (!g || !g.cur) return false;
  const t = (ctx.msg.text || '').trim();
  if (!t || t.length > 40) return false;
  const ok = g.cur.kind === 'math' ? t === g.cur.ans : normalize(t) === g.cur.ans;
  if (!ok) return false;
  const c = g.cur; g.cur = null;
  const s = g.scores[ctx.from.id] || (g.scores[ctx.from.id] = { id: ctx.from.id, name: userName(ctx.from), pts: 0 }); s.pts += 1;
  await g.tg.sendMessage(g.chatId, `✅ <b>${esc(ctx.name)}</b> a trouvé : ${esc(c.reveal)} (+1 point)`, { reply_to: ctx.msg.message_id, thread: g.thread });
  later(g, 2000, () => trNext(g));
  return true;
});

// ============ ROULETTE RUSSE ============
const rrKb = (g) => ({ inline_keyboard: [[{ text: `🔫 Rejoindre${g.fee ? ` (${g.fee} 🪙)` : ''}`, callback_data: `g:rr:${g.id}:join` }, { text: '▶️ Lancer', callback_data: `g:rr:${g.id}:go` }]] });
const rrLobby = (g) => `🔫 <b>Roulette russe</b>${g.fee ? ` — mise : <b>${g.fee} 🪙</b>` : ' — gratuite'}\nJoueurs (${g.players.length}/12) : ${g.players.map(nm).join(', ')}\n\nLe dernier survivant remporte la cagnotte ! Départ dans 30 s, ou quand le créateur appuie sur ▶️ (2 joueurs minimum).`;
async function rrStart(g) {
  if (g.started || g.dead) return;
  g.started = true; for (const t of g.timers) clearTimeout(t); g.timers = [];
  if (g.players.length < 2) { stop(g); await edit(g, '🔫 Pas assez de joueurs, partie annulée.'); return; }
  const paid = [];
  for (const p of g.players) { if (!g.fee || store.spend(p.id, g.fee)) paid.push(p); }
  if (paid.length < 2) { for (const p of paid) if (g.fee) store.earn(p.id, g.fee); stop(g); await edit(g, '🔫 Pas assez de joueurs solvables, partie annulée (mises rendues).'); return; }
  const pot = g.fee * paid.length; const alive = [...paid]; const log = [];
  while (alive.length > 1 && !g.dead) {
    await sleep(2500); touch(g);
    const out = alive.splice(randInt(0, alive.length - 1), 1)[0];
    log.push(`💥 ${nm(out)} est éliminé(e)`);
    await edit(g, `🔫 <b>Roulette russe</b>${pot ? ` — cagnotte : ${pot} 🪙` : ''}\n${log.slice(-8).join('\n')}\n\nIl reste ${alive.length} joueur${alive.length > 1 ? 's' : ''}…`);
  }
  const win = alive[0]; if (pot) store.earn(win.id, pot); stop(g);
  await edit(g, `🔫 <b>Roulette russe</b>\n${log.slice(-6).join('\n')}\n\n🏆 <b>${nm(win)}</b> survit et remporte ${pot ? `<b>${pot} 🪙</b>` : 'la gloire'} !`);
}
async function rrPress(g, cq, arg) {
  const u = cq.from;
  if (g.started) return 'La partie a déjà commencé.';
  if (arg === 'go') {
    if (u.id !== g.creator) return 'Seul le créateur peut lancer.';
    if (g.players.length < 2) return 'Il faut au moins 2 joueurs.';
    rrStart(g).catch((e) => console.warn('[rr]', e.message)); return 'C\u2019est parti !';
  }
  if (g.players.some((p) => p.id === u.id)) return 'Tu es déjà dans la partie.';
  if (g.players.length >= 12) return 'La partie est pleine.';
  if (g.fee && store.econ(u.id).coins < g.fee) return `Il te faut ${g.fee} 🪙 pour rejoindre.`;
  g.players.push(brief(u)); touch(g);
  await edit(g, rrLobby(g), rrKb(g));
  return 'Tu es dans la partie 🔫';
}

// ============ routage des boutons ============
async function answer(tg, cq, res) {
  const text = typeof res === 'string' ? res : res?.t;
  await tg.call('answerCallbackQuery', { callback_query_id: cq.id, ...(text ? { text: text.slice(0, 190) } : {}) }, { retries: 1, timeout: 8000 }).catch(() => {});
}
export async function handleGameCallback(tg, cq) {
  const [, type, id, arg] = String(cq.data || '').split(':');
  if (type === 'done') return answer(tg, cq, 'Partie terminée.');
  const g = G.get(id);
  if (!g || !cq.message || cq.message.chat.id !== g.chatId) return answer(tg, cq, 'Cette partie est terminée ou a expiré.');
  let res;
  try {
    if (g.type === 'ttt') res = await tttPress(g, cq, arg);
    else if (g.type === 'duel') res = await duelPress(g, cq, arg);
    else if (g.type === 'qz') res = await qzPress(g, cq, arg);
    else if (g.type === 'rr') res = await rrPress(g, cq, arg);
  } catch (e) { console.warn(`[multi:${g.type}]`, e.message); res = 'Oups, réessaie !'; }
  return answer(tg, cq, res);
}

// ============ commandes ============
const M = { cat: '🎲 Multijoueur', group: true };
export const defs = [
  {
    ...M, name: 'morpion', aliases: ['ttt', 'tictactoe'], desc: 'morpion à 2 (réponds à quelqu\u2019un pour le défier)', cooldown: 3000,
    async run(ctx) {
      const g = { type: 'ttt', board: Array(9).fill(''), x: brief(ctx.from), o: null, want: ctx.target?.id || null, turn: 'X' };
      const v = tttView({ ...g, id: 'x' });
      await create(ctx, g, v.text.replace(/g:ttt:x:/g, ''), null);
      const view = tttView(g); await edit(g, view.text, view.markup);
    },
  },
  {
    ...M, name: 'duel', aliases: ['defi2', 'pfc2'], desc: 'duel pierre-feuille-ciseaux avec mise (réponds + /duel 50)', needsTarget: true, targetHelp: 'Réponds au message de la personne à défier : /duel 50 (mise optionnelle).', cooldown: 4000,
    async run(ctx) {
      if (ctx.target.id === ctx.from.id) return ctx.reply('Tu ne peux pas te défier toi-même 😄');
      const bet = clamp(parseInt(ctx.argv[0], 10) || 0, 0, 100000);
      if (bet && store.econ(ctx.from.id).coins < bet) return ctx.reply('Tu n\u2019as pas assez de pièces pour cette mise 😅');
      const g = { type: 'duel', a: brief(ctx.from), b: brief(ctx.target), bet, stage: 'invite', picks: {} };
      await create(ctx, g, '⚔️ …');
      await edit(g, `⚔️ <b>${nm(g.a)}</b> défie <b>${nm(g.b)}</b> à pierre-feuille-ciseaux !${betTxt(g)}`, { inline_keyboard: [[{ text: '✅ Accepter', callback_data: `g:duel:${g.id}:yes` }, { text: '❌ Refuser', callback_data: `g:duel:${g.id}:no` }]] });
    },
  },
  {
    ...M, name: 'quizmulti', aliases: ['quizgroupe', 'qm'], desc: 'quiz à plusieurs (/quizmulti 5)', cooldown: 5000,
    async run(ctx) {
      if (active(ctx.chat.id, 'qz')) return ctx.reply('Un quiz est déjà en cours ici !');
      const n = clamp(parseInt(ctx.argv[0], 10) || 5, 3, 10);
      const g = { type: 'qz', qs: shuffle(QUIZ).slice(0, n), i: -1, scores: {}, open: false };
      await create(ctx, g, `🧠 <b>Quiz multijoueur</b> — ${n} questions !\nRépondez avec les boutons. Première question dans 4 s…`);
      later(g, 4000, () => qzNext(g));
    },
  },
  {
    ...M, name: 'tournoi', aliases: ['course', 'rapidite'], desc: 'tournoi de rapidité : calcul et mots mélangés (/tournoi 5)', cooldown: 5000,
    async run(ctx) {
      if (active(ctx.chat.id, 'tr')) return ctx.reply('Un tournoi est déjà en cours ici !');
      const n = clamp(parseInt(ctx.argv[0], 10) || 5, 3, 10);
      const g = { type: 'tr', rounds: n, i: -1, scores: {}, cur: null };
      await create(ctx, g, `⚡ <b>Tournoi de rapidité</b> — ${n} manches !\nLe premier à écrire la bonne réponse marque un point. Début dans 4 s…`);
      later(g, 4000, () => trNext(g));
    },
  },
  {
    ...M, name: 'roulette', aliases: ['rr', 'russe'], desc: 'roulette russe à plusieurs (/roulette 20 = mise)', cooldown: 5000,
    async run(ctx) {
      if (active(ctx.chat.id, 'rr')) return ctx.reply('Une roulette est déjà en cours ici !');
      const fee = clamp(parseInt(ctx.argv[0], 10) || (ctx.argv[0] === '0' ? 0 : 20), 0, 10000);
      if (fee && store.econ(ctx.from.id).coins < fee) return ctx.reply('Tu n\u2019as pas assez de pièces pour cette mise 😅');
      const g = { type: 'rr', fee, players: [brief(ctx.from)], creator: ctx.from.id, started: false };
      await create(ctx, g, '🔫 …');
      await edit(g, rrLobby(g), rrKb(g));
      later(g, 30000, () => rrStart(g));
    },
  },
  {
    ...M, name: 'stopjeu', aliases: ['stopgame'], admin: true, desc: '(admin) arrêter les jeux en cours dans ce groupe',
    run(ctx) {
      const list = [...G.values()].filter((g) => g.chatId === ctx.chat.id);
      list.forEach(stop);
      return ctx.reply(list.length ? `🛑 ${list.length} jeu(x) arrêté(s).` : 'Aucun jeu à plusieurs en cours.');
    },
  },
  {
    cat: '🎲 Multijoueur', name: 'jeux', aliases: ['games', 'multijoueur'], desc: 'liste des jeux à plusieurs',
    run: (ctx) => ctx.reply('🎲 <b>Jeux à plusieurs</b> (dans un groupe)\n\n⭕ /morpion — à 2 (réponds à quelqu\u2019un pour le défier)\n⚔️ /duel 50 — pierre-feuille-ciseaux avec mise (réponds à l\u2019adversaire)\n🧠 /quizmulti 5 — quiz, boutons, classement\n⚡ /tournoi 5 — le plus rapide à répondre\n🔫 /roulette 20 — roulette russe, cagnotte\n\nSolo : /pendu /devine /melange /calcul /slot /foot /basket'),
  },
];
export default defs;
