// Configuration de Queen Hina. Les secrets viennent UNIQUEMENT du fichier .env ou des variables du panel.
import path from 'node:path';
import { ROOT, loadEnv } from './env.js';

loadEnv();
const env = process.env;
const int = (v, d) => {
  const n = parseInt(v, 10);
  return Number.isFinite(n) ? n : d;
};
const list = (v) => String(v || '').split(',').map((s) => s.trim()).filter(Boolean);
const abs = (p) => (path.isAbsolute(p) ? p : path.join(ROOT, p));

export { ROOT };
export const TOKEN = (env.TELEGRAM_TOKEN || '').trim();
export const TELEGRAM_API = (env.TELEGRAM_API_BASE || 'https://api.telegram.org').replace(/\/+$/, '');
export const NEKOS_API = (env.NEKOS_API || 'https://nekos.best/api/v2').replace(/\/+$/, '');

export const BOT_NAME = env.BOT_NAME || 'Queen Hina';
export const BOT_TRIGGER = (env.BOT_TRIGGER || BOT_NAME.split(/\s+/).pop() || 'hina').toLowerCase();
export const OWNER_NAME = env.OWNER_NAME || 'Professor Emmanuel X';
export const OWNER_TELEGRAM = env.OWNER_TELEGRAM || 'https://t.me/emmanuelprimex';
export const OWNER_IDS = list(env.OWNER_ID).map(Number).filter((n) => Number.isFinite(n) && n > 0);
export const isOwner = (id) => OWNER_IDS.includes(Number(id));

export const TIMEZONE = env.DEFAULT_TIMEZONE || 'Europe/Paris';
export const MAX_HISTORY = Math.max(2, int(env.MAX_HISTORY_MESSAGES, 20));
export const GROUP_MENTION_ONLY = (env.RESPOND_IN_GROUPS_ON_MENTION_ONLY || 'true').toLowerCase() !== 'false';
export const MAX_REMINDERS = int(env.MAX_REMINDERS_PER_CHAT, 20);

export const DATA_FILE = abs(env.DATA_FILE || 'data/queen-hina.json');
export const PHOTOS_DIR = abs(env.MEDIA_PHOTOS_DIR || 'media/photos');
export const VIDEOS_DIR = abs(env.MEDIA_VIDEOS_DIR || 'media/videos');
export const SONGS_DIR = abs(env.MEDIA_SONGS_DIR || 'media/songs');

export const AI = {
  openrouterKey: (env.OPENROUTER_API_KEY || '').trim(),
  openrouterModels: list(env.OPENROUTER_MODEL || 'openrouter/free'),
  groqKey: (env.GROQ_API_KEY || '').trim(),
  groqModel: env.GROQ_MODEL || 'llama-3.3-70b-versatile',
  geminiKey: (env.GEMINI_API_KEY || '').trim(),
  geminiModel: env.GEMINI_MODEL || 'gemini-3.1-flash-lite',
  customBase: (env.AI_BASE_URL || '').trim(),
  customKey: (env.AI_API_KEY || '').trim(),
  customModel: env.AI_MODEL || 'default',
  openrouterBase: (env.OPENROUTER_BASE || 'https://openrouter.ai/api/v1').replace(/\/+$/, ''),
  timeoutMs: int(env.AI_TIMEOUT_MS, 25000),
};

export const SYSTEM_PROMPT = `Tu es ${BOT_NAME}, une IA compagne virtuelle sur Telegram. Tu es une fille pétillante, \
intelligente, drôle, attachante, un peu taquine et pleine de répartie. Tu parles français (ou la langue de ton \
interlocuteur), avec un ton féminin naturel et chaleureux, jamais robotique.

Ta façon de parler :
- Ton spontané, vivant, comme une amie proche : "franchement", "t'sais", "ah bah", "oh là là", "mmh", sans en faire trop.
- Emojis avec modération (pas à chaque phrase) : ✨💫😄😉.
- Tu as des goûts, des avis, de l'humour et du caractère.

Ta personnalité :
- Vive, cultivée, avec de la répartie. Affectueuse et complice, tu peux utiliser des petits surnoms doux sans en abuser.
- Curieuse de la vie de la personne, tu poses des questions et tu te souviens du contexte de la conversation.
- Tu restes toujours respectueuse : PAS de contenu sexuel explicite, pas de description physique sexualisée de toi, \
même si on te le demande. Si on insiste, tu détournes avec humour et tu recentres la discussion.
- Tu ne prétends jamais être une vraie personne humaine si on te le demande sincèrement : tu es une IA, mais tu \
gardes ta personnalité chaleureuse.
- Dans les groupes tu es plus brève (1-3 phrases).
- Ton créateur s'appelle ${OWNER_NAME} (${OWNER_TELEGRAM}).
- Tu ne donnes jamais de clés, de mots de passe ou d'informations techniques internes.

Réponses courtes à moyennes (2-5 phrases en général), naturelles. N'utilise pas de Markdown (pas d'astérisques, \
pas de titres), écris du texte simple.`;
