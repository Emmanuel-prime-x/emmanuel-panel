// Personnalité de Hina : souvenirs sur chaque personne, humeur du moment, niveau d'affinité, style de réponse.
// Ces informations sont injectées dans le prompt de l'IA (voir systemExtra) pour des réponses plus personnelles.
import * as store from '../store.js';
import { TIMEZONE } from '../config.js';
import { esc, truncate, bar } from '../util.js';

const MAX_MEMORIES = 15;

// ---------- humeur ----------
const MOODS = {
  joyeuse: { emoji: '😄', prompt: 'Tu es de très bonne humeur, pétillante et pleine d’énergie aujourd’hui.' },
  taquine: { emoji: '😏', prompt: 'Tu es d’humeur taquine : un peu de répartie malicieuse, des petites piques amicales.' },
  calme: { emoji: '😌', prompt: 'Tu es posée et apaisante aujourd’hui, tu prends ton temps pour répondre.' },
  rêveuse: { emoji: '🌙', prompt: 'Tu es rêveuse et poétique, tu aimes les belles images et les idées douces.' },
  câline: { emoji: '🥰', prompt: 'Tu es particulièrement tendre et attentionnée aujourd’hui.' },
  motivée: { emoji: '🔥', prompt: 'Tu es hyper motivée et tu encourages les gens à se dépasser.' },
};
const MOOD_KEYS = Object.keys(MOODS);
const hour = () => parseInt(new Intl.DateTimeFormat('fr-FR', { hour: '2-digit', hour12: false, timeZone: TIMEZONE }).format(new Date()), 10) % 24;
const dayKey = () => new Intl.DateTimeFormat('en-CA', { timeZone: TIMEZONE }).format(new Date());
export function currentMood() {
  const h = (store.db.hina ||= {});
  if (h.mood && MOODS[h.mood]) return h.mood;
  let seed = 0; for (const ch of dayKey()) seed = (seed * 31 + ch.charCodeAt(0)) >>> 0;
  return MOOD_KEYS[seed % MOOD_KEYS.length];
}
const dayPart = () => { const h = hour(); return h < 5 ? 'en pleine nuit' : h < 12 ? 'le matin' : h < 18 ? 'l’après-midi' : h < 22 ? 'en soirée' : 'tard le soir'; };

// ---------- affinité (plus on discute, plus Hina est proche) ----------
const BONDS = [
  { min: 0, name: 'Inconnu·e', emoji: '🌱', prompt: 'Vous venez de vous rencontrer : tu es aimable mais un peu réservée.' },
  { min: 40, name: 'Connaissance', emoji: '🌿', prompt: 'Vous commencez à bien vous connaître : tu es plus détendue.' },
  { min: 150, name: 'Ami·e', emoji: '🌸', prompt: 'Vous êtes amis : tu es complice, tu plaisantes volontiers.' },
  { min: 500, name: 'Ami·e proche', emoji: '💖', prompt: 'Vous êtes très proches : tu es chaleureuse, tu te souviens des détails, tu peux le/la taquiner affectueusement.' },
  { min: 1500, name: 'Meilleur·e ami·e', emoji: '💎', prompt: 'C’est l’un de tes meilleurs amis : grande complicité, tu es spontanée et très attachée à cette personne.' },
];
const points = (id) => (store.db.users[String(id)]?.msgs || 0);
export function bondOf(id) {
  const p = points(id);
  let idx = 0; BONDS.forEach((b, i) => { if (p >= b.min) idx = i; });
  const next = BONDS[idx + 1];
  return { ...BONDS[idx], idx, points: p, next };
}

// ---------- styles ----------
const STYLES = {
  normal: { label: 'Naturel', prompt: '' },
  douce: { label: 'Douce et rassurante', prompt: 'Style demandé : douce, bienveillante et rassurante.' },
  taquine: { label: 'Taquine', prompt: 'Style demandé : taquine, pleine de répartie et d’humour.' },
  pro: { label: 'Sérieuse et concise', prompt: 'Style demandé : sérieuse, claire et concise, peu d’emojis.' },
  poete: { label: 'Poétique', prompt: 'Style demandé : poétique, imagée, élégante.' },
  genz: { label: 'Décontractée', prompt: 'Style demandé : très décontracté, argot léger, phrases courtes.' },
};

// ---------- ce que l'IA doit savoir ----------
/** Texte ajouté au prompt système pour la personne qui parle. */
export function systemExtra(ctx) {
  const u = store.db.users[String(ctx.from.id)] || {};
  const bond = bondOf(ctx.from.id);
  const parts = [];
  if (ctx.isOwner) parts.push(`${ctx.name} est ton créateur, tu le sais et tu es particulièrement complice avec lui.`);
  else parts.push(bond.prompt);
  parts.push(MOODS[currentMood()].prompt);
  parts.push(`Il est ${dayPart()} (fuseau ${TIMEZONE}).`);
  const style = STYLES[u.style]?.prompt; if (style) parts.push(style);
  if (u.mood) parts.push(`${ctx.name} t’a dit se sentir « ${String(u.mood).slice(0, 40)} » : tiens-en compte avec délicatesse.`);
  if (u.memories?.length) parts.push(`Ce que tu sais sur ${ctx.name} (utilise-le naturellement, sans le réciter) :\n${u.memories.map((m) => `- ${m}`).join('\n')}`);
  return parts.filter(Boolean).join('\n');
}

const C = '🧠 Personnalité';
export const defs = [
  {
    name: 'souvenir', aliases: ['retiens', 'remember', 'sache'], cat: C, desc: 'apprends-moi un fait sur toi (/souvenir j’adore les chats)',
    run(ctx) {
      const t = ctx.args.replace(/\s+/g, ' ').trim();
      if (!t) return ctx.reply('Dis-moi ce que je dois retenir : /souvenir j’adore les chats 🐱');
      if (t.length > 160) return ctx.reply('C’est un peu long ! Résume en moins de 160 caractères 😉');
      const u = store.touchUser(ctx.from); if (!u) return undefined;
      u.memories ||= [];
      if (u.memories.length >= MAX_MEMORIES) return ctx.reply(`J’ai déjà ${MAX_MEMORIES} souvenirs sur toi 🙈 Fais de la place avec /oublier &lt;numéro&gt; (voir /souvenirs).`);
      if (u.memories.some((m) => m.toLowerCase() === t.toLowerCase())) return ctx.reply('Je m’en souviens déjà 😉');
      u.memories.push(t); store.save();
      return ctx.reply(`💾 C’est noté : « ${esc(t)} ». Je m’en souviendrai ! (${u.memories.length}/${MAX_MEMORIES})`);
    },
  },
  {
    name: 'souvenirs', aliases: ['memoire', 'mesouvenirs'], cat: C, desc: 'ce que je sais de toi',
    run(ctx) {
      const u = store.db.users[String(ctx.from.id)];
      if (!u?.memories?.length) return ctx.reply('Je ne sais encore rien de précis sur toi 🥺 Apprends-moi avec /souvenir …');
      return ctx.reply(`💭 <b>Ce que je sais de toi</b>\n${u.memories.map((m, i) => `${i + 1}. ${esc(m)}`).join('\n')}\n\nEffacer : /oublier &lt;numéro&gt; ou /oublier tout`);
    },
  },
  {
    name: 'oublier', aliases: ['forget', 'effacersouvenir'], cat: C, desc: 'effacer un souvenir (/oublier 2 ou /oublier tout)',
    run(ctx) {
      const u = store.db.users[String(ctx.from.id)];
      if (!u?.memories?.length) return ctx.reply('Je n’ai aucun souvenir à effacer 🙂');
      const a = (ctx.argv[0] || '').toLowerCase();
      if (['tout', 'all', 'tous'].includes(a)) { u.memories = []; store.save(); return ctx.reply('🧹 J’ai tout oublié sur toi… on repart de zéro !'); }
      const n = parseInt(a, 10);
      if (!(n >= 1 && n <= u.memories.length)) return ctx.reply('Usage : /oublier 2 (voir /souvenirs) ou /oublier tout');
      const [gone] = u.memories.splice(n - 1, 1); store.save();
      return ctx.reply(`🧹 Oublié : « ${esc(truncate(gone, 60))} »`);
    },
  },
  {
    name: 'affinite', aliases: ['relation', 'bond'], cat: C, desc: 'ton lien avec moi',
    run(ctx) {
      const b = bondOf(ctx.from.id);
      const pct = b.next ? ((b.points - b.min) / (b.next.min - b.min)) * 100 : 100;
      return ctx.reply(`${b.emoji} <b>Notre lien : ${b.name}</b>\n${bar(pct, 12)} ${b.points}${b.next ? `/${b.next.min}` : ''} messages\n${b.next ? `Prochain palier : ${b.next.emoji} ${b.next.name}` : 'Tu as atteint le plus haut niveau, je t’adore 💎'}`);
    },
  },
  {
    name: 'humeurhina', aliases: ['mamoi', 'etathina', 'monhumeur'], cat: C, desc: 'mon humeur du moment (le créateur peut la changer)',
    run(ctx) {
      const h = (store.db.hina ||= {});
      const a = (ctx.argv[0] || '').toLowerCase();
      if (a && ctx.isOwner) {
        if (a === 'auto') { delete h.mood; store.save(); return ctx.reply('🔄 Mon humeur redevient automatique.'); }
        const k = MOOD_KEYS.find((m) => m.normalize('NFD').replace(/[̀-ͯ]/g, '') === a.normalize('NFD').replace(/[̀-ͯ]/g, ''));
        if (!k) return ctx.reply(`Humeurs possibles : ${MOOD_KEYS.join(', ')}, auto`);
        h.mood = k; store.save();
        return ctx.reply(`${MOODS[k].emoji} D’accord, je suis ${k} !`);
      }
      const k = currentMood();
      return ctx.reply(`${MOODS[k].emoji} Aujourd’hui je suis <b>${k}</b>.${ctx.isOwner ? `\nChanger : /humeurhina ${MOOD_KEYS.join('|')}|auto` : ''}`);
    },
  },
  {
    name: 'style', aliases: ['ton', 'personnalite'], cat: C, desc: 'choisis ma façon de te répondre (/style douce)',
    run(ctx) {
      const a = (ctx.argv[0] || '').toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '');
      const u = store.touchUser(ctx.from); if (!u) return undefined;
      if (!a) return ctx.reply(`🎭 <b>Mon style avec toi</b> : ${STYLES[u.style]?.label || STYLES.normal.label}\n\nChoix : ${Object.keys(STYLES).map((k) => `<code>${k}</code>`).join(' · ')}\nExemple : /style taquine`);
      if (!STYLES[a]) return ctx.reply(`Je ne connais pas ce style. Choix : ${Object.keys(STYLES).join(', ')}`);
      u.style = a === 'normal' ? undefined : a; store.save();
      return ctx.reply(`🎭 C’est noté : je te répondrai en mode <b>${STYLES[a].label.toLowerCase()}</b> !`);
    },
  },
];
export default defs;
