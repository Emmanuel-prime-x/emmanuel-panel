const crypto = require('crypto')
const U = require('../lib/utils')

const use = (c, s) => c.reply(`ℹ️ Usage : ${c.prefix}${s}`)
const enc = encodeURIComponent
const MORSE = { A: '.-', B: '-...', C: '-.-.', D: '-..', E: '.', F: '..-.', G: '--.', H: '....', I: '..', J: '.---', K: '-.-', L: '.-..', M: '--', N: '-.', O: '---', P: '.--.', Q: '--.-', R: '.-.', S: '...', T: '-', U: '..-', V: '...-', W: '.--', X: '-..-', Y: '-.--', Z: '--..', 0: '-----', 1: '.----', 2: '..---', 3: '...--', 4: '....-', 5: '.....', 6: '-....', 7: '--...', 8: '---..', 9: '----.' }
const UNMORSE = Object.fromEntries(Object.entries(MORSE).map(([k, v]) => [v, k]))
const COINS = { btc: 'bitcoin', eth: 'ethereum', bnb: 'binancecoin', sol: 'solana', xrp: 'ripple', ada: 'cardano', doge: 'dogecoin', ton: 'the-open-network', trx: 'tron', usdt: 'tether', ltc: 'litecoin', dot: 'polkadot', matic: 'matic-network', shib: 'shiba-inu' }

module.exports = [
  {
    name: 'weather', aliases: ['meteo'], cat: 'tools', desc: 'Météo d\'une ville', usage: 'weather Brazzaville',
    run: async (c) => {
      if (!c.text) return use(c, 'weather <ville>')
      const j = await U.getJson(`https://wttr.in/${enc(c.text)}?format=j1&lang=fr`)
      const cur = j.current_condition?.[0]
      if (!cur) return c.reply('❌ Ville introuvable.')
      const area = j.nearest_area?.[0]
      const desc = cur.lang_fr?.[0]?.value || cur.weatherDesc?.[0]?.value
      await c.reply(`🌦️ *Météo : ${area?.areaName?.[0]?.value || c.text}, ${area?.country?.[0]?.value || ''}*\n\n🌡️ Température : ${cur.temp_C}°C (ressenti ${cur.FeelsLikeC}°C)\n☁️ Ciel : ${desc}\n💧 Humidité : ${cur.humidity}%\n💨 Vent : ${cur.windspeedKmph} km/h\n👁️ Visibilité : ${cur.visibility} km\n🔆 UV : ${cur.uvIndex}`)
    }
  },
  {
    name: 'calc', aliases: ['calcul', 'math'], cat: 'tools', desc: 'Calculatrice', usage: 'calc (12+8)*3/4',
    run: async (c) => {
      if (!c.text) return use(c, 'calc 2+2*5')
      const expr = c.text.replace(/,/g, '.').replace(/×/g, '*').replace(/÷/g, '/').replace(/\^/g, '**').replace(/x/gi, '*')
      if (!/^[0-9+\-*/().%\s]+$/.test(expr)) return c.reply('❌ Expression invalide. Utilise seulement des chiffres et + - * / ( ) % ^')
      let r
      try { r = Function(`"use strict";return (${expr})`)() } catch { return c.reply('❌ Calcul impossible.') }
      if (typeof r !== 'number' || !isFinite(r)) return c.reply('❌ Résultat invalide.')
      await c.reply(`🧮 ${c.text} = *${Number(r.toPrecision(12))}*`)
    }
  },
  {
    name: 'currency', aliases: ['convert', 'devise'], cat: 'tools', desc: 'Convertit des devises', usage: 'currency 100 usd xaf',
    run: async (c) => {
      const a = [...c.args]
      let amount = 1
      if (a.length && !isNaN(parseFloat(a[0].replace(',', '.')))) amount = parseFloat(a.shift().replace(',', '.'))
      if (a.length < 2) return use(c, 'currency 100 usd eur')
      const from = a[0].toUpperCase(), to = a[1].toUpperCase()
      const j = await U.getJson(`https://open.er-api.com/v6/latest/${from}`)
      if (j.result !== 'success' || !j.rates?.[to]) return c.reply('❌ Devise inconnue (utilise les codes : USD, EUR, XAF, XOF, NGN...).')
      await c.reply(`💱 *${amount.toLocaleString('fr-FR')} ${from}* = *${(amount * j.rates[to]).toLocaleString('fr-FR', { maximumFractionDigits: 2 })} ${to}*\n📈 Taux : 1 ${from} = ${j.rates[to]} ${to}`)
    }
  },
  {
    name: 'crypto', cat: 'tools', desc: 'Prix d\'une cryptomonnaie', usage: 'crypto btc',
    run: async (c) => {
      const q = (c.args[0] || 'bitcoin').toLowerCase()
      const id = COINS[q] || q
      const j = await U.getJson(`https://api.coingecko.com/api/v3/simple/price?ids=${enc(id)}&vs_currencies=usd,eur&include_24hr_change=true`)
      const d = j[id]
      if (!d) return c.reply('❌ Crypto introuvable. Essaie : btc, eth, sol, bnb, doge, ton...')
      await c.reply(`🪙 *${id.toUpperCase()}*\n💵 ${d.usd?.toLocaleString('en-US')} USD\n💶 ${d.eur?.toLocaleString('fr-FR')} EUR\n${d.usd_24h_change >= 0 ? '📈' : '📉'} 24h : ${d.usd_24h_change?.toFixed(2)}%`)
    }
  },
  {
    name: 'define', aliases: ['dico'], cat: 'tools', desc: 'Définition d\'un mot anglais', usage: 'define serendipity',
    run: async (c) => {
      if (!c.args[0]) return use(c, 'define <mot en anglais>')
      let j
      try { j = await U.getJson(`https://api.dictionaryapi.dev/api/v2/entries/en/${enc(c.args[0])}`) } catch { return c.reply('❌ Mot introuvable (cette commande fonctionne avec des mots anglais).') }
      const e = j[0]
      const meanings = e.meanings.slice(0, 3).map((m) => `• _${m.partOfSpeech}_ : ${m.definitions[0].definition}`).join('\n')
      await c.reply(`📚 *${e.word}* ${e.phonetic || ''}\n\n${meanings}`)
    }
  },
  {
    name: 'wiki', aliases: ['wikipedia'], cat: 'tools', desc: 'Résumé Wikipédia', usage: 'wiki Congo',
    run: async (c) => {
      if (!c.text) return use(c, 'wiki <sujet>')
      for (const lang of ['fr', 'en']) {
        const s = await U.getJson(`https://${lang}.wikipedia.org/w/api.php?action=opensearch&search=${enc(c.text)}&limit=1&format=json`).catch(() => null)
        const title = s?.[1]?.[0]
        if (!title) continue
        const r = await U.getJson(`https://${lang}.wikipedia.org/api/rest_v1/page/summary/${enc(title)}`)
        return c.reply(`📖 *${r.title}*\n\n${(r.extract || '').slice(0, 1000)}\n\n🔗 ${r.content_urls?.desktop?.page || ''}`)
      }
      await c.reply('❌ Aucun article trouvé.')
    }
  },
  {
    name: 'country', aliases: ['pays'], cat: 'tools', desc: 'Infos sur un pays', usage: 'country Congo',
    run: async (c) => {
      if (!c.text) return use(c, 'country <pays>')
      const j = await U.getJson(`https://restcountries.com/v3.1/name/${enc(c.text)}?fields=name,capital,region,subregion,population,area,currencies,languages,flag,idd`).catch(() => null)
      const p = j?.[0]
      if (!p) return c.reply('❌ Pays introuvable (essaie le nom en anglais).')
      await c.reply(`${p.flag} *${p.name.common}* (${p.name.official})\n\n🏛️ Capitale : ${(p.capital || ['?']).join(', ')}\n🌍 Région : ${p.region} / ${p.subregion || '-'}\n👥 Population : ${p.population.toLocaleString('fr-FR')}\n📐 Superficie : ${p.area.toLocaleString('fr-FR')} km²\n💰 Monnaie : ${Object.values(p.currencies || {}).map((x) => `${x.name} (${x.symbol})`).join(', ')}\n🗣️ Langues : ${Object.values(p.languages || {}).join(', ')}\n📞 Indicatif : ${p.idd?.root || ''}${p.idd?.suffixes?.[0] || ''}`)
    }
  },
  {
    name: 'ip', aliases: ['iplookup'], cat: 'tools', desc: 'Localise une adresse IP', usage: 'ip 8.8.8.8',
    run: async (c) => {
      if (!c.args[0]) return use(c, 'ip <adresse IP>')
      const j = await U.getJson(`http://ip-api.com/json/${enc(c.args[0])}?lang=fr&fields=status,message,country,regionName,city,isp,org,timezone,query`)
      if (j.status !== 'success') return c.reply('❌ ' + (j.message || 'IP invalide'))
      await c.reply(`🌐 *${j.query}*\n📍 ${j.city}, ${j.regionName}, ${j.country}\n🏢 ${j.isp}\n🕐 ${j.timezone}`)
    }
  },
  {
    name: 'qr', aliases: ['qrcode'], cat: 'tools', desc: 'Crée un QR code', usage: 'qr https://exemple.com',
    run: async (c) => { if (!c.input) return use(c, 'qr <texte ou lien>'); await c.image(`https://api.qrserver.com/v1/create-qr-code/?size=600x600&margin=10&data=${enc(c.input)}`, '📱 Ton QR code') }
  },
  {
    name: 'shorten', aliases: ['short', 'tinyurl'], cat: 'tools', desc: 'Raccourcit un lien', usage: 'shorten https://...',
    run: async (c) => {
      const url = (c.input.match(/https?:\/\/\S+/) || [])[0]
      if (!url) return use(c, 'shorten <lien>')
      let out
      try { out = (await U.getText(`https://is.gd/create.php?format=simple&url=${enc(url)}`)).trim() } catch { out = (await U.getText(`https://tinyurl.com/api-create.php?url=${enc(url)}`)).trim() }
      await c.reply(`🔗 ${out}`)
    }
  },
  {
    name: 'screenshot', aliases: ['ss', 'ssweb'], cat: 'tools', desc: "Capture d'écran d'un site", usage: 'screenshot https://google.com',
    run: async (c) => {
      let url = c.args[0]
      if (!url) return use(c, 'screenshot <lien>')
      if (!/^https?:\/\//i.test(url)) url = 'https://' + url
      await c.react('📸')
      let buf
      try { buf = await U.getBuffer(`https://image.thum.io/get/width/1280/crop/720/${url}`, { timeout: 60000 }) } catch { buf = await U.getBuffer(`https://s0.wp.com/mshots/v1/${enc(url)}?w=1280&h=720`, { timeout: 60000 }) }
      await c.image(buf, `🖥️ ${url}`)
    }
  },
  {
    name: 'password', aliases: ['pass', 'mdp'], cat: 'tools', desc: 'Génère un mot de passe sûr', usage: 'password 20',
    run: async (c) => {
      const n = Math.min(64, Math.max(6, parseInt(c.args[0]) || 16))
      const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz23456789!@#$%&*?'
      let p = ''
      for (let i = 0; i < n; i++) p += chars[crypto.randomInt(chars.length)]
      await c.reply(`🔑 Mot de passe (${n} caractères) :\n\n${p}\n\n_Ne le partage avec personne._`)
    }
  },
  {
    name: 'fancy', aliases: ['style'], cat: 'tools', desc: 'Écrit ton texte avec des polices stylées', usage: 'fancy Emmanuel',
    run: async (c) => {
      if (!c.input) return use(c, 'fancy <texte>')
      await c.reply(Object.keys(U.styles).map((s) => U.fancy(c.input, s)).join('\n\n'))
    }
  },
  {
    name: 'tourl', aliases: ['upload'], cat: 'tools', desc: 'Envoie une image/vidéo/fichier et donne un lien', usage: 'tourl (en répondant à un média)',
    run: async (c) => {
      const media = await c.getMedia()
      if (!media) return c.reply('📎 Envoie ou réponds à une image, vidéo, audio ou document avec cette commande.')
      await c.react('⏳')
      const ext = (media.mime.split('/')[1] || 'bin').split(';')[0]
      const blob = () => new Blob([media.buffer], { type: media.mime || 'application/octet-stream' })
      let url = ''
      try {
        const fd = new FormData()
        fd.append('reqtype', 'fileupload')
        fd.append('fileToUpload', blob(), `file.${ext}`)
        const r = await fetch('https://catbox.moe/user/api.php', { method: 'POST', body: fd, signal: AbortSignal.timeout(90000) })
        url = (await r.text()).trim()
      } catch {}
      if (!/^https?:\/\//.test(url)) {
        try {
          const fd = new FormData()
          fd.append('files[]', blob(), `file.${ext}`)
          const r = await fetch('https://uguu.se/upload', { method: 'POST', body: fd, signal: AbortSignal.timeout(90000) })
          url = (await r.json()).files?.[0]?.url || ''
        } catch {}
      }
      if (!/^https?:\/\//.test(url)) {
        try {
          const fd = new FormData()
          fd.append('file', blob(), `file.${ext}`)
          const r = await fetch('https://0x0.st', { method: 'POST', body: fd, headers: { 'User-Agent': 'curl/8.0' }, signal: AbortSignal.timeout(90000) })
          url = (await r.text()).trim()
        } catch {}
      }
      if (!/^https?:\/\//.test(url)) throw new Error("Envoi impossible : les services d'hébergement sont indisponibles, réessaie plus tard.")
      await c.reply(`🔗 *Lien direct :*\n${url}`)
    }
  }
]
