// Lance CHAQUE commande avec des arguments variés (y compris absurdes) et vérifie qu'aucune ne plante ni ne reste muette.
import { spawn } from 'node:child_process';
import fs from 'node:fs'; import os from 'node:os'; import path from 'node:path';
import { startMock } from './mock.mjs';
const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'qhf-'));
const { state, port, inject, server } = await startMock();
const env = { PATH: process.env.PATH, ENV_FILE: '/nonexistent', TELEGRAM_TOKEN: '1:T', TELEGRAM_API_BASE: `http://127.0.0.1:${port}/tg`, NEKOS_API: `http://127.0.0.1:${port}/nekos`, AI_BASE_URL: `http://127.0.0.1:${port}/ai`, AI_API_KEY: 'x', OWNER_ID: '1', DATA_FILE: path.join(tmp, 'd.json'), MEDIA_SONGS_DIR: path.join(tmp, 's'), MEDIA_PHOTOS_DIR: path.join(tmp, 'p'), MEDIA_VIDEOS_DIR: path.join(tmp, 'v') };
const child = spawn(process.execPath, [new URL('../index.js', import.meta.url).pathname], { env, stdio: ['ignore', 'pipe', 'pipe'] });
let log = ''; child.stdout.on('data', (d) => { log += d; }); child.stderr.on('data', (d) => { log += d; });
let exited = null; child.on('exit', (c) => { exited = c; });
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
for (let i = 0; i < 100 && !log.includes('est prête'); i += 1) await sleep(100);
const mods = ['core','reactions','songs','fun','games','multi','games2','economy','shop','persona','access','manage','group','text','utils','tools','aicmds','support','admin'];
const names = [];
for (const m of mods) for (const d of (await import(`../handlers/${m}.js`)).default) names.push(d.name);
const OWNER = { id: 1, first_name: 'Emma', is_bot: false };
const target = { message_id: 7, from: { id: 50, first_name: 'Bob', is_bot: false }, chat: { id: 5 }, text: 'Bonjour le monde' };
let mid = 5000;
const variants = [['', null], ['abc def', null], ['5 7', target], ['-3 99999999999 x', null], ['x ; y', target], ['<b>x</b> & "q"', null], ['a'.repeat(3000), null]];
const silent = new Set();
let chats = [[5, 'private'], [-100, 'supergroup']];
for (const [chatId, type] of chats) {
  for (const name of names) {
    if (['leave', 'broadcast'].includes(name)) continue;
    for (const [args, reply] of variants) {
      const since = state.calls.length;
      inject({ message: { message_id: ++mid, chat: { id: chatId, type, title: 'G' }, from: OWNER, text: `/${name} ${args}`.trim(), reply_to_message: reply || undefined } });
      const t0 = Date.now();
      while (Date.now() - t0 < 8000 && state.calls.length === since) await sleep(20);
      if (state.calls.length === since) silent.add(`${name} (${type}) args="${args.slice(0, 15)}"`);
      await sleep(15);
    }
  }
}
await sleep(500);
const errs = log.split('\n').filter((l) => /\[cmd:|uncaught|unhandled|TypeError|ReferenceError/.test(l));
console.log('processus vivant :', exited === null);
console.log('commandes testées :', names.length, 'x', variants.length, 'x', chats.length);
console.log('erreurs internes :', errs.length); errs.slice(0, 40).forEach((e) => console.log('  ', e.slice(0, 200)));
console.log('sans aucune réponse :', silent.size); [...silent].slice(0, 40).forEach((e) => console.log('  ', e));
child.kill('SIGTERM'); server.close(); fs.rmSync(tmp, { recursive: true, force: true });
process.exit(0);
