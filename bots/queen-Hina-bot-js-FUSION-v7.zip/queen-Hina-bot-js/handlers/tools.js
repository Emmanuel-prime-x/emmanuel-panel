import { MAX_REMINDERS } from '../config.js';
import * as store from '../store.js';
import { esc, parseDuration, fmtDuration, truncate } from '../util.js';

const T = { cat: '📝 Organisation' };
const notesOf = (uid) => store.db.notes[String(uid)] || (store.db.notes[String(uid)] = []);

export const defs = [
  {
    ...T, name: 'rappel', aliases: ['remind', 'reminder', 'timer', 'minuteur'], desc: 'me rappeler (/rappel 10m sortir le pain)',
    run(ctx) {
      const m = ctx.args.match(/^(\S+)\s*([\s\S]*)$/);
      const secs = m ? parseDuration(m[1]) : null;
      if (!secs) return ctx.reply('Usage : /rappel 30m appeler Marie\nDurées : 45s · 10m · 2h · 1j · 1h30m');
      if (secs < 5 || secs > 365 * 86400) return ctx.reply('Durée entre 5 secondes et 365 jours.');
      const mine = store.db.reminders.filter((r) => r.chatId === ctx.chat.id).length;
      if (mine >= MAX_REMINDERS) return ctx.reply(`Trop de rappels dans ce chat (max ${MAX_REMINDERS}). Supprime-en avec /delrappel.`);
      const text = (m[2] || 'C’est l’heure !').slice(0, 300);
      const id = Date.now().toString(36) + Math.random().toString(36).slice(2, 5);
      store.db.reminders.push({ id, chatId: ctx.chat.id, userId: ctx.from.id, at: Date.now() + secs * 1000, text: `${ctx.name} : ${text}` });
      store.save();
      return ctx.reply(`⏰ C’est noté ! Je te le rappelle dans <b>${fmtDuration(secs)}</b>.`);
    },
  },
  {
    ...T, name: 'rappels', aliases: ['reminders'], desc: 'liste de mes rappels',
    run(ctx) {
      const list = store.db.reminders.filter((r) => r.chatId === ctx.chat.id && (ctx.isPrivate || r.userId === ctx.from.id));
      if (!list.length) return ctx.reply('Aucun rappel en cours.');
      return ctx.reply(`⏰ <b>Rappels</b>\n${list.map((r, i) => `${i + 1}. dans ${fmtDuration((r.at - Date.now()) / 1000)} — ${esc(truncate(r.text, 60))}`).join('\n')}\n\nSupprimer : /delrappel numéro`);
    },
  },
  {
    ...T, name: 'delrappel', desc: 'supprimer un rappel (/delrappel 1)',
    run(ctx) {
      const list = store.db.reminders.filter((r) => r.chatId === ctx.chat.id && (ctx.isPrivate || r.userId === ctx.from.id));
      const r = list[parseInt(ctx.args, 10) - 1];
      if (!r) return ctx.reply('Numéro invalide, voir /rappels');
      store.db.reminders = store.db.reminders.filter((x) => x.id !== r.id); store.save();
      return ctx.reply('🗑️ Rappel supprimé.');
    },
  },
  {
    ...T, name: 'addnote', aliases: ['noter'], desc: 'enregistrer une note (/addnote texte)',
    run(ctx) {
      const t = ctx.args || ctx.msg.reply_to_message?.text;
      if (!t) return ctx.reply('Usage : /addnote acheter du pain');
      const list = notesOf(ctx.from.id);
      if (list.length >= 100) return ctx.reply('Tu as déjà 100 notes, supprime-en avec /delnote.');
      list.push({ text: t.slice(0, 500), at: Date.now() }); store.save();
      return ctx.reply(`📝 Note n°${list.length} enregistrée.`);
    },
  },
  {
    ...T, name: 'notes', aliases: ['mesnotes', 'todo'], desc: 'voir mes notes',
    run(ctx) {
      const list = notesOf(ctx.from.id);
      if (!list.length) return ctx.reply('Tu n’as aucune note. Ajoute-en avec /addnote texte');
      return ctx.reply(`📝 <b>Tes notes</b>\n${list.map((n, i) => `${i + 1}. ${esc(truncate(n.text, 120))}`).join('\n')}`);
    },
  },
  {
    ...T, name: 'delnote', desc: 'supprimer une note (/delnote 2 ou /delnote tout)',
    run(ctx) {
      const list = notesOf(ctx.from.id);
      if (/^(tout|all)$/i.test(ctx.args)) { store.db.notes[String(ctx.from.id)] = []; store.save(); return ctx.reply('🗑️ Toutes tes notes sont supprimées.'); }
      const i = parseInt(ctx.args, 10) - 1;
      if (!list[i]) return ctx.reply('Numéro invalide, voir /notes');
      list.splice(i, 1); store.save();
      return ctx.reply('🗑️ Note supprimée.');
    },
  },
];
export default defs;
