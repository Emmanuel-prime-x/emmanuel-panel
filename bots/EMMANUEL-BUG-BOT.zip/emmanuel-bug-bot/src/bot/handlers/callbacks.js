import {
  getMode,
  getPairsForUser,
  getAllPairs,
  isVVIP,
  getVVIPs,
} from "../../data/database.js";
import { getClient } from "../whatsapp.js";
import { log } from "../logger.js";
import { describeWhatsappError } from "../whatsapp.js";
import { getTravasEntry } from "../travas.js";
import {
  consumeVVIPSenderUse,
  resetVVIPSenderUse,
} from "../vvipCooldown.js";

export function registerCallbackHandlers(bot, runtime, menu) {
  const {
    isSubBot,
    subBotOwnerId,
    checkOwner,
    checkAdmin,
    checkAccess,
    dbScope,
    describeAssenderTarget,
    ownerActingAs,
    pendingAction,
    pendingTravasTarget,
    sendDoneCard,
    getActingTarget,
    isUsingExternalSender,
  } = runtime;

  const {
    botError,
    botSucces,
    handleMenuCallback,
    sendActionMenu,
    streamBlocks,
  } = menu;

  bot.on("callback_query:data", async (ctx) => {
    const uid = String(ctx.from.id);
    const data = ctx.callbackQuery.data;
    await ctx.answerCallbackQuery();

    const handledByMenu = await menu.handleMenuCallback(ctx, data);
    if (handledByMenu) return;

    switch (true) {
      case data === "cancel_execution": {
        pendingTravasTarget.delete(uid);
        await ctx.deleteMessage().catch(() => {});
        await sendActionMenu(ctx);
        return;
      }

      case data.startsWith("travas_pick_"): {
        if (isSubBot) {
          return botError(
            ctx,
            "Les sous-bots utilisent les commandes travas manuelles. Ouvre /action pour voir la liste des commandes.",
            "⚠️ MODE COMMANDE",
          );
        }

        if (!checkAccess(uid)) {
          return botError(
            ctx,
            "Tu n'as pas accès aux actions travas. Un accès Premium est requis.",
            "⚠️ ACCÈS REFUSÉ",
          );
        }

        const key = data.replace("travas_pick_", "");
        const item = getTravasEntry(key);

        if (!item) {
          return botError(ctx, "Cette option travas est indisponible.");
        }

        pendingTravasTarget.set(uid, { key, type: item.type, label: item.label });
        await ctx.deleteMessage().catch(() => {});

        const targetGuide = {
          number: {
            title: "Numéro WhatsApp",
            format: "6281234567890",
            instruction: "Envoie le numéro WhatsApp cible avec l'indicatif pays. N'inclus pas d'espaces, de signes plus ou de séparateurs.",
            example: "6281234567890",
          },
          group: {
            title: "Groupe WhatsApp",
            format: "Lien d'invitation ou JID de groupe",
            instruction: "Envoie un lien d'invitation de groupe WhatsApp. Le bot le résoudra automatiquement en un vrai JID de groupe @g.us. Tu peux aussi envoyer un JID de groupe existant.",
            example: "https://chat.whatsapp.com/ABC123xyz\n1234567890-123456@g.us",
          },
          channel: {
            title: "Channel WhatsApp",
            format: "ID du channel",
            instruction: "Envoie l'ID numérique du channel. Le bot le convertira en cible newsletter WhatsApp requise.",
            example: "1234567890",
          },
        }[item.type];

        const blocks = [
          { type: "heading", text: "🎯 DEMANDE DE CIBLE", size: 1 },
          {
            type: "table",
            cells: [
              [
                {
                  text: [
                    {
                      type: "bold",
                      text: "Envoie une valeur de cible valide pour continuer cette action travas.",
                    },
                  ],
                  is_header: true,
                  align: "center",
                  valign: "middle",
                },
              ],
            ],
            is_bordered: false,
            is_striped: false,
          },
          { type: "divider" },
          {
            type: "table",
            cells: [
              [
                {
                  text: "Action sélectionnée",
                  is_header: true,
                  align: "left",
                  valign: "middle",
                },
                {
                  text: item.label,
                  is_header: true,
                  align: "left",
                  valign: "middle",
                },
              ],
              [
                {
                  text: "Type de cible",
                  align: "left",
                  valign: "middle",
                },
                {
                  text: targetGuide.title,
                  align: "left",
                  valign: "middle",
                },
              ],
              [
                {
                  text: "Format requis",
                  align: "left",
                  valign: "middle",
                },
                {
                  text: targetGuide.format,
                  align: "left",
                  valign: "middle",
                },
              ],
            ],
            is_bordered: true,
            is_striped: true,
          },
          {
            type: "details",
            summary: ["Comment envoyer la cible"],
            blocks: [
              {
                type: "table",
                cells: [
                  [
                    {
                      text: targetGuide.instruction,
                      is_header: false,
                      align: "left",
                      valign: "middle",
                    },
                  ],
                  [
                    {
                      text: `Exemple :\n${targetGuide.example}`,
                      is_header: false,
                      align: "left",
                      valign: "middle",
                    },
                  ],
                ],
                is_bordered: true,
                is_striped: true,
              },
            ],
          },
          { type: "divider" },
          {
            type: "paragraph",
            text: [
              { type: "bold", text: "Important : " },
              "Envoie uniquement la valeur de la cible comme prochain message. L'invite sera supprimée après réception d'une cible valide.",
            ],
          },
          {
            type: "buttons",
            buttons: [
              {
                text: "Annuler et revenir au menu Action",
                style: "danger",
                callback_data: "cancel_execution",
              },
            ],
          },
        ];

        await streamBlocks(ctx, blocks, { footer: false });
        return;
      }

      case data.startsWith("reset_vvip_cooldown_"): {
        const uid = String(ctx.from.id);

        if (!checkOwner(uid)) {
          return botError(ctx, "Réservé au propriétaire.");
        }

        const targetId = data.replace("reset_vvip_cooldown_", "");
        resetVVIPSenderUse(targetId);
        await ctx.deleteMessage().catch(() => {});
        await botSucces(
          ctx,
          `Le cooldown de ${targetId} a été réinitialisé.`,
          "✅ COOLDOWN RÉINITIALISÉ",
        );
        return;
      }

      case data.startsWith("vvip_select_"): {
        const uid = String(ctx.from.id);
        const isPrivilegedVVIPUser =
          checkOwner(uid) || checkAdmin(uid) || isVVIP(uid, dbScope);

        if (!isPrivilegedVVIPUser) {
          return botError(ctx, "Un accès VVIP est requis pour cette fonctionnalité.");
        }

        if (getMode(dbScope) === "public" && !isPrivilegedVVIPUser) {
          return botError(
            ctx,
            "Cette fonctionnalité d'émetteur VVIP est désactivée en mode public/gratuit pour les utilisateurs gratuits.",
            "⚠️ NON DISPONIBLE",
          );
        }

        const payload = data.replace("vvip_select_", "");
        const [targetKey, targetNumber] = payload.split("__");

        if (!targetKey || !targetNumber) {
          return botError(ctx, "Sélection d'émetteur VVIP invalide.");
        }

        const currentTarget = getActingTarget(uid);
        if (targetKey === currentTarget) {
          return botError(
            ctx,
            isUsingExternalSender(uid)
              ? `Tu utilises déjà un émetteur VVIP de ${describeAssenderTarget(targetKey)}.`
              : "Tu utilises déjà ta propre session d'émetteur.",
            "⚠️ SESSION DÉJÀ ACTIVE",
          );
        }

        if (!checkOwner(uid)) {
          const usage = consumeVVIPSenderUse(uid);
          if (!usage.allowed) {
            const waitSeconds = Math.ceil(usage.waitMs / 1000);
            const minutes = Math.ceil(waitSeconds / 60);
            return botError(
              ctx,
              `Limite d'émetteur VVIP atteinte. Attends ${minutes} minute(s) avant de réessayer.`,
              "⏳ COOLDOWN",
            );
          }
        }

        const targetSenders = getPairsForUser(targetKey);
        if (!targetSenders.includes(targetNumber)) {
          return botError(ctx, "Cet émetteur n'est plus disponible.");
        }

        ownerActingAs.set(String(uid), targetKey);
        await ctx.deleteMessage().catch(() => {});
        await botSucces(
          ctx,
          `✅ Tu utilises maintenant ${describeAssenderTarget(targetKey)} et l'émetteur actif ${targetNumber}.\nUtilise /xvvip off ou /vvipassender off pour revenir à ton propre émetteur.`,
          "✅ VVIP ACTIF",
        );
        return;
      }

      case data.startsWith("action_"): {
        const uid = String(ctx.from.id);
        const pending = pendingAction.get(uid);

        if (!pending) {
          return botError(ctx, "Cette session d'action a expiré.");
        }

        const picked = data.replace("action_", "");
        const storageKey = pending.storageKey || uid;

        pendingAction.delete(uid);
        await ctx.deleteMessage().catch(() => {});

        const targets =
          picked === "all" ? getPairsForUser(storageKey) : [picked];

        await sendDoneCard(ctx, {
          command: pending.command,
          target: pending.target,
          type: "all",
          results: targets,
        });

        targets.forEach((number) => {
          const client = getClient(storageKey, number);
          if (client?.sock && client.status === "open") {
            pending.func(client.sock, pending.target).catch((err) => {
              log.error(
                `Exécution WhatsApp échouée | ${pending.command} | ${describeWhatsappError(err)}`,
              );
            });
          }
        });

        return;
      }

      default: {
        return;
      }
    }
  });
}
