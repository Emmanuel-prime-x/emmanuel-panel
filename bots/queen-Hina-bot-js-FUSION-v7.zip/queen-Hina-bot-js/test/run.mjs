import { spawn } from 'node:child_process';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { startMock } from './mock.mjs';

const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'qh-'));
const { state, port, inject, server } = await startMock();
const songsDir = path.join(tmp, 'songs'); fs.mkdirSync(songsDir);
const photosDir = path.join(tmp, 'photos'); fs.mkdirSync(photosDir);
fs.copyFileSync(new URL('../media/photos/QUEEN-HINA.jpg', import.meta.url), path.join(photosDir, 'a.jpg'));
const dataFile = path.join(tmp, 'data.json');
const env = {
  PATH: process.env.PATH, ENV_FILE: '/nonexistent', TELEGRAM_TOKEN: '123:TEST', TELEGRAM_API_BASE: `http://127.0.0.1:${port}/tg`,
  NEKOS_API: `http://127.0.0.1:${port}/nekos`, AI_BASE_URL: `http://127.0.0.1:${port}/ai`, AI_API_KEY: 'x', OWNER_ID: '1',
  DATA_FILE: dataFile, MEDIA_SONGS_DIR: songsDir, MEDIA_PHOTOS_DIR: photosDir, AI_TIMEOUT_MS: '3000',
};
const child = spawn(process.execPath, [new URL('../index.js', import.meta.url).pathname], { env, stdio: ['ignore', 'pipe', 'pipe'] });
let log = '';
child.stdout.on('data', (d) => { log += d; });
child.stderr.on('data', (d) => { log += d; });
let exited = null;
child.on('exit', (c) => { exited = c; });

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
let mid = 1000;
const OWNER = { id: 1, first_name: 'Emma', is_bot: false };
const USER = { id: 2, first_name: 'Lea', username: 'lea', is_bot: false };
const ADMIN = { id: 10, first_name: 'Admin', is_bot: false };
const msg = (text, o = {}) => ({ message: { message_id: ++mid, date: Math.floor(Date.now() / 1000), chat: { id: o.chat ?? 5, type: o.type ?? 'private', ...(o.type && o.type !== 'private' ? { title: 'Groupe' } : {}) }, from: o.from ?? OWNER, text, entities: o.entities, reply_to_message: o.reply, ...(o.extra || {}) } });
const send = (text, o) => inject(msg(text, o));
const find = (since, pred) => state.calls.slice(since).find(pred);
async function waitFor(pred, ms = 5000) { const since = state.calls.length; const t0 = Date.now(); while (Date.now() - t0 < ms) { const c = state.calls.slice(since).find(pred); if (c) return c; await sleep(50); } return null; }
async function expectCall(trigger, pred, ms = 5000) { const since = state.calls.length; trigger(); const t0 = Date.now(); while (Date.now() - t0 < ms) { const c = state.calls.slice(since).find(pred); if (c) return c; await sleep(50); } return null; }
async function expectNone(trigger, pred, ms = 1200) { const since = state.calls.length; trigger(); await sleep(ms); return !state.calls.slice(since).some(pred); }
const text = (re) => (c) => c.method === 'sendMessage' && re.test(c.params.text);
const results = []; let failed = 0;
async function test(name, fn) { const from0 = state.calls.length; try { const ok = await fn(); results.push([ok ? 'OK ' : 'ÉCHEC', name]); if (!ok) { failed += 1; if (process.env.DEBUG_TESTS) console.log(`--- ${name}\n` + state.calls.slice(from0).filter((c) => c.method === 'sendMessage' || c.method === 'editMessageText').map((c) => '   ' + String(c.params.text).replace(/\n/g, ' | ').slice(0, 160)).join('\n')); } } catch (e) { results.push(['ERREUR', `${name} — ${e.message}`]); failed += 1; } }

// attendre le démarrage
for (let i = 0; i < 100 && !log.includes('est prête'); i += 1) await sleep(100);
await test('démarrage', async () => log.includes('est prête') && /commandes/.test(log));

await test('/ping + edit', async () => !!(await expectCall(() => send('/ping'), (c) => c.method === 'editMessageText' && /Pong/.test(c.params.text))));
await test('/start envoie la photo (upload)', async () => !!(await expectCall(() => send('/start'), (c) => c.method === 'sendPhoto')));
await test('/menu avec boutons', async () => { const c = await expectCall(() => send('/menu'), (c) => c.method === 'sendMessage' && c.params.reply_markup); return c && c.params.reply_markup.inline_keyboard.length > 3; });
await test('callback du menu (catégorie)', async () => !!(await expectCall(() => inject({ callback_query: { id: 'cb1', data: 'm:2', from: OWNER, message: { message_id: 55, chat: { id: 5, type: 'private' } } } }), (c) => c.method === 'editMessageText' && /Réactions/.test(c.params.text))));

// --- réactions nekos.best
const reply = { message_id: 7, from: USER, chat: { id: 5 }, text: 'salut' };
await test('.kiss en réponse -> animation + légende', async () => { const c = await expectCall(() => send('.kiss', { reply }), (c) => c.method === 'sendAnimation'); return c && /embrasse/.test(c.params.caption) && /Lea/.test(c.params.caption) && /kiss\.gif/.test(c.params.animation); });
await test('/hug avec @pseudo', async () => { const c = await expectCall(() => send('/hug @bob'), (c) => c.method === 'sendAnimation'); return c && /@bob/.test(c.params.caption); });
await test('!pat et alias .câlin', async () => !!(await expectCall(() => send('!pat', { reply }), (c) => c.method === 'sendAnimation')) && !!(await expectCall(() => send('.câlin', { reply }), (c) => c.method === 'sendAnimation' && /câlin/.test(c.params.caption))));
await test('.neko (image)', async () => !!(await expectCall(() => send('.neko'), (c) => c.method === 'sendPhoto' && /neko\.gif/.test(c.params.photo))));
await test('.pied (kick animé) sans conflit avec /kick', async () => !!(await expectCall(() => send('.pied', { reply }), (c) => c.method === 'sendAnimation' && /pied/.test(c.params.caption))));
state.nekos = 'down';
await test('nekos.best en panne -> texte de secours, pas de crash', async () => !!(await expectCall(() => send('.kiss', { reply }), text(/embrasse/))));
state.nekos = 'ok';

// --- chansons
await test('/chanson sans musique -> explication', async () => !!(await expectCall(() => send('/chanson'), text(/Aucune chanson/))));
fs.writeFileSync(path.join(songsDir, 'Ma_Chanson.mp3'), Buffer.concat([Buffer.from('ID3'), Buffer.alloc(4000, 7)]));
await test('/chanson envoie le fichier (upload multipart)', async () => { const c = await expectCall(() => send('/chanson'), (c) => c.method === 'sendAudio'); return c && c.upload && c.upload.filename === 'Ma_Chanson.mp3'; });
await test('2e envoi réutilise le file_id (pas de ré-upload)', async () => { const c = await expectCall(() => send('/chanson'), (c) => c.method === 'sendAudio'); return c && !c.upload && /^AUDIO_/.test(c.params.audio); });
await test('/chansons liste', async () => !!(await expectCall(() => send('/chansons'), text(/Ma Chanson/))));
await test('/addsong en réponse à un audio', async () => !!(await expectCall(() => send('/addsong Ma 2e chanson', { reply: { message_id: 9, from: OWNER, chat: { id: 5 }, audio: { file_id: 'TGAUDIO', title: 'x', file_size: 1000 } } }), text(/ajoutée/))));
await test('/chanson 2 envoie via file_id Telegram', async () => { const c = await expectCall(() => send('/chanson 2'), (c) => c.method === 'sendAudio'); return c && c.params.audio === 'TGAUDIO'; });
await test('/addsong refusé aux non-propriétaires', async () => !!(await expectCall(() => send('/addsong x', { from: USER }), text(/réservée/))));
await test('/chanson inconnue', async () => !!(await expectCall(() => send('/chanson zzzz'), text(/ne trouve pas/))));

// --- IA
await test('discussion privée -> IA, markdown nettoyé', async () => { const c = await expectCall(() => send('Coucou Hina, ça va ?'), text(/Salut mon cœur/)); return c && !/\*\*/.test(c.params.text); });
const FALLBACK_RE = /cerveau|instant|reprends|buggé|tête ailleurs/;
state.ai = '500';
await test('IA en erreur 500 -> message de secours', async () => !!(await expectCall(() => send('un message'), text(FALLBACK_RE), 15000)));
state.ai = 'ok';
await test('IA rétablie -> reprend toute seule', async () => !!(await expectCall(() => send('re-coucou'), text(/Salut mon cœur/), 8000)));
state.ai = 'hang';
await test('IA qui ne répond jamais -> délai maximum puis message de secours', async () => !!(await expectCall(() => send('tu es là ?'), text(FALLBACK_RE), 15000)));
state.ai = 'ok';
await test('IA rétablie après blocage', async () => !!(await expectCall(() => send('et maintenant'), text(/Salut mon cœur/), 8000)));
state.ai = 'empty';
await test('IA qui renvoie du vide -> message de secours', async () => !!(await expectCall(() => send('vide ?'), text(FALLBACK_RE), 15000)));
state.ai = 'ok';
await test('IA de nouveau OK', async () => !!(await expectCall(() => send('ok ?'), text(/Salut mon cœur/), 8000)));
// --- personnalité injectée dans le prompt de l'IA (avant les tests de quota, qui mettent le fournisseur en pause)
const U4 = { id: 4, first_name: 'Zoe', is_bot: false };
await test('IA : souvenirs, style et humeur injectés dans le prompt', async () => {
  const a = await expectCall(() => send('/souvenir j’adore les chats', { chat: 44, from: U4 }), text(/noté/));
  await expectCall(() => send('/style taquine', { chat: 44, from: U4 }), text(/taquine/));
  const c = await expectCall(() => send('Salut Hina', { chat: 44, from: U4 }), text(/Salut mon cœur/));
  const sys = state.lastAiBody?.messages?.[0]?.content || '';
  return a && c && /j’adore les chats/.test(sys) && /taquine/i.test(sys) && /Il est/.test(sys) && /Inconnu|réservée|amis|complice/i.test(sys);
});
state.ai = '429day';
await test('quota IA -> réponse de secours, pas de crash', async () => !!(await expectCall(() => send('et maintenant ?'), text(/batteries|recharge/))));
const calls429 = state.aiCalls;
await test('quota IA -> pause du fournisseur (pas de nouvel appel)', async () => { await expectCall(() => send('encore ?'), text(/batteries|recharge/)); return state.aiCalls === calls429; });
state.ai = 'ok';
await test('/aistatus (propriétaire)', async () => !!(await expectCall(() => send('/aistatus'), text(/custom/))));

// --- groupes
const G = { chat: -100, type: 'supergroup' };
await test('groupe: message normal ignoré', async () => expectNone(() => send('salut tout le monde', { ...G, from: USER }), text(/./)));
await test('groupe: mot "machina" ne déclenche pas', async () => expectNone(() => send('la machina est cassée', { ...G, from: USER }), text(/./)));
await test('groupe: @mention répond', async () => !!(await expectCall(() => send('@QueenHinaBot tu es là ?', { ...G, from: USER, entities: [{ type: 'mention', offset: 0, length: 13 }] }), text(/Salut|batteries/))));
await test('groupe: prénom "hina" répond', async () => !!(await expectCall(() => send('Hina, raconte-moi un truc', { ...G, from: USER }), text(/Salut|batteries/))));
await test('groupe: réponse à un message du bot', async () => !!(await expectCall(() => send('merci', { ...G, from: USER, reply: { message_id: 3, from: { id: 999, is_bot: true, username: 'QueenHinaBot' }, chat: { id: -100 }, text: 'x' } }), text(/Salut|batteries/))));
await test('/ping@autrebot ignoré', async () => expectNone(() => send('/ping@AutreBot', { ...G, from: USER }), text(/./)));
await test('/ping@QueenHinaBot accepté', async () => !!(await expectCall(() => send('/ping@QueenHinaBot', G), (c) => c.method === 'sendMessage' && /🏓/.test(c.params.text))));
await test('commande inconnue en privé', async () => !!(await expectCall(() => send('/zzzzz'), text(/ne connais pas/))));
await test('commande inconnue en groupe: silence', async () => expectNone(() => send('/zzzzz', G), text(/./)));
await test('.texte inconnu: pas pris pour une discussion', async () => expectNone(() => send('.truc', G), text(/./)));
const target = { message_id: 12, from: { id: 50, first_name: 'Bob', is_bot: false }, chat: { id: -100 }, text: 'x' };
await test('/kick par un non-admin refusé', async () => !!(await expectCall(() => send('/kick', { ...G, from: USER, reply: target }), text(/admins/))));
await test('/kick par admin -> ban + unban', async () => { const since = state.calls.length; send('/kick', { ...G, from: ADMIN, reply: target }); await waitFor(text(/exclu/)); return state.calls.slice(since).some((c) => c.method === 'banChatMember') && state.calls.slice(since).some((c) => c.method === 'unbanChatMember'); });
await test('/ban sur un admin -> message clair (pas de crash)', async () => !!(await expectCall(() => send('/ban', { ...G, from: ADMIN, reply: { ...target, from: { id: 99, first_name: 'Boss', is_bot: false } } }), text(/droits|administrateur/))));
await test('/ban sans réponse -> aide', async () => !!(await expectCall(() => send('/ban', { ...G }), text(/Réponds/))));
await test('/warn x3 -> exclusion', async () => { const since = state.calls.length; for (let i = 0; i < 3; i += 1) { send('/warn spam', { ...G, reply: target }); await sleep(250); } await sleep(600); return state.calls.slice(since).some(text(/3 avertissements/)) && state.calls.slice(since).some((c) => c.method === 'banChatMember'); });
await test('/mute 10m', async () => { const c = await expectCall(() => send('/mute 10m', { ...G, from: ADMIN, reply: target }), (c) => c.method === 'restrictChatMember'); return c && c.params.until_date > Date.now() / 1000; });
await test('/bienvenue + arrivée d’un membre', async () => { send('/bienvenue on', { ...G, from: ADMIN }); await waitFor(text(/activé/)); const c = await expectCall(() => inject({ message: { message_id: ++mid, chat: { id: -100, type: 'supergroup', title: 'Groupe' }, from: USER, new_chat_members: [{ id: 60, first_name: 'Nouveau', is_bot: false }] } }), text(/Bienvenue/)); return c && /Nouveau/.test(c.params.text); });
await test('anti-lien supprime les liens', async () => { send('/antilink on', { ...G, from: ADMIN }); await waitFor(text(/antilink|anti-liens|on/i)); return !!(await expectCall(() => send('regardez http://spam.com', { ...G, from: USER }), (c) => c.method === 'deleteMessage')); });
await test('/broadcast refusé aux non-propriétaires', async () => !!(await expectCall(() => send('/broadcast x', { from: USER }), text(/réservée/))));
await test('/afk puis mention', async () => { send('/afk sieste', { ...G, from: USER }); await waitFor(text(/AFK/)); return !!(await expectCall(() => send('coucou', { ...G, from: OWNER, reply: { message_id: 3, from: USER, chat: { id: -100 }, text: 'x' } }), text(/est AFK/))); });

// --- outils & jeux
await test('/calc', async () => !!(await expectCall(() => send('/calc 2*(3+4)^2'), text(/98/))));
await test('/calc rejette le code malveillant', async () => !!(await expectCall(() => send('/calc process.exit(1)'), text(/pas compris/))));
await test('/convertir', async () => !!(await expectCall(() => send('/convertir 10 km mi'), text(/6,2/))));
await test('/de et /nombre 5 5 (pas de crash)', async () => !!(await expectCall(() => send('/de'), text(/Dé/))) && !!(await expectCall(() => send('/nombre 5 5'), text(/5/))));
await test('/pfc', async () => !!(await expectCall(() => send('/pfc pierre'), text(/Toi/))));
await test('/slot -> dé animé', async () => !!(await expectCall(() => send('/slot'), (c) => c.method === 'sendDice')));
await test('/quiz -> sondage quiz', async () => { const c = await expectCall(() => send('/quiz'), (c) => c.method === 'sendPoll'); return c && c.params.type === 'quiz' && c.params.options.length === 4; });
await test('/pendu + lettre', async () => { await expectCall(() => send('/pendu'), text(/Pendu/)); return !!(await expectCall(() => send('e'), text(/Pendu|Gagné/))); });
await test('/devine + proposition', async () => { await expectCall(() => send('/devine 10'), text(/entre 1 et 10/)); return !!(await expectCall(() => send('5'), text(/Plus|Trouvé/))); });
await test('/daily puis /solde', async () => { await expectCall(() => send('/daily'), text(/🪙/)); return !!(await expectCall(() => send('/solde'), text(/Solde/))); });
await test('/sondage', async () => !!(await expectCall(() => send('/sondage Pizza ? ; Oui ; Non'), (c) => c.method === 'sendPoll')));
await test('/horoscope lion', async () => !!(await expectCall(() => send('/horoscope lion'), text(/Lion/))));
await test('/ship', async () => !!(await expectCall(() => send('/ship Alice ; Bob'), text(/%/))));
await test('/morse aller-retour', async () => !!(await expectCall(() => send('/morse sos'), text(/\.\.\. --- \.\.\./))));
await test('services externes injoignables -> message gentil', async () => !!(await expectCall(() => send('/meteo Paris'), text(/ne répond pas|trouve pas/))));
await test('/note + /notes + /delnote', async () => { await expectCall(() => send('/addnote acheter du pain'), text(/enregistrée/)); await expectCall(() => send('/notes'), text(/acheter du pain/)); return !!(await expectCall(() => send('/delnote 1'), text(/supprimée/))); });
await test('/rappel 5s se déclenche', async () => { await expectCall(() => send('/rappel 5s boire de l’eau'), text(/noté/)); return !!(await waitFor(text(/Rappel/), 12000)); });

// --- robustesse
await test('anti-spam : 2 commandes identiques rapprochées -> 1 seule réponse', async () => { const since = state.calls.length; send('/blague', { from: USER }); send('/blague', { from: USER }); await sleep(1200); return state.calls.slice(since).filter(text(/./)).length === 1; });
await test('mises à jour bizarres (sans from, canal, edited, sticker) sans crash', async () => {
  inject({ message: { message_id: ++mid, chat: { id: 5, type: 'private' }, sticker: { file_id: 's' } } });
  inject({ channel_post: { message_id: 1, chat: { id: -5, type: 'channel' }, text: '/ping' } });
  inject({ edited_message: { message_id: 1, chat: { id: 5, type: 'private' }, text: 'x', from: OWNER } });
  inject({ message: { message_id: ++mid, chat: { id: -100, type: 'supergroup' }, sender_chat: { id: -100 }, text: '/ping' } });
  inject({ message: { message_id: ++mid, chat: { id: 5, type: 'private' }, from: OWNER, text: '/' } });
  inject({ message: { message_id: ++mid, chat: { id: 5, type: 'private' }, from: OWNER, text: '.' + 'a'.repeat(5000) } });
  inject({ callback_query: { id: 'x', data: 'garbage', from: OWNER } });
  await sleep(500); return exited === null && !!(await expectCall(() => send('/ping'), (c) => c.method === 'editMessageText'));
});
await test('réponse à un message supprimé -> renvoi sans réponse', async () => !!(await expectCall(() => send('/ping', { extra: {} }), (c) => c.method === 'sendMessage')));
state.failUpdates = 3;
await test('coupures de getUpdates (502) -> le bot continue', async () => { await sleep(100); return !!(await expectCall(() => send('/ping'), (c) => c.method === 'editMessageText', 15000)); });
state.conflictUpdates = 2;
await test('erreur 409 conflit -> le bot continue', async () => !!(await expectCall(() => send('/ping'), (c) => c.method === 'editMessageText', 25000)));

// --- jeux de dés non bloquants
await test('/slot ne bloque pas le chat (un /ping passe pendant l’animation)', async () => {
  const since = state.calls.length; const t0 = Date.now();
  send('/slot'); await sleep(150); send('/ping');
  const pong = await waitFor((c) => c.method === 'editMessageText' && /Pong/.test(c.params.text), 2500);
  return !!pong && Date.now() - t0 < 2500;
});
await test('/slot : le résultat arrive ensuite, en réponse au dé', async () => { const c = await waitFor(text(/JACKPOT/), 6000); return !!c && c.params.reply_parameters?.message_id > 0; });
await test('/foot /basket /dart /bowling répondent', async () => { for (const e of ['foot', 'basket', 'dart', 'bowling']) { if (!(await expectCall(() => send(`/${e}`), (c) => c.method === 'sendDice'))) return false; } return true; });
await test('emoji 🏀 envoyé seul en privé -> le bot joue (pas l’IA)', async () => { const ai0 = state.aiCalls; const ok = !!(await expectCall(() => send('🏀'), (c) => c.method === 'sendDice' && c.params.emoji === '🏀')); return ok && state.aiCalls === ai0; });
await test('dé envoyé par l’utilisateur -> commentaire', async () => !!(await expectCall(() => inject({ message: { message_id: ++mid, chat: { id: 5, type: 'private' }, from: OWNER, dice: { emoji: '🎯', value: 6 } } }), text(/mille/))));
await test('cooldown : l’utilisateur est prévenu au lieu de rester sans réponse', async () => { send('/slot', { from: USER }); await sleep(300); return !!(await expectCall(() => send('/slot', { from: USER }), text(/Attends encore/))); });

// --- étoiles Telegram
await test('/soutenir -> boutons de montants', async () => { const c = await expectCall(() => send('/soutenir'), (c) => c.method === 'sendMessage' && c.params.reply_markup); return c && JSON.stringify(c.params.reply_markup).includes('s:50'); });
await test('clic sur ⭐ 50 -> facture en étoiles (XTR, sans provider_token)', async () => { const c = await expectCall(() => inject({ callback_query: { id: 'cbs', data: 's:50', from: OWNER, message: { message_id: 55, chat: { id: 5, type: 'private' } } } }), (c) => c.method === 'sendInvoice'); return c && c.params.currency === 'XTR' && c.params.prices[0].amount === 50 && c.params.provider_token === undefined && /^support:1:50$/.test(c.params.payload); });
await test('/soutenir 75 -> facture de 75 étoiles', async () => { const c = await expectCall(() => send('/soutenir 75'), (c) => c.method === 'sendInvoice'); return c && c.params.prices[0].amount === 75; });
await test('/soutenir 0 refusé', async () => !!(await expectCall(() => send('/soutenir 0'), text(/entre 1 et/))));
await test('pre_checkout_query validé immédiatement', async () => { const c = await expectCall(() => inject({ pre_checkout_query: { id: 'pq1', from: OWNER, currency: 'XTR', total_amount: 50, invoice_payload: 'support:1:50' } }), (c) => c.method === 'answerPreCheckoutQuery'); return c && c.params.ok === true; });
await test('pre_checkout_query inconnu refusé', async () => { const c = await expectCall(() => inject({ pre_checkout_query: { id: 'pq2', from: OWNER, currency: 'USD', total_amount: 50, invoice_payload: 'autre' } }), (c) => c.method === 'answerPreCheckoutQuery'); return c && c.params.ok === false && !!c.params.error_message; });
const pay = { currency: 'XTR', total_amount: 50, invoice_payload: 'support:2:50', telegram_payment_charge_id: 'CHARGE_1', provider_payment_charge_id: '' };
await test('paiement reçu -> remerciement + notification du propriétaire', async () => { const since = state.calls.length; inject({ message: { message_id: ++mid, chat: { id: 5, type: 'private' }, from: USER, successful_payment: pay } }); await sleep(900); const calls = state.calls.slice(since); return calls.some((c) => c.method === 'sendMessage' && c.params.chat_id === 5 && /Merci/.test(c.params.text) && /50/.test(c.params.text)) && calls.some((c) => c.method === 'sendMessage' && c.params.chat_id === 1 && /Nouveau soutien/.test(c.params.text)); });
await test('paiement dupliqué ignoré (pas de double comptage)', async () => { const since = state.calls.length; inject({ message: { message_id: ++mid, chat: { id: 5, type: 'private' }, from: USER, successful_payment: pay } }); await sleep(700); return !state.calls.slice(since).some((c) => /Merci/.test(c.params?.text || '')); });
await test('/supporters affiche le total au propriétaire', async () => !!(await expectCall(() => send('/supporters'), text(/Lea[\s\S]*50 ⭐[\s\S]*Total reçu/))));

// --- pièces illimitées pour le créateur
await test('créateur : solde illimité (∞), même après un gros pari', async () => { await expectCall(() => send('/pari 999999999'), text(/Gagné|Perdu/)); return !!(await expectCall(() => send('/solde'), text(/∞/))); });
await test('autres utilisateurs : pas d’illimité (pari trop gros refusé)', async () => { const c = await expectCall(() => send('/pari 999999999', { from: { id: 3, first_name: 'Max', is_bot: false } }), text(/pas assez/)); return !!c; });
await test('autres utilisateurs : solde chiffré, pas ∞', async () => { const c = await expectCall(() => send('/solde', { from: { id: 3, first_name: 'Max', is_bot: false } }), text(/Solde/)); return c && !/∞/.test(c.params.text); });

// --- jeux à plusieurs
const U3 = { id: 3, first_name: 'Max', is_bot: false };
const MSG = (id) => ({ message_id: id, chat: { id: -100, type: 'supergroup', title: 'Groupe' } });
const tap = (data, from, mid = 700) => inject({ callback_query: { id: `cb${++mid}${Math.random()}`, data, from, message: MSG(mid) } });
const toast = (since, re) => state.calls.slice(since).some((c) => c.method === 'answerCallbackQuery' && re.test(c.params.text || ''));
const findGame = (re) => { for (const c of [...state.calls].reverse()) { const m = JSON.stringify(c.params.reply_markup || '').match(re); if (m) return m; } return null; };
await test('/jeux liste les jeux à plusieurs', async () => !!(await expectCall(() => send('/jeux', G), text(/morpion/))));
await test('/morpion : plateau avec boutons', async () => { send('/morpion', { ...G, reply: { message_id: 8, from: USER, chat: { id: -100 }, text: 'x' } }); const c = await waitFor((c) => c.method === 'editMessageText' && /g:ttt:/.test(JSON.stringify(c.params.reply_markup)), 4000); return !!c; });
let ttt = findGame(/g:ttt:(\w+):0/)?.[1];
await test('morpion : le défié rejoint en appuyant', async () => { const since = state.calls.length; tap(`g:ttt:${ttt}:4`, USER); await sleep(500); return toast(since, /Tu joues les ⭕/); });
await test('morpion : mauvais tour / tiers refusés', async () => { let since = state.calls.length; tap(`g:ttt:${ttt}:5`, USER); await sleep(400); const a = toast(since, /pas ton tour/); since = state.calls.length; tap(`g:ttt:${ttt}:5`, U3); await sleep(400); return a && toast(since, /deux autres joueurs/); });
await test('morpion : partie complète jusqu’à la victoire (+30 🪙)', async () => { const since = state.calls.length; for (const [cell, who] of [[0, OWNER], [3, USER], [1, OWNER], [4, USER], [2, OWNER]]) { tap(`g:ttt:${ttt}:${cell}`, who); await sleep(250); } await sleep(500); return state.calls.slice(since).some((c) => c.method === 'editMessageText' && /gagne/.test(c.params.text)); });
await test('morpion : boutons d’une partie finie -> message clair', async () => { const since = state.calls.length; tap(`g:ttt:${ttt}:6`, USER); await sleep(400); return toast(since, /terminée|expiré/); });
await test('/duel avec mise : acceptation, choix secrets, résultat', async () => {
  send('/duel 20', { ...G, reply: { message_id: 8, from: USER, chat: { id: -100 }, text: 'x' } });
  await waitFor((c) => c.method === 'editMessageText' && /g:duel:\w+:yes/.test(JSON.stringify(c.params.reply_markup)), 4000);
  const id = findGame(/g:duel:(\w+):yes/)?.[1]; if (!id) return false;
  let since = state.calls.length; tap(`g:duel:${id}:no`, U3); await sleep(300); if (!toast(since, /ne te concerne pas/)) return false;
  tap(`g:duel:${id}:yes`, USER); await sleep(500);
  tap(`g:duel:${id}:p`, OWNER); await sleep(300); tap(`g:duel:${id}:c`, USER); await sleep(600);
  return state.calls.some((c) => c.method === 'editMessageText' && /Duel/.test(c.params.text) && /gagne/.test(c.params.text));
});
await test('/duel sans réponse -> aide', async () => !!(await expectCall(() => send('/duel 10', G), text(/Réponds/))));
await test('/quizmulti : question à boutons, bonnes/mauvaises réponses', async () => {
  send('/quizmulti 3', G);
  const c = await waitFor((c) => c.method === 'sendMessage' && /Question 1\/3/.test(c.params.text), 9000); if (!c) return false;
  const id = JSON.stringify(c.params.reply_markup).match(/g:qz:(\w+):0/)?.[1]; if (!id) return false;
  const since = state.calls.length;
  [[OWNER, 0], [USER, 1], [U3, 2], [{ id: 4, first_name: 'Zed', is_bot: false }, 3]].forEach(([who, i]) => tap(`g:qz:${id}:${i}`, who));
  await sleep(700);
  const t = state.calls.slice(since).filter((c) => c.method === 'answerCallbackQuery').map((c) => c.params.text || '');
  tap(`g:qz:${id}:0`, OWNER); await sleep(300);
  return t.some((x) => /Bonne réponse/.test(x)) && t.filter((x) => /Raté/.test(x)).length === 3 && toast(since, /déjà répondu/);
});
await test('/quizmulti en double refusé, /stopjeu l’arrête', async () => !!(await expectCall(() => send('/quizmulti', G), text(/déjà en cours/))) && !!(await expectCall(() => send('/stopjeu', G), text(/arrêté/))));
await test('/tournoi : un joueur trouve la bonne réponse', async () => {
  const { WORDS } = await import('../content.js');
  send('/tournoi 3', G);
  const q = await waitFor((c) => c.method === 'sendMessage' && /Manche 1\/3/.test(c.params.text), 9000); if (!q) return false;
  let ans;
  const m = q.params.text.match(/font <b>(\d+) ([+\-×]) (\d+)<\/b>/);
  if (m) { const a = +m[1]; const b = +m[3]; ans = String(m[2] === '+' ? a + b : m[2] === '-' ? a - b : a * b); } else { const sc = q.params.text.match(/<b>([A-Z]+)<\/b>/)[1].toLowerCase(); ans = WORDS.find((w) => [...w].sort().join('') === [...sc].sort().join('')); }
  const ok = await expectCall(() => send(ans, { ...G, from: USER }), text(/a trouvé/), 4000);
  await expectCall(() => send('/stopjeu', G), text(/arrêté/)); return !!ok;
});
await test('/roulette gratuite : lobby, rejoindre, lancer, survivant', async () => {
  send('/roulette 0', G);
  await waitFor((c) => c.method === 'editMessageText' && /g:rr:\w+:join/.test(JSON.stringify(c.params.reply_markup)), 4000);
  const id = findGame(/g:rr:(\w+):join/)?.[1]; if (!id) return false;
  let since = state.calls.length; tap(`g:rr:${id}:go`, OWNER); await sleep(300); if (!toast(since, /2 joueurs/)) return false;
  tap(`g:rr:${id}:join`, USER); await sleep(400);
  since = state.calls.length; tap(`g:rr:${id}:go`, USER); await sleep(300); if (!toast(since, /créateur/)) return false;
  tap(`g:rr:${id}:go`, OWNER);
  return !!(await waitFor((c) => c.method === 'editMessageText' && /survit/.test(c.params.text), 8000));
});
await test('/roulette avec mise trop grosse refusée pour un non-créateur riche', async () => !!(await expectCall(() => send('/roulette 999999', { ...G, from: U3 }), text(/pas assez/))));
await test('/morpion en privé -> message clair', async () => !!(await expectCall(() => send('/morpion'), text(/groupe/))));

// --- sélection des modèles IA (unitaire) : un modèle qui répond "User Safety: safe" est écarté
// --- économie avancée : boutique, banque, niveaux, vol
const U5 = { id: 5, first_name: 'Ravi', is_bot: false };
await test('/boutique liste les objets', async () => !!(await expectCall(() => send('/boutique', G), text(/Bouclier[\s\S]*Trèfle/))));
await test('/acheter sans assez de pièces -> refus', async () => !!(await expectCall(() => send('/acheter pioche', { ...G, from: U4 }), text(/manque/))));
await test('/acheter + /utiliser + /inventaire (créateur)', async () => {
  const a = await expectCall(() => send('/acheter bouclier', G), text(/acheté/));
  const u = await expectCall(() => send('/utiliser bouclier', G), text(/Bouclier activé/));
  const i = await expectCall(() => send('/inventaire', G), text(/bouclier actif/));
  return a && u && i;
});
await test('objet inconnu -> aide', async () => !!(await expectCall(() => send('/acheter licorne', G), text(/Quel objet/))));
await test('banque : dépôt, retrait, solde', async () => {
  const d = await expectCall(() => send('/depot 50', { ...G, from: U4 }), text(/déposés/));
  const r = await expectCall(() => send('/retrait 20', { ...G, from: U4 }), text(/retirés/));
  const b = await expectCall(() => send('/banque', { ...G, from: U4 }), text(/Banque de[\s\S]*30/));
  await sleep(1300);
  const t = await expectCall(() => send('/depot 99999', { ...G, from: U4 }), text(/pas assez/));
  return d && r && b && t;
});
await test('/voler : protégé par le créateur, résultat pour un joueur ordinaire', async () => {
  const a = await expectCall(() => send('/voler', { ...G, from: U4, reply: { message_id: 8, from: OWNER, chat: { id: -100 }, text: 'x' } }), text(/Même pas en rêve/));
  const b = await expectCall(() => send('/voler', { ...G, from: U3, reply: { message_id: 9, from: USER, chat: { id: -100 }, text: 'x' } }), text(/dérobe|attrap|fauché|Il te faut/));
  return a && b;
});
await test('XP : un message donne de l’XP, /niveau l’affiche', async () => { send('coucou tout le monde', { ...G, from: U5 }); await sleep(300); const c = await expectCall(() => send('/niveau', { ...G, from: U5 }), text(/Niveau[\s\S]*XP/)); return c && !/0\/0/.test(c.params.text); });
await test('/topxp', async () => !!(await expectCall(() => send('/topxp', G), text(/Classement des niveaux/))));
await test('/roue : mise refusée sans pièces, jouable avec', async () => {
  const a = await expectCall(() => send('/roue 5000', { ...G, from: U5 }), text(/pas assez/));
  const b = await expectCall(() => send('/roue 50', G), text(/La roue tourne/));
  return a && b;
});

// --- blackjack
await test('/blackjack : cartes + boutons, seul le joueur peut agir', async () => {
  const c = await expectCall(() => send('/blackjack 50', G), (c) => c.method === 'sendMessage' && /b:\w+:h/.test(JSON.stringify(c.params.reply_markup || '')) || (c.method === 'sendMessage' && /Blackjack/.test(c.params.text)));
  const id = findGame(/b:(\w+):h/)?.[1];
  if (!c) return false;
  if (!id) return true; // blackjack naturel immédiat : partie déjà terminée
  let since = state.calls.length; tap(`b:${id}:s`, USER); await sleep(400);
  const refused = toast(since, /pas ta partie/);
  since = state.calls.length; tap(`b:${id}:s`, OWNER); await sleep(600);
  return refused && state.calls.slice(since).some((x) => x.method === 'editMessageText' && /Croupier/.test(x.params.text) && /solde/.test(x.params.text));
});
await test('/blackjack sans assez de pièces', async () => !!(await expectCall(() => send('/blackjack 4000', { ...G, from: U5 }), text(/pas assez/))));

// --- puissance 4
await test('/puissance4 : rejoindre puis victoire verticale', async () => {
  send('/puissance4', G);
  await waitFor((c) => c.method === 'editMessageText' || (c.method === 'sendMessage' && /p:\w+:0/.test(JSON.stringify(c.params.reply_markup || ''))), 3000);
  const id = findGame(/p:(\w+):0/)?.[1];
  if (!id) return false;
  let since = state.calls.length; tap(`p:${id}:3`, OWNER); await sleep(300);
  const self = toast(since, /Attends/);
  since = state.calls.length; tap(`p:${id}:3`, USER); await sleep(400);
  const joined = toast(since, /Tu joues les 🟡/);
  for (const [col, who] of [[0, OWNER], [1, USER], [0, OWNER], [1, USER], [0, OWNER], [1, USER], [0, OWNER]]) { tap(`p:${id}:${col}`, who); await sleep(250); }
  await sleep(500);
  return self && joined && state.calls.some((c) => c.method === 'editMessageText' && /gagne/.test(c.params.text) && /Puissance 4/.test(c.params.text));
});

// --- gestion par le créateur : utilisateurs, groupes, blocage, quitter
const PRIV0 = (u) => ({ chat: u.id + 2000, from: u });
const ownerTap = (data, from = OWNER) => inject({ callback_query: { id: `cbo${++mid}`, data, from, message: { message_id: 900 + mid, chat: { id: 5, type: 'private' } } } });
await test('gestion : réservée au créateur', async () => !!(await expectCall(() => send('/utilisateurs', PRIV0(U3)), text(/réservée à mon créateur/))));
await test('/utilisateurs : liste avec boutons de profil', async () => { const c = await expectCall(() => send('/utilisateurs'), text(/Utilisateurs/)); return c && /o:u:2/.test(JSON.stringify(c.params.reply_markup)) && /o:u:1/.test(JSON.stringify(c.params.reply_markup)); });
await test('/utilisateurs lea : recherche', async () => { await sleep(2100); const c = await expectCall(() => send('/utilisateurs lea'), text(/pour « lea »/)); return c && /o:u:2/.test(JSON.stringify(c.params.reply_markup)) && !/o:u:3/.test(JSON.stringify(c.params.reply_markup)); });
await test('/voiruser @lea : profil complet + bouton Bloquer', async () => {
  const c = await expectCall(() => send('/voiruser @lea'), text(/Messages[\s\S]*Niveau[\s\S]*Pièces/));
  return c && /Lea/.test(c.params.text) && /o:bl:2/.test(JSON.stringify(c.params.reply_markup));
});
await test('blocage par bouton : l’utilisateur est ignoré, le créateur ne peut pas être bloqué', async () => {
  const since = state.calls.length; ownerTap('o:bl:2'); await sleep(500);
  const edited = state.calls.slice(since).some((c) => c.method === 'editMessageText' && /BLOQUÉ/.test(c.params.text));
  const ignored = await expectNone(() => send('/solde', { ...G, from: USER }), (c) => c.method === 'sendMessage' && /Solde/.test(c.params.text), 1500);
  const since2 = state.calls.length; ownerTap('o:bl:1'); await sleep(400);
  const refused = state.calls.slice(since2).some((c) => c.method === 'answerCallbackQuery' && /créateur/.test(c.params.text || ''));
  return edited && ignored && refused;
});
await test('/bloques liste puis déblocage par bouton', async () => {
  const c = await expectCall(() => send('/bloques'), text(/Utilisateurs bloqués[\s\S]*Lea/));
  const since = state.calls.length; ownerTap('o:ub:2'); await sleep(500);
  const back = state.calls.slice(since).some((x) => x.method === 'editMessageText' && !/BLOQUÉ/.test(x.params.text) && /Lea/.test(x.params.text));
  const works = await expectCall(() => send('/solde', { ...G, from: USER }), text(/Solde/));
  return c && back && !!works;
});
await test('/bloquer et /debloquer par commande (@pseudo)', async () => {
  const a = await expectCall(() => send('/bloquer @lea'), text(/est maintenant bloqué/));
  const b = await expectCall(() => send('/debloquer @lea'), text(/est débloqué/));
  await sleep(1600);
  const c = await expectCall(() => send('/bloquer', { reply: { message_id: 3, from: OWNER, chat: { id: 5 }, text: 'x' } }), text(/ne peux pas bloquer/));
  return a && b && c;
});
await test('boutons du créateur refusés aux autres', async () => { const since = state.calls.length; ownerTap('o:bl:3', U3); await sleep(500); return state.calls.slice(since).some((c) => c.method === 'answerCallbackQuery' && /Réservé/.test(c.params.text || '')) && !!(await expectCall(() => send('/solde', { ...G, from: U3 }), text(/Solde/))); });
send('coucou le groupe', { chat: -555, type: 'supergroup', from: USER }); await sleep(500);
await test('/groupes : liste avec le groupe', async () => { const c = await expectCall(() => send('/groupes'), text(/Groupes/)); return c && /o:g:-555/.test(JSON.stringify(c.params.reply_markup)); });
await test('fiche de groupe puis quitter avec confirmation', async () => {
  let since = state.calls.length; ownerTap('o:g:-555'); await sleep(700);
  const card = state.calls.slice(since).find((c) => c.method === 'editMessageText' && /Membres/.test(c.params.text));
  since = state.calls.length; ownerTap('o:lq:-555'); await sleep(400);
  const ask = state.calls.slice(since).some((c) => c.method === 'editMessageText' && /Faire quitter/.test(c.params.text));
  since = state.calls.length; ownerTap('o:ly:-555'); await sleep(700);
  const left = state.calls.slice(since).find((c) => c.method === 'leaveChat');
  const msgd = state.calls.slice(since).some((c) => c.method === 'editMessageText' && /J’ai quitté/.test(c.params.text));
  return !!card && ask && left?.params.chat_id === -555 && msgd;
});
await test('/quitter par nom de groupe (confirmation) et groupe inconnu', async () => {
  send('re coucou', { chat: -556, type: 'supergroup', from: USER }); await sleep(400);
  const a = await expectCall(() => send('/quitter Groupe'), text(/Faire quitter/));
  await sleep(3100);
  const b = await expectCall(() => send('/quitter zzzinconnu'), text(/Usage/));
  return a && b;
});

// --- chat payant (étoiles)
const PRIV = (u) => ({ chat: u.id + 1000, from: u });
await test('chat payant : réservé au créateur, désactivé par défaut', async () => {
  const a = await expectCall(() => send('/chatpayant on', PRIV(U3)), text(/réservée à mon créateur/));
  const b = await expectCall(() => send('/chatpayant', G), text(/désactivé/));
  return a && b;
});
await test('chat payant : réglage prix/durée puis activation', async () => {
  const a = await expectCall(() => send('/chatpayant prix 20', G), text(/20 ⭐/));
  await sleep(1300);
  const b = await expectCall(() => send('/chatpayant jours 7', G), text(/7 jour/));
  await sleep(1300);
  const c = await expectCall(() => send('/chatpayant on', G), text(/ACTIVÉ/));
  return a && b && c;
});
await test('chat payant : un inconnu est bloqué avec bouton de paiement, sans appel IA', async () => {
  const before = state.aiCalls;
  const c = await expectCall(() => send('Coucou Hina', PRIV(U3)), (c) => c.method === 'sendMessage' && /réservé/.test(c.params.text) && /a:buy/.test(JSON.stringify(c.params.reply_markup || '')));
  return c && /20 ⭐/.test(c.params.text) && state.aiCalls === before;
});
await test('chat payant : les commandes IA sont aussi réservées (bouton de paiement, sans appel IA)', async () => {
  const before = state.aiCalls;
  const c = await expectCall(() => send('/ia pourquoi le ciel est bleu', PRIV(U3)), (c) => c.method === 'sendMessage' && /réservée/.test(c.params.text) && /a:buy/.test(JSON.stringify(c.params.reply_markup || '')), 8000);
  await sleep(1300);
  const d = await expectCall(() => send('/poeme la mer', PRIV(U3)), (c) => c.method === 'sendMessage' && /réservée/.test(c.params.text), 8000);
  return !!c && !!d && state.aiCalls === before;
});
await test('chat payant : le créateur garde les commandes IA', async () => { const c = await expectCall(() => send('/ia bonjour', { chat: 5 }), (c) => c.method === 'sendMessage' && !/réservée/.test(c.params.text), 8000); return !!c; });
await test('chat payant : les commandes restent gratuites, le créateur discute librement', async () => {
  await sleep(1300);
  const a = await expectCall(() => send('/solde', PRIV(U3)), text(/Solde/), 8000);
  const b = await expectCall(() => send('Salut', { chat: 5 }), text(/Salut|batteries/), 8000);
  return a && b;
});
await test('chat payant : bouton -> facture XTR 20 ⭐ avec payload access', async () => {
  const c = await expectCall(() => inject({ callback_query: { id: 'cba1', data: 'a:buy', from: U3, message: { message_id: 56, chat: { id: 1003, type: 'private' } } } }), (c) => c.method === 'sendInvoice');
  return c && c.params.currency === 'XTR' && c.params.prices[0].amount === 20 && /^access:3:20:7$/.test(c.params.payload);
});
await test('chat payant : pre_checkout "access" validé', async () => { const c = await expectCall(() => inject({ pre_checkout_query: { id: 'pqa', from: U3, currency: 'XTR', total_amount: 20, invoice_payload: 'access:3:20:7' } }), (c) => c.method === 'answerPreCheckoutQuery'); return c && c.params.ok === true; });
await test('chat payant : paiement -> accès débloqué, créateur prévenu', async () => {
  const since = state.calls.length;
  inject({ message: { message_id: ++mid, chat: { id: 1003, type: 'private' }, from: U3, successful_payment: { currency: 'XTR', total_amount: 20, invoice_payload: 'access:3:20:7', telegram_payment_charge_id: 'chargeACCESS1' } } });
  await sleep(900);
  const calls = state.calls.slice(since);
  return calls.some((c) => /accès au chat[\s\S]*activé/.test(c.params?.text || '')) && calls.some((c) => c.params?.chat_id === 1 && /Accès au chat acheté/.test(c.params?.text || ''));
});
await test('chat payant : après paiement, les commandes IA fonctionnent', async () => { await sleep(1300); const c = await expectCall(() => send('/ia re', PRIV(U3)), (c) => c.method === 'sendMessage', 8000); return !!c && !/réservée/.test(c.params.text); });
await test('chat payant : après paiement, la personne peut discuter (plus de blocage)', async () => {
  const c = await expectCall(() => send('Re coucou', PRIV(U3)), (c) => c.method === 'sendMessage' && /Salut|batteries/.test(c.params.text));
  return !!c && !/réservé/.test(c.params.text);
});
await test('chat payant : /acces, /chatpayant liste puis retirer', async () => {
  const a = await expectCall(() => send('/acces', PRIV(U3)), text(/actif encore/));
  const b = await expectCall(() => send('/chatpayant liste', G), text(/Accès actifs[\s\S]*Max/));
  await sleep(1300);
  const c = await expectCall(() => send('/chatpayant retirer', { ...G, reply: { message_id: 8, from: U3, chat: { id: -100 }, text: 'x' } }), text(/Accès retiré/));
  await sleep(3200);
  const d = await expectCall(() => send('/acces', PRIV(U3)), text(/pas \(ou plus\) accès/));
  return a && b && c && d;
});
await test('chat payant : désactivation -> tout le monde rediscute', async () => {
  await expectCall(() => send('/chatpayant off', G), text(/DÉSACTIVÉ/));
  const c = await expectCall(() => send('Hey', { chat: 1004, from: { id: 9, first_name: 'Zed', is_bot: false } }), (c) => c.method === 'sendMessage' && /Salut|batteries/.test(c.params.text));
  return !!c;
});

// --- personnalité : souvenirs, style, humeur, affinité
await test('/souvenirs liste ce que Hina a retenu', async () => !!(await expectCall(() => send('/souvenirs', { ...G, from: U4 }), text(/1\. j’adore les chats/))));
await test('/oublier un souvenir puis tout', async () => {
  const a = await expectCall(() => send('/oublier 1', { ...G, from: U4 }), text(/Oublié/));
  await sleep(1300);
  const b = await expectCall(() => send('/oublier tout', { ...G, from: U4 }), text(/aucun souvenir/));
  return a && b;
});
await test('/affinite et /humeurhina (créateur peut changer)', async () => {
  const a = await expectCall(() => send('/affinite', { ...G, from: U4 }), text(/Notre lien/));
  const b = await expectCall(() => send('/humeurhina câline', G), text(/câline/));
  const c = await expectCall(() => send('/humeurhina auto', G), text(/automatique/));
  const d = await expectCall(() => send('/humeurhina', { ...G, from: U4 }), text(/Aujourd/));
  return a && b && c && d;
});

process.env.ENV_FILE = '/nonexistent'; process.env.OPENROUTER_API_KEY = 'k'; process.env.OPENROUTER_BASE = `http://127.0.0.1:${port}/ai`; delete process.env.AI_BASE_URL; process.env.DATA_FILE = path.join(tmp, 'unit.json');
state.modelCalls = {};
const aiMod = await import('../ai.js');
await test('IA : saute le modèle "guard"/absurde/en panne et utilise un bon modèle gratuit', async () => {
  const r = await aiMod.chat([{ role: 'user', content: 'Salut' }]);
  return r.text === 'Salut mon cœur ✨ test' && r.model === 'good/chat:free' && !state.modelCalls['meta-llama/llama-guard-4:free'] && !state.modelCalls['paid/model'];
});
await test('IA : les mauvais modèles sont mis de côté (pas ré-essayés)', async () => { const bad0 = state.modelCalls['bad/chat:free']; const r = await aiMod.chat([{ role: 'user', content: 'Re' }]); return r.model === 'good/chat:free' && state.modelCalls['bad/chat:free'] === bad0; });

const g2 = await import('../handlers/games2.js');
const card = (r) => ({ r, s: '♠️' });
await test('blackjack : valeur des mains (as = 1 ou 11)', async () => g2.handValue([card('A'), card('K')]) === 21 && g2.handValue([card('A'), card('A'), card('9')]) === 21 && g2.handValue([card('K'), card('Q'), card('5')]) === 25 && g2.handValue([card('5'), card('6')]) === 11);
await test('puissance 4 : détection horizontale, diagonale, rien', async () => {
  const mk = () => Array.from({ length: 6 }, () => Array(7).fill(''));
  const h = mk(); for (let c = 2; c < 6; c += 1) h[5][c] = 'R';
  const d = mk(); for (let k = 0; k < 4; k += 1) d[5 - k][k] = 'Y';
  const n = mk(); n[5][0] = 'R'; n[5][1] = 'Y'; n[5][2] = 'R';
  return g2.p4Winner(h) === 'R' && g2.p4Winner(d) === 'Y' && g2.p4Winner(n) === null;
});
const perks = await import('../perks.js');
await test('XP/niveaux : formule cohérente, objets reconnus par préfixe', async () => perks.levelOf(0) === 0 && perks.levelOf(25) === 1 && perks.levelOf(100) === 2 && perks.xpFor(3) === 225 && perks.itemKey('bouc') === 'bouclier' && perks.itemKey('Trèfle') === 'trefle' && perks.itemKey('xyz') === null);

// --- unitaires Telegram (repli HTML, 429)
const { Telegram } = await import('../telegram.js');
const tg = new Telegram({ token: 'x:y', base: `http://127.0.0.1:${port}/tg`, log: console });
await test('HTML invalide -> renvoi en texte brut', async () => { const r = await tg.sendMessage(77, '<b>unclosed texte'); return r?.message_id > 0 && !state.calls.at(-1).params.parse_mode; });
await test('429 -> attente retry_after puis succès', async () => { state.fail429Once.add(78); const t0 = Date.now(); const r = await tg.sendMessage(78, 'hello'); return r?.message_id > 0 && Date.now() - t0 >= 1000; });
await test('réponse à un message introuvable -> renvoi sans reply', async () => { const r = await tg.sendMessage(79, 'x', { reply_to: 424242 }); return r?.message_id > 0; });
await test('texte > 4096 découpé', async () => { const since = state.calls.length; await tg.sendMessage(80, `${'mot '.repeat(2500)}`); return state.calls.slice(since).filter((c) => c.method === 'sendMessage').length >= 3; });

// --- arrêt propre
child.kill('SIGTERM');
for (let i = 0; i < 40 && exited === null; i += 1) await sleep(100);
await test('arrêt propre (SIGTERM) code 0', async () => exited === 0);
await test('données sauvegardées, JSON valide, pas de fichier .tmp', async () => { const d = JSON.parse(fs.readFileSync(dataFile, 'utf8')); return Object.keys(d.users).length >= 2 && !fs.existsSync(`${dataFile}.tmp`); });
await test('l’historique ne contient aucun message d’erreur', async () => { const d = JSON.parse(fs.readFileSync(dataFile, 'utf8')); const all = JSON.stringify(d.history); return /Salut mon cœur/.test(all) && !/batteries|buggé|reprends mes esprits/.test(all); });
await test('aucune exception non gérée dans les logs', async () => !/uncaughtException|unhandledRejection|\[fatal\]|TypeError|ReferenceError/.test(log));

for (const [s, n] of results) console.log(`${s === 'OK ' ? '✅' : '❌'} ${n}`);
console.log(`\n${results.length - failed}/${results.length} tests réussis`);
if (failed) console.log('\n--- LOGS ---\n' + log.slice(-3000));
server.close(); fs.rmSync(tmp, { recursive: true, force: true });
process.exit(failed ? 1 : 0);
